package com.example.fourbuttonpad

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class QuickNote(
    val id: Long,
    val timestamp: String,
    val text: String,
    val modeName: String = PadMode.SCHOOL.name
)

enum class PadMode(
    val label: String,
    val accent: Color,
    val inverseNeonText: Color,
    val buttonBrightText: Color,
    val defaultSeconds: Int?,
    val supportsTimer: Boolean
) {
    SCHOOL(
        label = "Школа",
        accent = Color(0xFFE11D48),
        inverseNeonText = Color(0xFF5EEAD4),
        buttonBrightText = Color(0xFFFFA3B5),
        defaultSeconds = 40 * 60,
        supportsTimer = true
    ),
    CODING(
        label = "Коддинг",
        accent = Color(0xFF9333EA),
        inverseNeonText = Color(0xFFBEF264),
        buttonBrightText = Color(0xFFD8B4FE),
        defaultSeconds = 60 * 60,
        supportsTimer = true
    ),
    REST(
        label = "Отдых",
        accent = Color(0xFF84CC16),
        inverseNeonText = Color(0xFFC084FC),
        buttonBrightText = Color(0xFFD9F99D),
        defaultSeconds = null,
        supportsTimer = true
    ),
    SLEEP(
        label = "Сон",
        accent = Color(0xFF93C5FD),
        inverseNeonText = Color(0xFFFDE68A),
        buttonBrightText = Color(0xFFDBEAFE),
        defaultSeconds = null,
        supportsTimer = false
    );

    companion object {
        fun fromName(name: String?): PadMode {
            if (name == "STUDY") return SCHOOL
            return runCatching { valueOf(name ?: "") }.getOrDefault(SCHOOL)
        }
    }
}

data class AppSettings(
    val notificationsEnabled: Boolean = true,
    val codingVibrationEnabled: Boolean = true,
    val smoothAnimationsEnabled: Boolean = true,
    // Реально работающий ползунок: задаёт темп/интенсивность дыхания UI (0..100), влияет на скорость пульсации и шаг прокрутки
    val uiPacePercent: Float = 50f
)

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.SCHOOL,
    val remainingSeconds: Int = 40 * 60,
    val isTimerRunning: Boolean = false,
    val restTimerFinished: Boolean = false,
    val notes: List<QuickNote> = emptyList(),
    val settings: AppSettings = AppSettings()
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val mode = PadMode.fromName(obj.optString("mode", PadMode.SCHOOL.name))
            val defaultSec = mode.defaultSeconds ?: 0
            val remainingSeconds = obj.optInt("remainingSeconds", defaultSec).coerceAtLeast(0)
            val isTimerRunning = if (mode.supportsTimer) obj.optBoolean("isTimerRunning", false) else false
            val restTimerFinished = if (mode == PadMode.REST) obj.optBoolean("restTimerFinished", false) else false

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    val rawStamp = item.optString("timestamp", "").ifBlank {
                        item.optString("time", "01.01.26, 00:00")
                    }
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            timestamp = rawStamp,
                            text = item.optString("text", ""),
                            modeName = PadMode.fromName(item.optString("modeName", mode.name)).name
                        )
                    )
                }
            }

            val settingsObj = obj.optJSONObject("settings") ?: JSONObject()
            val settings = AppSettings(
                notificationsEnabled = settingsObj.optBoolean("notificationsEnabled", true),
                codingVibrationEnabled = settingsObj.optBoolean("codingVibrationEnabled", true),
                smoothAnimationsEnabled = settingsObj.optBoolean("smoothAnimationsEnabled", true),
                uiPacePercent = settingsObj.optDouble("uiPacePercent", 50.0).toFloat().coerceIn(0f, 100f)
            )

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                restTimerFinished = restTimerFinished,
                notes = notes,
                settings = settings
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)
            put("restTimerFinished", state.restTimerFinished)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("timestamp", n.timestamp)
                        put("text", n.text)
                        put("modeName", n.modeName)
                    }
                )
            }
            put("notes", arr)

            put(
                "settings",
                JSONObject().apply {
                    put("notificationsEnabled", state.settings.notificationsEnabled)
                    put("codingVibrationEnabled", state.settings.codingVibrationEnabled)
                    put("smoothAnimationsEnabled", state.settings.smoothAnimationsEnabled)
                    put("uiPacePercent", state.settings.uiPacePercent.toDouble())
                }
            )
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

object AlertHelper {
    const val CHANNEL_SCHOOL_NO_VIBRATE = "kuro_school_silent_v6"
    const val CHANNEL_CODING_VIBRATE = "kuro_coding_vibrate_v6"
    const val CHANNEL_ONGOING_QUIET = "kuro_ongoing_quiet_v6"

    private const val TIMER_DONE_ID = 1001
    private const val ONGOING_STATUS_ID = 2001

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val schoolChannel = NotificationChannel(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Школа — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Школа без вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
            }

            val codingChannel = NotificationChannel(
                CHANNEL_CODING_VIBRATE,
                "Коддинг — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Коддинг с вибрацией"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 300L, 150L, 300L)
            }

            val ongoingQuietChannel = NotificationChannel(
                CHANNEL_ONGOING_QUIET,
                "Сон и Отдых — постоянный статус",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Постоянное статус-уведомление для режимов Сон и Отдых без звука и вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
                setShowBadge(false)
            }

            manager.createNotificationChannel(schoolChannel)
            manager.createNotificationChannel(codingChannel)
            manager.createNotificationChannel(ongoingQuietChannel)
        }
    }

    private fun createReturnToAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags)
    }

    fun canNotify(context: Context, settings: AppSettings): Boolean {
        if (!settings.notificationsEnabled) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun isOngoingNotificationPresent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return runCatching {
                manager.activeNotifications.any { it.id == ONGOING_STATUS_ID }
            }.getOrDefault(false)
        }
        return false
    }

    fun showTimerDoneNotification(context: Context, mode: PadMode, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val (channelId, title, message, vibrateEnabled) = when (mode) {
            PadMode.CODING -> Quadruple(
                CHANNEL_CODING_VIBRATE,
                "Помощник Куро — Коддинг",
                "Таймер закончился. Пора отдохнуть.",
                settings.codingVibrationEnabled
            )
            PadMode.SCHOOL -> Quadruple(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Помощник Куро — Школа",
                "Урок кончился? Есть что записать? Я здесь.",
                false
            )
            else -> return
        }

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1101)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(!vibrateEnabled)
            .setAutoCancel(true)
            .apply {
                if (vibrateEnabled) {
                    setVibrate(longArrayOf(0L, 300L, 150L, 300L))
                } else {
                    setVibrate(longArrayOf(0L))
                }
            }
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun showRestDoneExternalNotification(context: Context, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val message = "Отдых кончился... Вернемся к работе?"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1102)
        val notification = NotificationCompat.Builder(context, CHANNEL_SCHOOL_NO_VIBRATE)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle("Помощник Куро — Отдых")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun syncOngoingModeNotification(
        context: Context,
        mode: PadMode,
        restTimerFinished: Boolean,
        settings: AppSettings,
        forceRecreate: Boolean = false
    ) {
        if (!canNotify(context, settings)) {
            cancelOngoingNotification(context)
            return
        }

        val message = when (mode) {
            PadMode.SLEEP -> "Вы спите?"
            PadMode.REST -> {
                if (restTimerFinished) {
                    "Отдых кончился... Вернемся к работе?"
                } else {
                    "Ждём, когда Вы отдохнете... Не торопитесь, я здесь."
                }
            }
            else -> {
                cancelOngoingNotification(context)
                return
            }
        }

        if (!forceRecreate && isOngoingNotificationPresent(context)) {
            return
        }

        val title = "Помощник Куро — ${mode.label}"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 2101)
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setAutoCancel(false)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(ONGOING_STATUS_ID, notification)
        }
    }

    fun cancelOngoingNotification(context: Context) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(ONGOING_STATUS_ID)
        }
    }

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D
    )
}

class MainActivity : ComponentActivity() {
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                val store = MemoryStore(File(filesDir, "pad_memory.json"))
                val loaded = store.load()
                AlertHelper.syncOngoingModeNotification(
                    context = this,
                    mode = loaded.mode,
                    restTimerFinished = loaded.restTimerFinished,
                    settings = loaded.settings,
                    forceRecreate = true
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.ensureChannels(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()
        AlertHelper.syncOngoingModeNotification(
            context = this,
            mode = initialState.mode,
            restTimerFinished = initialState.restTimerFinished,
            settings = initialState.settings,
            forceRecreate = false
        )

        setContent {
            KuroAssistantApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

private data class SmokeParticle(
    val seed: Float,
    val baseXRatio: Float,
    val baseYRatio: Float,
    val radiusDp: Float,
    val driftX: Float,
    val driftY: Float,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KuroAssistantApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var showCodingPresetDialog by remember { mutableStateOf(false) }
    var showCustomRestDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showResetCounterConfirmDialog by remember { mutableStateOf(false) }
    var showTimerFinishedBanner by remember { mutableStateOf(false) }
    var draftNote by remember { mutableStateOf("") }
    var customMinutesInput by remember { mutableStateOf("15") }

    // Фиолетовый дым по нажатию на сердечко: случайная длительность от 1 до 5 секунд
    var smokeDurationSec by remember { mutableIntStateOf(0) }
    var smokeTriggerId by remember { mutableIntStateOf(0) }
    var smokeProgress by remember { mutableFloatStateOf(0f) }

    // Удержание кнопок + и - на таймере (старт автонакрутки после > 2 сек удержания)
    var holdingPlus by remember { mutableStateOf(false) }
    var holdingMinus by remember { mutableStateOf(false) }

    val smooth = state.settings.smoothAnimationsEnabled
    val paceFactor = (state.settings.uiPacePercent / 100f).coerceIn(0f, 1f)
    val animDuration = if (smooth) {
        max(120, (520f - paceFactor * 360f).toInt())
    } else {
        0
    }

    // Плавные анимации включают как переходы цветов/масштабов, так и мягкое дыхание подсветки при включённой опции
    val animatedAccent by animateColorAsState(
        targetValue = state.mode.accent,
        animationSpec = if (smooth) {
            tween(durationMillis = animDuration, easing = FastOutSlowInEasing)
        } else {
            snap()
        },
        label = "accentAnim"
    )

    val mainMenuWhite = Color(0xFFF8FAFC)
    val buttonTextColor by animateColorAsState(
        targetValue = state.mode.buttonBrightText,
        animationSpec = if (smooth) {
            tween(durationMillis = animDuration, easing = FastOutSlowInEasing)
        } else {
            snap()
        },
        label = "btnBrightAnim"
    )

    val breathPulse = if (smooth) {
        val transition = rememberInfiniteTransition(label = "breathTransition")
        val periodMs = max(900, (3200f - paceFactor * 2100f).toInt())
        transition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = periodMs, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "breathScale"
        ).value
    } else {
        1f
    }

    fun updateAndSave(
        forceNotificationRecreate: Boolean = false,
        transform: (PadMemoryState) -> PadMemoryState
    ) {
        val next = transform(state)
        state = next
        onPersist(next)
        AlertHelper.syncOngoingModeNotification(
            context = context,
            mode = next.mode,
            restTimerFinished = next.restTimerFinished,
            settings = next.settings,
            forceRecreate = forceNotificationRecreate
        )
    }

    fun ensureRestModeSupportsTimer(current: PadMemoryState): PadMemoryState {
        return if (current.mode == PadMode.REST) {
            current.copy(restTimerFinished = false)
        } else {
            current
        }
    }

    fun applyModeSelection(chosen: PadMode) {
        when (chosen) {
            PadMode.SCHOOL -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SCHOOL,
                        remainingSeconds = 40 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
            }
            PadMode.CODING -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.CODING,
                        remainingSeconds = 60 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCodingPresetDialog = true
            }
            PadMode.REST -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.REST,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCustomRestDialog = true
            }
            PadMode.SLEEP -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SLEEP,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
            }
        }
    }

    // Таймер фиолетового дыма на 1..5 секунд
    LaunchedEffect(smokeTriggerId) {
        if (smokeTriggerId == 0 || smokeDurationSec <= 0) return@LaunchedEffect
        val totalMs = smokeDurationSec * 1000L
        val stepMs = 30L
        var elapsed = 0L
        smokeProgress = 0f
        while (elapsed < totalMs && isActive) {
            delay(stepMs)
            elapsed += stepMs
            smokeProgress = (elapsed.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
        }
        smokeProgress = 1f
        smokeDurationSec = 0
    }

    // Автонакрутка таймера при удержании + или - дольше 2 секунд:
    // рост плавный и читаемый человеком (начинается с малых шагов, затем нарастает без ухода в "скорость света")
    LaunchedEffect(holdingPlus, holdingMinus, state.mode) {
        val activeDirection = when {
            holdingPlus && !holdingMinus -> 1
            holdingMinus && !holdingPlus -> -1
            else -> 0
        }
        if (activeDirection == 0 || !state.mode.supportsTimer) return@LaunchedEffect

        // Ждём 2000 мс удержания перед началом автонакрутки
        delay(2000L)
        val startHoldTime = System.currentTimeMillis()
        while (isActive) {
            val heldSec = ((System.currentTimeMillis() - startHoldTime) / 1000f).coerceAtLeast(0f)
            // Плавная кривая: первые секунды идёт по 1-2 сек, к 5-8 сек доходит до 15-30 сек за тик
            val ramp = (heldSec / 6f).coerceIn(0f, 1f)
            val smoothRamp = ramp * ramp * (3f - 2f * ramp)
            val paceBoost = 0.6f + paceFactor * 0.8f
            val stepSeconds = max(1, ((1f + smoothRamp * 24f) * paceBoost).toInt())
            val tickDelayMs = max(120L, (260f - smoothRamp * 120f).toLong())

            showTimerFinishedBanner = false
            updateAndSave { current ->
                if (!current.mode.supportsTimer) {
                    current
                } else {
                    val updatedSec = (current.remainingSeconds + activeDirection * stepSeconds)
                        .coerceIn(0, 99 * 3600 + 59 * 60 + 59)
                    ensureRestModeSupportsTimer(current).copy(
                        remainingSeconds = updatedSec,
                        isTimerRunning = false
                    )
                }
            }
            delay(tickDelayMs)
        }
    }

    // Проверка на удаление постоянного уведомления Сна/Отдыха из панели
    LaunchedEffect(state.mode, state.restTimerFinished, state.settings.notificationsEnabled) {
        while (state.mode == PadMode.SLEEP || state.mode == PadMode.REST) {
            AlertHelper.syncOngoingModeNotification(
                context = context,
                mode = state.mode,
                restTimerFinished = state.restTimerFinished,
                settings = state.settings,
                forceRecreate = false
            )
            delay(5000L)
        }
    }

    LaunchedEffect(state.isTimerRunning, state.mode) {
        while (state.isTimerRunning && state.mode.supportsTimer && state.remainingSeconds > 0) {
            delay(1000L)
            var reachedZero = false
            var finishedMode = state.mode
            var currentSettings = state.settings
            var recreateOngoing = false
            updateAndSave(forceNotificationRecreate = false) { current ->
                finishedMode = current.mode
                currentSettings = current.settings
                if (!current.isTimerRunning || !current.mode.supportsTimer) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    reachedZero = true
                    if (current.mode == PadMode.REST) {
                        recreateOngoing = true
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = true
                        )
                    } else {
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = false
                        )
                    }
                }
            }
            if (recreateOngoing) {
                AlertHelper.syncOngoingModeNotification(
                    context = context,
                    mode = finishedMode,
                    restTimerFinished = true,
                    settings = currentSettings,
                    forceRecreate = true
                )
            }
            if (reachedZero) {
                if (finishedMode == PadMode.SCHOOL || finishedMode == PadMode.CODING) {
                    showTimerFinishedBanner = true
                    AlertHelper.showTimerDoneNotification(context, finishedMode, currentSettings)
                } else if (finishedMode == PadMode.REST) {
                    AlertHelper.showRestDoneExternalNotification(context, currentSettings)
                }
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = animatedAccent,
        onPrimary = Color(0xFF060911),
        background = Color(0xFF060911),
        onBackground = mainMenuWhite,
        surface = Color(0xFF0E1525),
        onSurface = mainMenuWhite,
        surfaceVariant = Color(0xFF1A2438),
        onSurfaceVariant = Color(0xFFCBD5E1)
    )

    MaterialTheme(colorScheme = darkScheme) {
        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = "Помощник Куро",
                                fontWeight = FontWeight.SemiBold,
                                color = mainMenuWhite
                            )
                        },
                        actions = {
                            // Пустое сердечко слева от сброса счётчика: создаёт фиолетовый дым на 1..5 сек
                            TextButton(
                                onClick = {
                                    smokeDurationSec = Random.nextInt(1, 6)
                                    smokeTriggerId += 1
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "♡",
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (smokeDurationSec > 0) Color(0xFFC084FC) else mainMenuWhite
                                )
                            }
                            // Сброс счётчика с подтверждением "Вы уверены?"
                            TextButton(onClick = { showResetCounterConfirmDialog = true }) {
                                Text(
                                    text = "Сброс счётчика",
                                    fontWeight = FontWeight.SemiBold,
                                    color = mainMenuWhite
                                )
                            }
                            TextButton(onClick = { showSettingsDialog = true }) {
                                Text(
                                    text = "Настройки",
                                    fontWeight = FontWeight.SemiBold,
                                    color = mainMenuWhite
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFF0A0F1C),
                            titleContentColor = mainMenuWhite
                        )
                    )
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AnimatedVisibility(
                        visible = showTimerFinishedBanner && (state.mode == PadMode.SCHOOL || state.mode == PadMode.CODING),
                        enter = if (smooth) fadeIn(animationSpec = tween(animDuration)) else fadeIn(animationSpec = snap()),
                        exit = if (smooth) fadeOut(animationSpec = tween(animDuration)) else fadeOut(animationSpec = snap())
                    ) {
                        val bannerMessage = when (state.mode) {
                            PadMode.CODING -> "Таймер закончился. Пора отдохнуть."
                            else -> "Урок кончился? Есть что записать? Я здесь."
                        }
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.78f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.36f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Таймер завершён (${state.mode.label})",
                                        fontWeight = FontWeight.Bold,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = bannerMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = mainMenuWhite
                                    )
                                }
                                TextButton(onClick = { showTimerFinishedBanner = false }) {
                                    Text("ОК", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Стеклянная карточка статуса + счётчик
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            animatedAccent.copy(alpha = 0.22f),
                                            Color.White.copy(alpha = 0.06f)
                                        )
                                    )
                                )
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Режим: ${state.mode.label}",
                                    fontWeight = FontWeight.Bold,
                                    color = mainMenuWhite
                                )
                                val timerText = when {
                                    !state.mode.supportsTimer -> "Таймер: отключён"
                                    state.mode == PadMode.REST && state.remainingSeconds == 0 ->
                                        "Таймер: без таймера (00:00)"
                                    else -> "Таймер: ${formatSeconds(state.remainingSeconds)}"
                                }
                                Text(
                                    text = timerText,
                                    color = mainMenuWhite
                                )
                                Text(
                                    text = "Счётчик: +1 / -1 • Зажмите + или - (>2с) для таймера",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = mainMenuWhite.copy(alpha = 0.85f)
                                )
                            }

                            NeonHollowCounter(
                                value = state.counter,
                                neonColor = animatedAccent,
                                smoothAnimations = smooth,
                                breathScale = breathPulse
                            )
                        }
                    }

                    // Кнопка 1 и Кнопка 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ColoredGlassButton(
                            text = "1. Заметка",
                            tint = animatedAccent,
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = { showNoteDialog = true }
                        )

                        val canToggleTimer = state.mode.supportsTimer && state.remainingSeconds > 0
                        val timerLabel = when {
                            !state.mode.supportsTimer -> "2. Без таймера"
                            state.mode == PadMode.REST && state.remainingSeconds == 0 -> "2. Задать время"
                            state.isTimerRunning -> "2. Пауза"
                            else -> "2. Старт"
                        }
                        ColoredGlassButton(
                            text = timerLabel,
                            tint = Color(0xFF0EA5E9),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = {
                                if (canToggleTimer) {
                                    showTimerFinishedBanner = false
                                    updateAndSave {
                                        it.copy(
                                            isTimerRunning = !it.isTimerRunning,
                                            restTimerFinished = if (!it.isTimerRunning) false else it.restTimerFinished
                                        )
                                    }
                                } else if (state.mode == PadMode.REST) {
                                    showCustomRestDialog = true
                                }
                            }
                        )
                    }

                    // Кнопка 3: левая половина (+1 счётчик, удержание >2с накручивает таймер вверх),
                    // правая половина (-1 счётчик, удержание >2с накручивает таймер вниз) и Кнопка 4 (радиальное меню)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.72f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.44f),
                                                animatedAccent.copy(alpha = 0.20f)
                                            )
                                        )
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter + 1) }
                                                },
                                                onPress = {
                                                    holdingPlus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingPlus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                                VerticalDivider(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .padding(vertical = 12.dp),
                                    thickness = 1.dp,
                                    color = animatedAccent.copy(alpha = 0.55f)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter - 1) }
                                                },
                                                onPress = {
                                                    holdingMinus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingMinus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "-1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                            }
                        }

                        ColoredGlassButton(
                            text = "4. Меню",
                            tint = Color(0xFF8B5CF6),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = { showRadialMenu = true }
                        )
                    }

                    Text(
                        text = "Сохранённые записи (${state.notes.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = mainMenuWhite
                    )

                    if (state.notes.isEmpty()) {
                        Text(
                            text = "Пока пусто. Нажмите «1. Заметка», чтобы добавить запись.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = mainMenuWhite.copy(alpha = 0.82f)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(state.notes, key = { it.id }) { note ->
                                val noteMode = PadMode.fromName(note.modeName)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, noteMode.accent.copy(alpha = 0.55f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(
                                                        noteMode.accent.copy(alpha = 0.28f),
                                                        noteMode.accent.copy(alpha = 0.08f)
                                                    )
                                                )
                                            )
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 8.dp)
                                        ) {
                                            Text(
                                                text = "${note.timestamp}  •  ${noteMode.label}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = noteMode.buttonBrightText
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                text = note.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = mainMenuWhite
                                            )
                                        }
                                        TextButton(
                                            onClick = {
                                                updateAndSave { current ->
                                                    current.copy(notes = current.notes.filterNot { it.id == note.id })
                                                }
                                            }
                                        ) {
                                            Text(
                                                text = "Удалить",
                                                color = mainMenuWhite,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Оверлей фиолетового дыма поверх экрана при нажатии на сердечко
            if (smokeDurationSec > 0) {
                PurpleSmokeOverlay(
                    progress = smokeProgress,
                    triggerId = smokeTriggerId,
                    smoothAnimations = smooth
                )
            }
        }

        if (showResetCounterConfirmDialog) {
            GlassDialogWrapper(onDismiss = { showResetCounterConfirmDialog = false }) {
                Text(
                    text = "Вы уверены?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Счётчик будет сброшен до 0.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.88f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = { showResetCounterConfirmDialog = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Сбросить",
                        tint = animatedAccent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            updateAndSave { it.copy(counter = 0) }
                            showResetCounterConfirmDialog = false
                        }
                    )
                }
            }
        }

        if (showRadialMenu) {
            RadialFourWayDialog(
                currentMode = state.mode,
                onSelectMode = { chosen ->
                    showRadialMenu = false
                    applyModeSelection(chosen)
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showSettingsDialog) {
            GlassDialogWrapper(onDismiss = { showSettingsDialog = false }) {
                Text(
                    text = "Настройки",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Уведомления",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.notificationsEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(settings = it.settings.copy(notificationsEnabled = enabled))
                            }
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Вибрация (только Коддинг)",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.codingVibrationEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave {
                                it.copy(settings = it.settings.copy(codingVibrationEnabled = enabled))
                            }
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Плавные анимации",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.smoothAnimationsEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave {
                                it.copy(settings = it.settings.copy(smoothAnimationsEnabled = enabled))
                            }
                        }
                    )
                }

                // Реально работающий ползунок: задаёт темп дыхания интерфейса и скорость нарастания прокрутки таймера
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Темп анимаций и прокрутки",
                            color = mainMenuWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${state.settings.uiPacePercent.toInt()}%",
                            color = buttonTextColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = state.settings.uiPacePercent,
                        onValueChange = { newVal ->
                            updateAndSave {
                                it.copy(settings = it.settings.copy(uiPacePercent = newVal))
                            }
                        },
                        valueRange = 0f..100f
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Закрыть", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showCodingPresetDialog) {
            val presets = listOf(
                "30 мин" to 30 * 60,
                "1 ч" to 60 * 60,
                "1,5 ч" to 90 * 60,
                "2 ч" to 120 * 60
            )
            GlassDialogWrapper(onDismiss = { showCodingPresetDialog = false }) {
                Text(
                    text = "Коддинг — длительность",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Выберите интервал таймера",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                presets.forEach { (label, seconds) ->
                    ColoredGlassButton(
                        text = label,
                        tint = PadMode.CODING.accent,
                        textColor = PadMode.CODING.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.CODING,
                                    remainingSeconds = seconds,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCodingPresetDialog = false
                        }
                    )
                }
                TextButton(onClick = { showCodingPresetDialog = false }) {
                    Text("Оставить текущий", color = mainMenuWhite)
                }
            }
        }

        if (showCustomRestDialog) {
            GlassDialogWrapper(onDismiss = { showCustomRestDialog = false }) {
                Text(
                    text = "Отдых",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Режим работает без таймера, но при желании Вы можете задать своё время в минутах.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                OutlinedTextField(
                    value = customMinutesInput,
                    onValueChange = { value ->
                        customMinutesInput = value.filter { it.isDigit() }.take(3)
                    },
                    label = { Text("Минуты (опционально)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.REST,
                                    remainingSeconds = 0,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Без таймера", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Задать",
                        tint = PadMode.REST.accent,
                        textColor = PadMode.REST.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val mins = customMinutesInput.toIntOrNull()?.coerceIn(1, 720)
                            if (mins != null) {
                                updateAndSave(forceNotificationRecreate = true) {
                                    it.copy(
                                        mode = PadMode.REST,
                                        remainingSeconds = mins * 60,
                                        isTimerRunning = false,
                                        restTimerFinished = false
                                    )
                                }
                            }
                            showCustomRestDialog = false
                        }
                    )
                }
            }
        }

        if (showNoteDialog) {
            GlassDialogWrapper(onDismiss = { showNoteDialog = false }) {
                Text(
                    text = "Новая заметка (${state.mode.label})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                OutlinedTextField(
                    value = draftNote,
                    onValueChange = { draftNote = it },
                    placeholder = { Text("Короткая мысль или задача...") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    timestamp = stamp,
                                    text = clean,
                                    modeName = state.mode.name
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PurpleSmokeOverlay(
    progress: Float,
    triggerId: Int,
    smoothAnimations: Boolean
) {
    val palette = remember {
        listOf(
            Color(0xFF9333EA),
            Color(0xFFC084FC),
            Color(0xFF7E22CE),
            Color(0xFFA855F7)
        )
    }
    val particles = remember(triggerId) {
        val rng = Random(triggerId * 9973 + 17)
        List(18) { idx ->
            SmokeParticle(
                seed = rng.nextFloat() * 100f,
                baseXRatio = rng.nextFloat(),
                baseYRatio = 0.12f + rng.nextFloat() * 0.78f,
                radiusDp = 64f + rng.nextFloat() * 96f,
                driftX = (rng.nextFloat() - 0.5f) * 180f,
                driftY = -60f - rng.nextFloat() * 150f,
                color = palette[idx % palette.size]
            )
        }
    }

    // Плавное появление и растворение дыма (если плавные анимации выключены — более резкий ступенчатый спад)
    val envelope = if (smoothAnimations) {
        val fadeInT = (progress / 0.22f).coerceIn(0f, 1f)
        val fadeOutT = ((1f - progress) / 0.35f).coerceIn(0f, 1f)
        min(fadeInT, fadeOutT)
    } else {
        if (progress < 0.85f) 0.55f else 0f
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (envelope <= 0.01f) return@Canvas
        particles.forEach { p ->
            val phase = p.seed + progress * 4.5f
            val dx = p.driftX * progress + sin(phase.toDouble()).toFloat() * 24f
            val dy = p.driftY * progress + cos((phase * 0.7f).toDouble()).toFloat() * 18f
            val cx = (size.width * p.baseXRatio + dx).coerceIn(0f, size.width)
            val cy = (size.height * p.baseYRatio + dy).coerceIn(0f, size.height)
            val radPx = p.radiusDp.dp.toPx() * (0.85f + progress * 0.35f)
            val alpha = (0.30f * envelope).coerceIn(0f, 0.45f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.color.copy(alpha = alpha),
                        p.color.copy(alpha = alpha * 0.45f),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = radPx
                ),
                radius = radPx,
                center = Offset(cx, cy)
            )
        }
    }
}

@Composable
private fun ColoredGlassButton(
    text: String,
    tint: Color,
    textColor: Color = Color.White,
    smoothAnimations: Boolean = true,
    animDuration: Int = 260,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale = if (smoothAnimations) {
        animateFloatAsState(
            targetValue = if (pressed) 0.96f else 1f,
            animationSpec = tween(durationMillis = max(80, animDuration / 2)),
            label = "btnScale"
        ).value
    } else {
        1f
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.72f)),
        modifier = modifier
            .scale(scale)
            .pointerInput(smoothAnimations) {
                if (smoothAnimations) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    )
                } else {
                    pressed = false
                }
            }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            tint.copy(alpha = 0.44f),
                            tint.copy(alpha = 0.20f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            )
        }
    }
}

@Composable
private fun NeonHollowCounter(
    value: Int,
    neonColor: Color,
    smoothAnimations: Boolean = true,
    breathScale: Float = 1f
) {
    val isNegative = value < 0
    val absDigits = abs(value).toString()
    val fontSize = 44.sp
    val animatedScale = if (smoothAnimations) {
        animateFloatAsState(
            targetValue = breathScale,
            animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
            label = "counterScale"
        ).value
    } else {
        1f
    }

    Box(
        modifier = Modifier.scale(animatedScale),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(width = 128.dp, height = 64.dp)) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        neonColor.copy(alpha = 0.24f),
                        neonColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = size.minDimension * 0.85f
                ),
                radius = size.minDimension * 0.85f,
                center = Offset(size.width / 2f, size.height / 2f)
            )
        }

        Row(
            modifier = Modifier.padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            if (isNegative) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "-",
                        style = TextStyle(
                            fontSize = fontSize,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF060911),
                            drawStyle = Stroke(width = 4.5f, join = StrokeJoin.Round)
                        )
                    )
                    Text(
                        text = "-",
                        style = TextStyle(
                            fontSize = fontSize,
                            fontWeight = FontWeight.ExtraBold,
                            color = neonColor,
                            drawStyle = Stroke(width = 2.0f, join = StrokeJoin.Round)
                        )
                    )
                }
            }

            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = absDigits,
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF060911),
                        drawStyle = Stroke(width = 4.5f, join = StrokeJoin.Round)
                    )
                )
                Text(
                    text = absDigits,
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = neonColor,
                        drawStyle = Stroke(width = 2.0f, join = StrokeJoin.Round)
                    )
                )
            }
        }
    }
}

@Composable
private fun GlassDialogWrapper(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF1E293B).copy(alpha = 0.88f),
                                Color(0xFF0F172A).copy(alpha = 0.92f)
                            )
                        )
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun RadialFourWayDialog(
    currentMode: PadMode,
    onSelectMode: (PadMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sectors = listOf(PadMode.SCHOOL, PadMode.CODING, PadMode.REST, PadMode.SLEEP)
    val startAngle = -135f
    val sweepAngle = 90f

    GlassDialogWrapper(onDismiss = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Выбор активности",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = currentMode.inverseNeonText
            )
            Text(
                text = "Тапните по сектору круга",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1)
            )

            BoxWithConstraints(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                val labelRadiusDp = (maxWidth.value * 0.31f)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(sectors) {
                            detectTapGestures { tap ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tap.x - center.x
                                val dy = tap.y - center.y
                                val r = min(size.width, size.height) / 2f
                                val innerHole = r * 0.20f
                                val dist = sqrt(dx * dx + dy * dy)

                                if (dist in innerHole..r) {
                                    val deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                    var rel = (deg - startAngle) % 360f
                                    if (rel < 0f) rel += 360f
                                    val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                    onSelectMode(sectors[index])
                                }
                            }
                        }
                ) {
                    val diameter = min(size.width, size.height)
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    sectors.forEachIndexed { idx, mode ->
                        val sectorStart = startAngle + idx * sweepAngle
                        val isSelected = mode == currentMode
                        drawArc(
                            color = mode.accent.copy(alpha = if (isSelected) 0.90f else 0.52f),
                            startAngle = sectorStart,
                            sweepAngle = sweepAngle,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                    }

                    val outerRadius = diameter / 2f
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)
                    for (i in sectors.indices) {
                        val rad = ((startAngle + i * sweepAngle) * PI / 180.0).toFloat()
                        val endPt = Offset(
                            x = centerOffset.x + outerRadius * cos(rad),
                            y = centerOffset.y + outerRadius * sin(rad)
                        )
                        drawLine(
                            color = Color(0xFF0A0F1C),
                            start = centerOffset,
                            end = endPt,
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    val activeIdx = sectors.indexOf(currentMode).coerceAtLeast(0)
                    drawArc(
                        color = Color.White,
                        startAngle = startAngle + activeIdx * sweepAngle,
                        sweepAngle = sweepAngle,
                        useCenter = true,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
                    )

                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = diameter * 0.11f
                    )
                }

                sectors.forEachIndexed { idx, mode ->
                    val midAngleRad = ((startAngle + idx * sweepAngle + sweepAngle / 2f) * PI / 180.0)
                    val offsetX = (labelRadiusDp * cos(midAngleRad)).dp
                    val offsetY = (labelRadiusDp * sin(midAngleRad)).dp
                    Text(
                        text = mode.label,
                        fontWeight = FontWeight.Bold,
                        color = mode.inverseNeonText,
                        modifier = Modifier.offset(x = offsetX, y = offsetY)
                    )
                }
            }

            TextButton(onClick = onDismiss) {
                Text("Закрыть", color = Color(0xFFCBD5E1))
            }
        }
    }
}

private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
