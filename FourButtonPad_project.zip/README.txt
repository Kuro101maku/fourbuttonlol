FourButtonPad — Android Studio project

MainActivity.kt is copied from the supplied MainActivity.kt.txt without changing its source contents.

To build:
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

The APK could not be built in this environment because Android SDK and Gradle are not installed here.
