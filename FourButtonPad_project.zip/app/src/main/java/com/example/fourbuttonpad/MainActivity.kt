package com.example.fourbuttonpad

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.min
import kotlin.math.sqrt

data class QuickNote(
    val id: Long,
    val time: String,
    val text: String
)

enum class PadMode(val label: String, val accent: Color) {
    WORK("Работа", Color(0xFF3B82F6)),
    REST("Отдых", Color(0xFF10B981)),
    IDEA("Идея", Color(0xFFF59E0B))
}

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.WORK,
    val remainingSeconds: Int = 15 * 60,
    val isTimerRunning: Boolean = false,
    val notes: List<QuickNote> = emptyList()
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val modeName = obj.optString("mode", PadMode.WORK.name)
            val mode = runCatching { PadMode.valueOf(modeName) }.getOrDefault(PadMode.WORK)
            val remainingSeconds = obj.optInt("remainingSeconds", 15 * 60).coerceAtLeast(0)
            val isTimerRunning = obj.optBoolean("isTimerRunning", false)

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            time = item.optString("time", "--:--"),
                            text = item.optString("text", "")
                        )
                    )
                }
            }

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                notes = notes
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("time", n.time)
                        put("text", n.text)
                    }
                )
            }
            put("notes", arr)
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()

        setContent {
            FourButtonPadApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FourButtonPadApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var draftNote by remember { mutableStateOf("") }

    fun updateAndSave(transform: (PadMemoryState) -> PadMemoryState) {
        val next = transform(state)
        state = next
        onPersist(next)
    }

    // Без звука: таймер работает молча и сохраняет остаток секунд
    LaunchedEffect(state.isTimerRunning) {
        while (state.isTimerRunning) {
            delay(1000L)
            updateAndSave { current ->
                if (!current.isTimerRunning) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    current.copy(remainingSeconds = 15 * 60, isTimerRunning = false)
                }
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = state.mode.accent,
        onPrimary = Color(0xFF090D16),
        background = Color(0xFF0B1120),
        onBackground = Color(0xFFE2E8F0),
        surface = Color(0xFF131C31),
        onSurface = Color(0xFFE2E8F0),
        surfaceVariant = Color(0xFF1E293B),
        onSurfaceVariant = Color(0xFF94A3B8)
    )

    MaterialTheme(colorScheme = darkScheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("Быстрый пульт", fontWeight = FontWeight.SemiBold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF111827),
                        titleContentColor = Color(0xFFF8FAFC)
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Режим: ${state.mode.label}",
                                fontWeight = FontWeight.Bold,
                                color = state.mode.accent
                            )
                            Text(
                                text = "Таймер: ${formatSeconds(state.remainingSeconds)}",
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${state.counter}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = state.mode.accent
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showNoteDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text("1. Заметка")
                    }
                    Button(
                        onClick = {
                            updateAndSave { it.copy(isTimerRunning = !it.isTimerRunning) }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text(if (state.isTimerRunning) "2. Пауза" else "2. Старт")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            updateAndSave { it.copy(counter = it.counter + 1) }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text("3. Счёт +1")
                    }
                    Button(
                        onClick = { showRadialMenu = true },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = Color(0xFFF8FAFC)
                        ),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text("4. Меню")
                    }
                }

                Text(
                    text = "Сохранённые записи (${state.notes.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (state.notes.isEmpty()) {
                    Text(
                        text = "Пока пусто. Нажми «1. Заметка», чтобы добавить запись.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.notes, key = { it.id }) { note ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = note.time,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = state.mode.accent
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = note.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showRadialMenu) {
            RadialThreeWayDialog(
                currentMode = state.mode,
                onSelectMode = { chosen ->
                    updateAndSave { it.copy(mode = chosen) }
                    showRadialMenu = false
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showNoteDialog) {
            AlertDialog(
                onDismissRequest = { showNoteDialog = false },
                containerColor = MaterialTheme.colorScheme.surface,
                title = { Text("Новая заметка") },
                text = {
                    OutlinedTextField(
                        value = draftNote,
                        onValueChange = { draftNote = it },
                        placeholder = { Text("Короткая мысль или задача...") },
                        singleLine = false,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    time = stamp,
                                    text = clean
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена")
                    }
                }
            )
        }
    }
}

@Composable
private fun RadialThreeWayDialog(
    currentMode: PadMode,
    onSelectMode: (PadMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sectors = listOf(PadMode.WORK, PadMode.REST, PadMode.IDEA)
    val startAngle = -90f
    val sweepAngle = 360f / sectors.size

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Выбор режима",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF8FAFC)
                )
                Text(
                    text = "Тапни по сектору диаграммы",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )

                Box(
                    modifier = Modifier.size(250.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(sectors) {
                                detectTapGestures { tap ->
                                    val center = Offset(size.width / 2f, size.height / 2f)
                                    val dx = tap.x - center.x
                                    val dy = tap.y - center.y
                                    val radius = min(size.width, size.height) / 2f
                                    val innerHole = radius * 0.28f
                                    val dist = sqrt(dx * dx + dy * dy)

                                    if (dist in innerHole..radius) {
                                        var deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                        var rel = (deg - startAngle) % 360f
                                        if (rel < 0f) rel += 360f
                                        val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                        onSelectMode(sectors[index])
                                    }
                                }
                            }
                    ) {
                        val diameter = min(size.width, size.height)
                        val topLeft = Offset(
                            (size.width - diameter) / 2f,
                            (size.height - diameter) / 2f
                        )
                        val arcSize = Size(diameter, diameter)

                        sectors.forEachIndexed { idx, mode ->
                            val sectorStart = startAngle + idx * sweepAngle
                            val isSelected = mode == currentMode
                            drawArc(
                                color = mode.accent.copy(alpha = if (isSelected) 0.92f else 0.45f),
                                startAngle = sectorStart,
                                sweepAngle = sweepAngle - 2f,
                                useCenter = true,
                                topLeft = topLeft,
                                size = arcSize
                            )
                            if (isSelected) {
                                drawArc(
                                    color = Color(0xFFF8FAFC),
                                    startAngle = sectorStart,
                                    sweepAngle = sweepAngle - 2f,
                                    useCenter = true,
                                    topLeft = topLeft,
                                    size = arcSize,
                                    style = Stroke(width = 3.dp.toPx())
                                )
                            }
                        }

                        drawCircle(
                            color = Color(0xFF111827),
                            radius = diameter * 0.14f
                        )
                    }

                    // Подписи секторов для удобного тапа
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = PadMode.WORK.label,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(top = 34.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 28.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = PadMode.IDEA.label,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = PadMode.REST.label,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                TextButton(onClick = onDismiss) {
                    Text("Закрыть", color = Color(0xFF94A3B8))
                }
            }
        }
    }
}

private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
