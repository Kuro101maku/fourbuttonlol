package com.example.fourbuttonpad

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class QuickNote(
    val id: Long,
    val timestamp: String,
    val text: String,
    val modeName: String = PadMode.SCHOOL.name
)

data class NotebookEntry(
    val id: Long,
    val title: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val timestamp: String = ""
)

enum class PadMode(
    val label: String,
    val accent: Color,
    val inverseNeonText: Color,
    val buttonBrightText: Color,
    val defaultSeconds: Int?,
    val supportsTimer: Boolean
) {
    SCHOOL(
        label = "Школа",
        accent = Color(0xFFE11D48),
        inverseNeonText = Color(0xFF5EEAD4),
        buttonBrightText = Color(0xFFFFA3B5),
        defaultSeconds = 40 * 60,
        supportsTimer = true
    ),
    CODING(
        label = "Коддинг",
        accent = Color(0xFF9333EA),
        inverseNeonText = Color(0xFFBEF264),
        buttonBrightText = Color(0xFFD8B4FE),
        defaultSeconds = 60 * 60,
        supportsTimer = true
    ),
    REST(
        label = "Отдых",
        accent = Color(0xFF84CC16),
        inverseNeonText = Color(0xFFC084FC),
        buttonBrightText = Color(0xFFD9F99D),
        defaultSeconds = null,
        supportsTimer = true
    ),
    SLEEP(
        label = "Сон",
        accent = Color(0xFF93C5FD),
        inverseNeonText = Color(0xFFFDE68A),
        buttonBrightText = Color(0xFFDBEAFE),
        defaultSeconds = null,
        supportsTimer = false
    ),
    EMPTY(
        label = "Пусто",
        accent = Color(0xFF64748B),
        inverseNeonText = Color(0xFFE2E8F0),
        buttonBrightText = Color(0xFFF1F5F9),
        defaultSeconds = null,
        supportsTimer = false
    ),
    DASH(
        label = "—",
        accent = Color(0xFF475569),
        inverseNeonText = Color(0xFFCBD5E1),
        buttonBrightText = Color(0xFFE2E8F0),
        defaultSeconds = null,
        supportsTimer = false
    ),
    DEADLINE(
        label = "Дедлайн",
        accent = Color(0xFFF97316),
        inverseNeonText = Color(0xFF38BDF8),
        buttonBrightText = Color(0xFFFDBA74),
        defaultSeconds = null,
        supportsTimer = true
    );

    companion object {
        fun fromName(name: String?): PadMode {
            if (name == "STUDY") return SCHOOL
            return runCatching { valueOf(name ?: "") }.getOrDefault(SCHOOL)
        }
    }
}

data class AppSettings(
    val notificationsEnabled: Boolean = true,
    val codingVibrationEnabled: Boolean = true,
    val smoothAnimationsEnabled: Boolean = true,
    // Реально работающий ползунок: задаёт темп/интенсивность дыхания UI (0..100), влияет на скорость пульсации и шаг прокрутки
    val uiPacePercent: Float = 50f,
    // 4-конечный ползунок оформления фона (1..4): 1 — исходный космос, 2–3 — тематика космос в фиолетовых тонах, 4 — тематика код в фиолетовых тонах
    val backgroundTheme: Int = 1
)

data class CustomAutoReminder(
    val id: Long,
    val text: String,
    val hour: Int, // 0..23
    val minute: Int, // 0..59
    val daysOfWeek: Set<Int>, // java.util.Calendar.MONDAY..SUNDAY (1..7)
    val enabled: Boolean = true,
    val lastTriggeredKey: String = ""
)

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.SCHOOL,
    val remainingSeconds: Int = 40 * 60,
    val isTimerRunning: Boolean = false,
    val restTimerFinished: Boolean = false,
    val schoolFinishedDateKey: String = "",
    val deadlineHour: Int = 18,
    val deadlineMinute: Int = 0,
    val deadlineActive: Boolean = false,
    val deadlineTriggeredKey: String = "",
    val notes: List<QuickNote> = emptyList(),
    val notebookEntries: List<NotebookEntry> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val customReminders: List<CustomAutoReminder> = emptyList(),
    val gameBestScore: Int = 0
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val mode = PadMode.fromName(obj.optString("mode", PadMode.SCHOOL.name))
            val defaultSec = mode.defaultSeconds ?: 0
            val remainingSeconds = obj.optInt("remainingSeconds", defaultSec).coerceAtLeast(0)
            val isTimerRunning = if (mode.supportsTimer) obj.optBoolean("isTimerRunning", false) else false
            val restTimerFinished = if (mode == PadMode.REST) obj.optBoolean("restTimerFinished", false) else false
            val schoolFinishedDateKey = obj.optString("schoolFinishedDateKey", "")
            val deadlineHour = obj.optInt("deadlineHour", 18).coerceIn(6, 23)
            val rawDeadlineMin = obj.optInt("deadlineMinute", 0)
            val deadlineMinute = if (rawDeadlineMin in listOf(0, 15, 30, 45)) rawDeadlineMin else 0
            val deadlineActive = obj.optBoolean("deadlineActive", false)
            val deadlineTriggeredKey = obj.optString("deadlineTriggeredKey", "")

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    val rawStamp = item.optString("timestamp", "").ifBlank {
                        item.optString("time", "01.01.26, 00:00")
                    }
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            timestamp = rawStamp,
                            text = item.optString("text", ""),
                            modeName = PadMode.fromName(item.optString("modeName", mode.name)).name
                        )
                    )
                }
            }

            val settingsObj = obj.optJSONObject("settings") ?: JSONObject()
            val settings = AppSettings(
                notificationsEnabled = settingsObj.optBoolean("notificationsEnabled", true),
                codingVibrationEnabled = settingsObj.optBoolean("codingVibrationEnabled", true),
                smoothAnimationsEnabled = settingsObj.optBoolean("smoothAnimationsEnabled", true),
                uiPacePercent = settingsObj.optDouble("uiPacePercent", 50.0).toFloat().coerceIn(0f, 100f),
                backgroundTheme = settingsObj.optInt("backgroundTheme", 1).coerceIn(1, 4)
            )

            val remindersJson = obj.optJSONArray("customReminders") ?: JSONArray()
            val customReminders = buildList {
                for (i in 0 until remindersJson.length()) {
                    val rObj = remindersJson.optJSONObject(i) ?: continue
                    val daysArr = rObj.optJSONArray("daysOfWeek") ?: JSONArray()
                    val daysSet = buildSet {
                        for (d in 0 until daysArr.length()) {
                            val dayVal = daysArr.optInt(d, -1)
                            if (dayVal in java.util.Calendar.SUNDAY..java.util.Calendar.SATURDAY) {
                                add(dayVal)
                            }
                        }
                    }
                    add(
                        CustomAutoReminder(
                            id = rObj.optLong("id", System.currentTimeMillis() + i),
                            text = rObj.optString("text", ""),
                            hour = rObj.optInt("hour", 9).coerceIn(0, 23),
                            minute = rObj.optInt("minute", 0).coerceIn(0, 59),
                            daysOfWeek = daysSet,
                            enabled = rObj.optBoolean("enabled", true),
                            lastTriggeredKey = rObj.optString("lastTriggeredKey", "")
                        )
                    )
                }
            }

            val nbJson = obj.optJSONArray("notebookEntries") ?: JSONArray()
            val notebookEntries = buildList {
                for (i in 0 until nbJson.length()) {
                    val item = nbJson.optJSONObject(i) ?: continue
                    val created = item.optLong("createdAt", System.currentTimeMillis() + i)
                    val stamp = item.optString("timestamp", "").ifBlank {
                        SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date(created))
                    }
                    add(
                        NotebookEntry(
                            id = item.optLong("id", created),
                            title = item.optString("title", ""),
                            text = item.optString("text", ""),
                            createdAt = created,
                            timestamp = stamp
                        )
                    )
                }
            }

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                restTimerFinished = restTimerFinished,
                schoolFinishedDateKey = schoolFinishedDateKey,
                deadlineHour = deadlineHour,
                deadlineMinute = deadlineMinute,
                deadlineActive = deadlineActive,
                deadlineTriggeredKey = deadlineTriggeredKey,
                notes = notes,
                notebookEntries = notebookEntries,
                settings = settings,
                customReminders = customReminders,
                gameBestScore = obj.optInt("gameBestScore", 0).coerceAtLeast(0)
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)
            put("restTimerFinished", state.restTimerFinished)
            put("schoolFinishedDateKey", state.schoolFinishedDateKey)
            put("deadlineHour", state.deadlineHour)
            put("deadlineMinute", state.deadlineMinute)
            put("deadlineActive", state.deadlineActive)
            put("deadlineTriggeredKey", state.deadlineTriggeredKey)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("timestamp", n.timestamp)
                        put("text", n.text)
                        put("modeName", n.modeName)
                    }
                )
            }
            put("notes", arr)

            put(
                "settings",
                JSONObject().apply {
                    put("notificationsEnabled", state.settings.notificationsEnabled)
                    put("codingVibrationEnabled", state.settings.codingVibrationEnabled)
                    put("smoothAnimationsEnabled", state.settings.smoothAnimationsEnabled)
                    put("uiPacePercent", state.settings.uiPacePercent.toDouble())
                    put("backgroundTheme", state.settings.backgroundTheme.coerceIn(1, 4))
                }
            )

            val remindersArr = JSONArray()
            for (rem in state.customReminders) {
                remindersArr.put(
                    JSONObject().apply {
                        put("id", rem.id)
                        put("text", rem.text)
                        put("hour", rem.hour.coerceIn(0, 23))
                        put("minute", rem.minute.coerceIn(0, 59))
                        put("enabled", rem.enabled)
                        put("lastTriggeredKey", rem.lastTriggeredKey)
                        val daysJson = JSONArray()
                        for (d in rem.daysOfWeek.sorted()) {
                            daysJson.put(d)
                        }
                        put("daysOfWeek", daysJson)
                    }
                )
            }
            put("customReminders", remindersArr)
            val nbArr = JSONArray()
            for (entry in state.notebookEntries) {
                nbArr.put(
                    JSONObject().apply {
                        put("id", entry.id)
                        put("title", entry.title)
                        put("text", entry.text)
                        put("createdAt", entry.createdAt)
                        put("timestamp", entry.timestamp)
                    }
                )
            }
            put("notebookEntries", nbArr)
            put("gameBestScore", state.gameBestScore.coerceAtLeast(0))
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

object AlertHelper {
    const val CHANNEL_SCHOOL_NO_VIBRATE = "kuro_school_silent_v6"
    const val CHANNEL_CODING_VIBRATE = "kuro_coding_vibrate_v6"
    const val CHANNEL_ONGOING_QUIET = "kuro_ongoing_quiet_v6"

    private const val TIMER_DONE_ID = 1001
    const val ONGOING_STATUS_ID = 2001
    @Volatile
    private var lastOngoingContentKey: String? = null

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val schoolChannel = NotificationChannel(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Школа — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Школа с вибрацией"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 260L, 120L, 260L)
            }

            val codingChannel = NotificationChannel(
                CHANNEL_CODING_VIBRATE,
                "Коддинг — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Коддинг с вибрацией"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 300L, 150L, 300L)
            }

            val ongoingQuietChannel = NotificationChannel(
                CHANNEL_ONGOING_QUIET,
                "Напоминания и статус",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомления и напоминания с вибрацией при приходе"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 240L, 120L, 240L)
                setShowBadge(true)
            }

            manager.createNotificationChannel(schoolChannel)
            manager.createNotificationChannel(codingChannel)
            manager.createNotificationChannel(ongoingQuietChannel)
        }
    }

    private fun createReturnToAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags)
    }

    fun canNotify(context: Context, settings: AppSettings): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun isOngoingNotificationPresent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return runCatching {
                manager.activeNotifications.any { it.id == ONGOING_STATUS_ID }
            }.getOrDefault(false)
        }
        return false
    }

    fun showTimerDoneNotification(context: Context, mode: PadMode, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val (channelId, title, message, _) = when (mode) {
            PadMode.CODING -> Quadruple(
                CHANNEL_CODING_VIBRATE,
                "Помощник Куро — Коддинг",
                "Время кодинга вышло. Самое время сделать паузу.",
                true
            )
            PadMode.SCHOOL -> Quadruple(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Помощник Куро — Школа",
                "Урок завершился. Хотите что-то зафиксировать?",
                true
            )
            else -> return
        }

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1101)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 300L, 150L, 300L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun showDeadlineNotification(context: Context, targetTimeText: String, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1103)
        val notification = NotificationCompat.Builder(context, CHANNEL_CODING_VIBRATE)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle("Помощник Куро — Дедлайн")
            .setContentText("дедлайн ($targetTimeText)")
            .setStyle(NotificationCompat.BigTextStyle().bigText("дедлайн ($targetTimeText)"))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 300L, 150L, 300L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun showRestDoneExternalNotification(context: Context, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val message = "Пауза подошла к концу. Готовы вернуться к делам?"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1102)
        val notification = NotificationCompat.Builder(context, CHANNEL_SCHOOL_NO_VIBRATE)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle("Помощник Куро — Отдых")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 260L, 120L, 260L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    private fun createLargeStarBitmap(context: Context): android.graphics.Bitmap? {
        return runCatching {
            val sizePx = (96f * context.resources.displayMetrics.density).toInt().coerceAtLeast(192)
            val bmp = android.graphics.Bitmap.createBitmap(sizePx, sizePx, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            val bgPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#0A0F1C")
            }
            canvas.drawRoundRect(0f, 0f, sizePx.toFloat(), sizePx.toFloat(), sizePx * 0.24f, sizePx * 0.24f, bgPaint)

            val drawable = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_launcher_la_star)
            if (drawable != null) {
                val pad = (sizePx * 0.10f).toInt()
                drawable.setBounds(pad, pad, sizePx - pad, sizePx - pad)
                drawable.draw(canvas)
            }
            bmp
        }.getOrNull()
    }

    private fun resolveOngoingMessage(
        mode: PadMode,
        restTimerFinished: Boolean,
        schoolFinishedDateKey: String = ""
    ): String? {
        return when (mode) {
            PadMode.SCHOOL -> SchoolBellSchedule.evaluateNow(finishedDateKey = schoolFinishedDateKey).notificationText
            PadMode.SLEEP -> "Тихий час / сон. Не тревожу лишний раз."
            PadMode.REST -> {
                if (restTimerFinished) {
                    "Пауза подошла к концу. Готовы вернуться к делам?"
                } else {
                    "Отдыхайте без спешки — я никуда не тороплюсь."
                }
            }
            else -> null
        }
    }

    fun buildOngoingNotification(
        context: Context,
        mode: PadMode,
        restTimerFinished: Boolean,
        settings: AppSettings,
        schoolFinishedDateKey: String = ""
    ): android.app.Notification? {
        if (!canNotify(context, settings)) return null
        val message = resolveOngoingMessage(mode, restTimerFinished, schoolFinishedDateKey) ?: return null

        val title = "Помощник Куро — ${mode.label}"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 2101)
        val largeIcon = createLargeStarBitmap(context)
        return NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply {
                if (largeIcon != null) setLargeIcon(largeIcon)
            }
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setAutoCancel(false)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .build()
    }

    fun syncOngoingModeNotification(
        context: Context,
        mode: PadMode,
        restTimerFinished: Boolean,
        settings: AppSettings,
        schoolFinishedDateKey: String = "",
        forceRecreate: Boolean = false
    ) {
        if (!canNotify(context, settings)) {
            cancelOngoingNotification(context)
            return
        }

        val message = resolveOngoingMessage(mode, restTimerFinished, schoolFinishedDateKey)
        if (message == null) {
            cancelOngoingNotification(context)
            return
        }

        val contentKey = "${mode.name}|$message"
        val isPresent = isOngoingNotificationPresent(context)

        // Повторяем/создаём уведомление ТОЛЬКО если оно отсутствует в панели уведомлений
        // или если реально изменился режим/текст уведомления (но не при клике на счётчик)
        if (isPresent && !forceRecreate && lastOngoingContentKey == contentKey) {
            return
        }

        val notification = buildOngoingNotification(
            context = context,
            mode = mode,
            restTimerFinished = restTimerFinished,
            settings = settings,
            schoolFinishedDateKey = schoolFinishedDateKey
        ) ?: return
        lastOngoingContentKey = contentKey
        runCatching {
            NotificationManagerCompat.from(context).notify(ONGOING_STATUS_ID, notification)
        }
    }

    private const val SCHEDULED_REMINDER_ID = 3001
    private const val REST_IDLE_REMINDER_ID = 3002

    fun showScheduledReminderNotification(context: Context, title: String, message: String, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 3101)
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 260L, 120L, 260L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(SCHEDULED_REMINDER_ID, notification)
        }
    }

    fun showRestIdleReminderNotification(context: Context, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val message = "Вы в режиме отдыха уже целый час. Продолжим или сделаем паузу?"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 3102)
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle("Помощник Куро — Отдых")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 260L, 120L, 260L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(REST_IDLE_REMINDER_ID, notification)
        }
    }

    fun cancelOngoingNotification(context: Context) {
        lastOngoingContentKey = null
        runCatching {
            NotificationManagerCompat.from(context).cancel(ONGOING_STATUS_ID)
        }
    }

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D
    )
}

class ScheduledReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: return
        val store = MemoryStore(File(context.filesDir, "pad_memory.json"))
        val state = store.load()
        AlertHelper.ensureChannels(context)

        val cal = java.util.Calendar.getInstance()
        val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val isWeekday = dayOfWeek in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY

        when (kind) {
            ReminderScheduler.KIND_BEDTIME_2200 -> {
                AlertHelper.showScheduledReminderNotification(
                    context = context,
                    title = "Помощник Куро — Вечер",
                    message = "Уже 22:00 — самое время свернуть дела и выспаться.",
                    settings = state.settings
                )
                ReminderScheduler.scheduleNextBedtime(context)
            }
            ReminderScheduler.KIND_WAKE_0630 -> {
                if (isWeekday) {
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Утро",
                        message = "06:30 — подъём. Новый день стартует.",
                        settings = state.settings
                    )
                }
                ReminderScheduler.scheduleNextWeekdayWake(context)
            }
            ReminderScheduler.KIND_CUSTOM -> {
                val reminderId = intent.getLongExtra(ReminderScheduler.EXTRA_REMINDER_ID, -1L)
                val target = state.customReminders.firstOrNull { it.id == reminderId && it.enabled }
                if (target != null && dayOfWeek in target.daysOfWeek) {
                    val timeStr = String.format(Locale.getDefault(), "%02d:%02d", target.hour, target.minute)
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — $timeStr",
                        message = target.text.ifBlank { "Напоминание ($timeStr)" },
                        settings = state.settings
                    )
                    val triggerKey = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}-${target.hour}-${target.minute}"
                    val updatedList = state.customReminders.map {
                        if (it.id == target.id) it.copy(lastTriggeredKey = triggerKey) else it
                    }
                    store.save(state.copy(customReminders = updatedList))
                }
                ReminderScheduler.scheduleCustomReminders(context, state.customReminders)
            }
        }
    }
}

object ReminderScheduler {
    const val EXTRA_KIND = "reminder_kind"
    const val EXTRA_REMINDER_ID = "reminder_id"
    const val KIND_BEDTIME_2200 = "bedtime_2200"
    const val KIND_WAKE_0630 = "wake_0630"
    const val KIND_CUSTOM = "custom_reminder"

    private const val REQ_BEDTIME = 4101
    private const val REQ_WAKE = 4102
    private const val REQ_CUSTOM_BASE = 5000

    fun scheduleAll(context: Context, customReminders: List<CustomAutoReminder> = emptyList()) {
        scheduleNextBedtime(context)
        scheduleNextWeekdayWake(context)
        scheduleCustomReminders(context, customReminders)
    }

    fun scheduleCustomReminders(context: Context, reminders: List<CustomAutoReminder>) {
        val now = System.currentTimeMillis()
        for (rem in reminders) {
            val reqCode = REQ_CUSTOM_BASE + (kotlin.math.abs(rem.id.hashCode()) % 40000)
            if (!rem.enabled || rem.daysOfWeek.isEmpty()) {
                cancelAlarm(context, reqCode)
                continue
            }
            val target = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, rem.hour.coerceIn(0, 23))
                set(java.util.Calendar.MINUTE, rem.minute.coerceIn(0, 59))
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) {
                    add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                var guard = 0
                while (get(java.util.Calendar.DAY_OF_WEEK) !in rem.daysOfWeek && guard < 14) {
                    add(java.util.Calendar.DAY_OF_YEAR, 1)
                    guard++
                }
            }
            setAlarm(context, target.timeInMillis, reqCode, KIND_CUSTOM, rem.id)
        }
    }

    private fun cancelAlarm(context: Context, reqCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val intent = Intent(context, ScheduledReminderReceiver::class.java)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_NO_CREATE
        }
        val existing = PendingIntent.getBroadcast(context, reqCode, intent, flags)
        if (existing != null) {
            runCatching { alarmManager.cancel(existing) }
            existing.cancel()
        }
    }

    fun scheduleNextBedtime(context: Context) {
        val now = System.currentTimeMillis()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 22)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        }
        setAlarm(context, target.timeInMillis, REQ_BEDTIME, KIND_BEDTIME_2200)
    }

    fun scheduleNextWeekdayWake(context: Context) {
        val now = System.currentTimeMillis()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 6)
            set(java.util.Calendar.MINUTE, 30)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            while (get(java.util.Calendar.DAY_OF_WEEK) !in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        }
        setAlarm(context, target.timeInMillis, REQ_WAKE, KIND_WAKE_0630)
    }

    private fun setAlarm(
        context: Context,
        triggerAtMs: Long,
        reqCode: Int,
        kind: String,
        reminderId: Long = -1L
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val intent = Intent(context, ScheduledReminderReceiver::class.java).apply {
            putExtra(EXTRA_KIND, kind)
            if (reminderId != -1L) {
                putExtra(EXTRA_REMINDER_ID, reminderId)
            }
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pi = PendingIntent.getBroadcast(context, reqCode, intent, flags)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                alarmManager.set(android.app.AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        }
    }
}


data class SchoolBellSlot(
    val lessonNumber: Int?, // 1..8 для урока, null для перемены
    val isBreak: Boolean,
    val startMinutes: Int, // минуты от полуночи (0..1439)
    val endMinutes: Int,
    val weekdaysOnly8th: Boolean = false
)

enum class SchoolPhaseKind {
    BEFORE_FIRST,
    LESSON,
    BREAK,
    AFTER_SCHOOL,
    WEEKEND
}

data class SchoolBellStatus(
    val kind: SchoolPhaseKind,
    val lessonNumber: Int?, // 1..8 если идёт урок или следующая перемена относится к уроку
    val displayLessonCounter: Int, // 0..8
    val statusText: String,
    val notificationText: String,
    val countdownLabel: String?, // например: "До конца урока: 24:15" или "До конца перемены: 09:30"
    val dayNote: String
)

object SchoolBellSchedule {
    fun dayArrivalNote(dayOfWeek: Int): String = when (dayOfWeek) {
        java.util.Calendar.MONDAY -> "Пн: к 1-му уроку"
        java.util.Calendar.TUESDAY,
        java.util.Calendar.WEDNESDAY,
        java.util.Calendar.THURSDAY -> "Вт–Чт: ко 2-му уроку"
        java.util.Calendar.FRIDAY -> "Пт: к 1-му уроку"
        else -> "Выходной"
    }

    fun slotsForDay(dayOfWeek: Int): List<SchoolBellSlot> {
        val includeEighth = dayOfWeek in listOf(
            java.util.Calendar.TUESDAY,
            java.util.Calendar.WEDNESDAY,
            java.util.Calendar.THURSDAY
        )
        val base = mutableListOf(
            SchoolBellSlot(1, false, 7 * 60 + 58, 8 * 60 + 38),
            SchoolBellSlot(null, true, 8 * 60 + 38, 8 * 60 + 53),
            SchoolBellSlot(2, false, 8 * 60 + 53, 9 * 60 + 33),
            SchoolBellSlot(null, true, 9 * 60 + 33, 9 * 60 + 48),
            SchoolBellSlot(3, false, 9 * 60 + 48, 10 * 60 + 28),
            SchoolBellSlot(null, true, 10 * 60 + 28, 10 * 60 + 48),
            SchoolBellSlot(4, false, 10 * 60 + 48, 11 * 60 + 28),
            SchoolBellSlot(null, true, 11 * 60 + 28, 11 * 60 + 43),
            SchoolBellSlot(5, false, 11 * 60 + 43, 12 * 60 + 23),
            SchoolBellSlot(null, true, 12 * 60 + 23, 12 * 60 + 43),
            SchoolBellSlot(6, false, 12 * 60 + 43, 13 * 60 + 23),
            SchoolBellSlot(null, true, 13 * 60 + 23, 13 * 60 + 38),
            SchoolBellSlot(7, false, 13 * 60 + 38, 14 * 60 + 18)
        )
        if (includeEighth) {
            base.add(SchoolBellSlot(null, true, 14 * 60 + 18, 14 * 60 + 28, weekdaysOnly8th = true))
            base.add(SchoolBellSlot(8, false, 14 * 60 + 28, 15 * 60 + 8, weekdaysOnly8th = true))
        }
        return base
    }

    fun todayKey(cal: java.util.Calendar = java.util.Calendar.getInstance()): String {
        return "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}"
    }

    fun evaluateNow(
        cal: java.util.Calendar = java.util.Calendar.getInstance(),
        finishedDateKey: String = ""
    ): SchoolBellStatus {
        val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val arrivalNote = dayArrivalNote(dayOfWeek)
        if (finishedDateKey.isNotEmpty() && finishedDateKey == todayKey(cal)) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.AFTER_SCHOOL,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Уроков больше нет. $arrivalNote",
                notificationText = "Уроки окончены. На сегодня звонки всё, я рядом.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }
        val isWeekend = dayOfWeek == java.util.Calendar.SATURDAY || dayOfWeek == java.util.Calendar.SUNDAY
        if (isWeekend) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.WEEKEND,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Сегодня выходной. Уроков нет.",
                notificationText = "Сегодня выходной. Отдыхайте.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }

        val nowSecOfDay = cal.get(java.util.Calendar.HOUR_OF_DAY) * 3600 +
            cal.get(java.util.Calendar.MINUTE) * 60 +
            cal.get(java.util.Calendar.SECOND)
        val nowMin = nowSecOfDay / 60
        val slots = slotsForDay(dayOfWeek)
        val firstStartSec = slots.first().startMinutes * 60
        val lastEndSec = slots.last().endMinutes * 60

        if (nowSecOfDay < firstStartSec) {
            val remSec = (firstStartSec - nowSecOfDay).coerceAtLeast(0)
            return SchoolBellStatus(
                kind = SchoolPhaseKind.BEFORE_FIRST,
                lessonNumber = 1,
                displayLessonCounter = 0,
                statusText = "До начала уроков (07:58). $arrivalNote",
                notificationText = "Уроки ещё не начались ($arrivalNote). Готовимся к старту.",
                countdownLabel = "До 1-го урока: ${formatSeconds(remSec)}",
                dayNote = arrivalNote
            )
        }

        if (nowSecOfDay >= lastEndSec) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.AFTER_SCHOOL,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Уроки окончены. $arrivalNote",
                notificationText = "Уроки окончены. На сегодня звонки всё, я рядом.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }

        for (i in slots.indices) {
            val slot = slots[i]
            val slotStartSec = slot.startMinutes * 60
            val slotEndSec = slot.endMinutes * 60
            if (nowSecOfDay in slotStartSec until slotEndSec) {
                val remSec = (slotEndSec - nowSecOfDay).coerceAtLeast(0)
                return if (!slot.isBreak && slot.lessonNumber != null) {
                    val lessonNum = slot.lessonNumber.coerceIn(1, 8)
                    val msg = "Уберите телефон. Идёт $lessonNum-й урок."
                    SchoolBellStatus(
                        kind = SchoolPhaseKind.LESSON,
                        lessonNumber = lessonNum,
                        displayLessonCounter = lessonNum,
                        statusText = msg,
                        notificationText = msg,
                        countdownLabel = "До конца урока: ${formatSeconds(remSec)}",
                        dayNote = arrivalNote
                    )
                } else {
                    val nextLesson = slots.drop(i + 1).firstOrNull { !it.isBreak }?.lessonNumber
                    val msg = "Перемена. Можно выдохнуть и переключиться."
                    SchoolBellStatus(
                        kind = SchoolPhaseKind.BREAK,
                        lessonNumber = nextLesson,
                        displayLessonCounter = (nextLesson ?: 1).coerceIn(1, 8),
                        statusText = msg,
                        notificationText = msg,
                        countdownLabel = "До конца перемены: ${formatSeconds(remSec)}",
                        dayNote = arrivalNote
                    )
                }
            }
        }

        return SchoolBellStatus(
            kind = SchoolPhaseKind.AFTER_SCHOOL,
            lessonNumber = null,
            displayLessonCounter = 0,
            statusText = "Вне расписания звонков. $arrivalNote",
            notificationText = "Сейчас вне расписания звонков.",
            countdownLabel = null,
            dayNote = arrivalNote
        )
    }
}


class KuroForegroundService : android.app.Service() {
    private val scope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()
    )

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AlertHelper.ensureChannels(this)
        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initial = store.load()
        val notif = AlertHelper.buildOngoingNotification(
            context = this,
            mode = initial.mode,
            restTimerFinished = initial.restTimerFinished,
            settings = initial.settings,
            schoolFinishedDateKey = initial.schoolFinishedDateKey
        )
        if (notif != null) {
            runCatching {
                startForeground(AlertHelper.ONGOING_STATUS_ID, notif)
            }
        }

        scope.coroutineContext[kotlinx.coroutines.Job]?.cancelChildren()
        return START_STICKY
    }

    override fun onDestroy() {
        scope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        super.onDestroy()
    }
}

class MainActivity : ComponentActivity() {
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                val store = MemoryStore(File(filesDir, "pad_memory.json"))
                val loaded = store.load()
                AlertHelper.syncOngoingModeNotification(
                    context = this,
                    mode = loaded.mode,
                    restTimerFinished = loaded.restTimerFinished,
                    settings = loaded.settings,
                    schoolFinishedDateKey = loaded.schoolFinishedDateKey,
                    forceRecreate = false
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.ensureChannels(this)
        ReminderScheduler.scheduleAll(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()
        ReminderScheduler.scheduleCustomReminders(this, initialState.customReminders)
        AlertHelper.syncOngoingModeNotification(
            context = this,
            mode = initialState.mode,
            restTimerFinished = initialState.restTimerFinished,
            settings = initialState.settings,
            schoolFinishedDateKey = initialState.schoolFinishedDateKey,
            forceRecreate = false
        )

        setContent {
            KuroAssistantApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

private data class SmokeParticle(
    val seed: Float,
    val baseXRatio: Float,
    val baseYRatio: Float,
    val radiusDp: Float,
    val driftX: Float,
    val driftY: Float,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KuroAssistantApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var showCodingPresetDialog by remember { mutableStateOf(false) }
    var showCustomRestDialog by remember { mutableStateOf(false) }
    var showDeadlinePickerDialog by remember { mutableStateOf(false) }
    var showDeadlineBanner by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showResetCounterConfirmDialog by remember { mutableStateOf(false) }
    var showNoMoreLessonsConfirmDialog by remember { mutableStateOf(false) }
    var showCalculatorDialog by remember { mutableStateOf(false) }
    var showNotebookDialog by remember { mutableStateOf(false) }
    var showMiniGameDialog by remember { mutableStateOf(false) }
    var showTimerFinishedBanner by remember { mutableStateOf(false) }
    var showMiaBubble by remember { mutableStateOf(false) }
    var miaBubbleTriggerId by remember { mutableIntStateOf(0) }
    var draftNote by remember { mutableStateOf("") }
    var customMinutesInput by remember { mutableStateOf("15") }

    // Фиолетовый дым по нажатию на сердечко: случайная длительность от 1 до 5 секунд
    var smokeDurationSec by remember { mutableIntStateOf(0) }
    var smokeTriggerId by remember { mutableIntStateOf(0) }
    var smokeProgress by remember { mutableFloatStateOf(0f) }

    // Удержание кнопок + и - на таймере (старт автонакрутки после > 2 сек удержания)
    var holdingPlus by remember { mutableStateOf(false) }
    var holdingMinus by remember { mutableStateOf(false) }

    val smooth = state.settings.smoothAnimationsEnabled
    val paceFactor = (state.settings.uiPacePercent / 100f).coerceIn(0f, 1f)
    val animDuration = if (smooth) {
        max(120, (520f - paceFactor * 360f).toInt())
    } else {
        0
    }

    val mainMenuWhite = Color(0xFFF8FAFC)

    // При выключении "Плавные анимации" используем прямые значения без анимаций
    val animatedAccent: Color = if (smooth) {
        val c by animateColorAsState(
            targetValue = state.mode.accent,
            animationSpec = tween(durationMillis = animDuration, easing = FastOutSlowInEasing),
            label = "accentAnim"
        )
        c
    } else {
        state.mode.accent
    }

    val buttonTextColor: Color = if (smooth) {
        val c by animateColorAsState(
            targetValue = state.mode.buttonBrightText,
            animationSpec = tween(durationMillis = animDuration, easing = FastOutSlowInEasing),
            label = "btnBrightAnim"
        )
        c
    } else {
        state.mode.buttonBrightText
    }

    val breathPulse: Float = if (smooth) {
        val transition = rememberInfiniteTransition(label = "breathTransition")
        val periodMs = max(900, (3200f - paceFactor * 2100f).toInt())
        transition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = periodMs, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "breathScale"
        ).value
    } else {
        1f
    }

    LaunchedEffect(smooth) {
        if (!smooth) {
            smokeDurationSec = 0
            smokeProgress = 0f
        }
    }

    fun updateAndSave(
        syncNotification: Boolean = false,
        forceNotificationRecreate: Boolean = false,
        transform: (PadMemoryState) -> PadMemoryState
    ) {
        val prev = state
        val next = transform(prev)
        state = next
        onPersist(next)
        val modeOrStatusChanged = prev.mode != next.mode ||
            prev.restTimerFinished != next.restTimerFinished ||
            prev.schoolFinishedDateKey != next.schoolFinishedDateKey ||
            prev.settings.notificationsEnabled != next.settings.notificationsEnabled

        if (syncNotification || modeOrStatusChanged) {
            AlertHelper.syncOngoingModeNotification(
                context = context,
                mode = next.mode,
                restTimerFinished = next.restTimerFinished,
                settings = next.settings,
                schoolFinishedDateKey = next.schoolFinishedDateKey,
                forceRecreate = forceNotificationRecreate
            )
            runCatching {
                val svcIntent = Intent(context, KuroForegroundService::class.java)
                if (next.mode == PadMode.SCHOOL || next.mode == PadMode.SLEEP || next.mode == PadMode.REST || next.isTimerRunning) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(svcIntent)
                    } else {
                        context.startService(svcIntent)
                    }
                } else {
                    context.stopService(svcIntent)
                }
            }
        }
    }

    fun ensureRestModeSupportsTimer(current: PadMemoryState): PadMemoryState {
        return if (current.mode == PadMode.REST) {
            current.copy(restTimerFinished = false)
        } else {
            current
        }
    }

    fun applyModeSelection(chosen: PadMode) {
        when (chosen) {
            PadMode.SCHOOL -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SCHOOL,
                        remainingSeconds = 40 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
            }
            PadMode.CODING -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.CODING,
                        remainingSeconds = 60 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCodingPresetDialog = true
            }
            PadMode.REST -> {
                showTimerFinishedBanner = false
                restEnteredAtMs = System.currentTimeMillis()
                restIdleNotifiedForSession = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.REST,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCustomRestDialog = true
            }
            PadMode.SLEEP -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SLEEP,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                }
            }
            PadMode.EMPTY -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                updateAndSave(syncNotification = true) {
                    it.copy(
                        mode = PadMode.EMPTY,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                }
            }
            PadMode.DASH -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                updateAndSave(syncNotification = true) {
                    it.copy(
                        mode = PadMode.DASH,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                }
            }
            PadMode.DEADLINE -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                val cal = java.util.Calendar.getInstance()
                val curH = cal.get(java.util.Calendar.HOUR_OF_DAY)
                val curM = cal.get(java.util.Calendar.MINUTE)
                val nextQuarter = ((curM / 15) + 1) * 15
                val suggestedHour = (if (nextQuarter >= 60) curH + 1 else curH).coerceIn(6, 23)
                val suggestedMin = if (nextQuarter >= 60) 0 else nextQuarter
                updateAndSave(syncNotification = true) {
                    it.copy(
                        mode = PadMode.DEADLINE,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineHour = if (it.deadlineHour in 6..23) it.deadlineHour else suggestedHour,
                        deadlineMinute = if (it.deadlineMinute in listOf(0, 15, 30, 45)) it.deadlineMinute else suggestedMin
                    )
                }
                showDeadlinePickerDialog = true
            }
        }
    }

    // Бабл секретки "Любимая Мия<3" при зажатии сердечка
    LaunchedEffect(miaBubbleTriggerId) {
        if (miaBubbleTriggerId == 0 || !showMiaBubble) return@LaunchedEffect
        delay(3500L)
        showMiaBubble = false
    }

    // Таймер фиолетового дыма на 1..5 секунд
    LaunchedEffect(smokeTriggerId) {
        if (smokeTriggerId == 0 || smokeDurationSec <= 0) return@LaunchedEffect
        val totalMs = smokeDurationSec * 1000L
        val stepMs = 30L
        var elapsed = 0L
        smokeProgress = 0f
        while (elapsed < totalMs && isActive) {
            delay(stepMs)
            elapsed += stepMs
            smokeProgress = (elapsed.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
        }
        smokeProgress = 1f
        smokeDurationSec = 0
    }

    // Автонакрутка СЧЁТЧИКА при удержании + или - дольше 2 секунд:
    // рост плавный и читаемый человеком (начинается с малых шагов, затем нарастает без ухода в "скорость света")
    LaunchedEffect(holdingPlus, holdingMinus) {
        val activeDirection = when {
            holdingPlus && !holdingMinus -> 1
            holdingMinus && !holdingPlus -> -1
            else -> 0
        }
        if (activeDirection == 0) return@LaunchedEffect

        // Задержка перед стартом автонакрутки: 0.5 с (500 мс)
        delay(500L)
        while (isActive) {
            updateAndSave { current ->
                val cur = current.counter
                val nextCounter = if (cur == 0) {
                    activeDirection
                } else if ((activeDirection > 0 && cur > 0) || (activeDirection < 0 && cur < 0)) {
                    // Умножаем на 2 каждые 0.5с в сторону выбранного знака (+ или -)
                    (cur.toLong() * 2L).coerceIn(-999_999_999L, 999_999_999L).toInt()
                } else {
                    // Если текущий счётчик имеет противоположный знак (например, -8 при нажатии +),
                    // шагаем в сторону нуля/знака с удвоением шага, чтобы корректно перейти к положительным значениям
                    val absStep = max(1, (abs(cur.toLong()) / 2L).toInt())
                    (cur.toLong() + activeDirection.toLong() * absStep.toLong())
                        .coerceIn(-999_999_999L, 999_999_999L).toInt()
                }
                current.copy(counter = nextCounter)
            }
            delay(500L)
        }
    }

    var lastTriggeredClockKey by remember { mutableStateOf("") }
    var restEnteredAtMs by remember {
        mutableStateOf(if (initialState.mode == PadMode.REST) System.currentTimeMillis() else 0L)
    }
    var restIdleNotifiedForSession by remember { mutableStateOf(false) }
    var secretMessage by remember { mutableStateOf<String?>(null) }
    var secretTriggerId by remember { mutableIntStateOf(0) }

    // Исчезновение секретной фразы через несколько секунд (3.5 сек)
    LaunchedEffect(secretTriggerId) {
        if (secretTriggerId == 0 || secretMessage == null) return@LaunchedEffect
        delay(3500L)
        secretMessage = null
    }

    // Отслеживание времени нахождения в режиме Отдых (1 час = 3600_000 мс), только если таймер не включён
    LaunchedEffect(state.mode, state.isTimerRunning, state.settings.notificationsEnabled) {
        if (state.mode != PadMode.REST) {
            restEnteredAtMs = 0L
            restIdleNotifiedForSession = false
            return@LaunchedEffect
        }
        if (restEnteredAtMs == 0L) {
            restEnteredAtMs = System.currentTimeMillis()
        }
        while (isActive && state.mode == PadMode.REST) {
            if (!state.isTimerRunning && !restIdleNotifiedForSession) {
                val elapsedMs = System.currentTimeMillis() - restEnteredAtMs
                if (elapsedMs >= 3_600_000L) {
                    restIdleNotifiedForSession = true
                    AlertHelper.showRestIdleReminderNotification(context, state.settings)
                }
            }
            delay(15_000L)
        }
    }

    // Проверка совпадения системного времени с установленным дедлайном (часы 6..23, шаг 15 минут)
    LaunchedEffect(
        state.mode,
        state.deadlineActive,
        state.deadlineHour,
        state.deadlineMinute,
        state.deadlineTriggeredKey,
        state.settings.notificationsEnabled
    ) {
        while (isActive && state.mode == PadMode.DEADLINE && state.deadlineActive) {
            val cal = java.util.Calendar.getInstance()
            val curH = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val curM = cal.get(java.util.Calendar.MINUTE)
            val minuteKey = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}-$curH-$curM"

            if (curH == state.deadlineHour && curM == state.deadlineMinute && state.deadlineTriggeredKey != minuteKey) {
                val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", state.deadlineHour, state.deadlineMinute)
                AlertHelper.showDeadlineNotification(context, formattedTime, state.settings)
                showDeadlineBanner = true
                updateAndSave {
                    it.copy(
                        deadlineActive = false,
                        deadlineTriggeredKey = minuteKey
                    )
                }
            }
            delay(1000L)
        }
    }

    // Системное расписание: 22:00 ежедневно ("Сон важен...") и 06:30 по будням ("06:30 — подъём. Новый день стартует.")
    LaunchedEffect(state.settings.notificationsEnabled) {
        while (isActive) {
            val cal = java.util.Calendar.getInstance()
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val minute = cal.get(java.util.Calendar.MINUTE)
            val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
            val isWeekday = dayOfWeek in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY

            val slotKey = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}-$hour-$minute"
            if (slotKey != lastTriggeredClockKey) {
                if (hour == 22 && minute == 0) {
                    lastTriggeredClockKey = slotKey
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Вечер",
                        message = "Уже 22:00 — самое время свернуть дела и выспаться.",
                        settings = state.settings
                    )
                } else if (hour == 6 && minute == 30 && isWeekday) {
                    lastTriggeredClockKey = slotKey
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Утро",
                        message = "06:30 — подъём. Новый день стартует.",
                        settings = state.settings
                    )
                }
            }

            if (state.customReminders.isNotEmpty()) {
                val matchedIds = state.customReminders
                    .filter { rem ->
                        rem.enabled &&
                            dayOfWeek in rem.daysOfWeek &&
                            rem.hour == hour &&
                            rem.minute == minute &&
                            rem.lastTriggeredKey != slotKey
                    }
                    .map { it.id }
                if (matchedIds.isNotEmpty()) {
                    val matchedSet = matchedIds.toSet()
                    state.customReminders.filter { it.id in matchedSet }.forEach { rem ->
                        val tStr = String.format(Locale.getDefault(), "%02d:%02d", rem.hour, rem.minute)
                        AlertHelper.showScheduledReminderNotification(
                            context = context,
                            title = "Помощник Куро — $tStr",
                            message = rem.text.ifBlank { "Напоминание ($tStr)" },
                            settings = state.settings
                        )
                    }
                    updateAndSave { cur ->
                        cur.copy(
                            customReminders = cur.customReminders.map { r ->
                                if (r.id in matchedSet) r.copy(lastTriggeredKey = slotKey) else r
                            }
                        )
                    }
                }
            }
            delay(10_000L)
        }
    }

    // Проверка на удаление постоянного уведомления Школы/Сна/Отдыха из панели:
    // повторяется ТОЛЬКО при удалении уведомления или его отсутствии в панели уведомлений
    LaunchedEffect(state.mode, state.restTimerFinished, state.schoolFinishedDateKey, state.settings.notificationsEnabled) {
        while (state.mode == PadMode.SCHOOL || state.mode == PadMode.SLEEP || state.mode == PadMode.REST) {
            if (!AlertHelper.isOngoingNotificationPresent(context)) {
                AlertHelper.syncOngoingModeNotification(
                    context = context,
                    mode = state.mode,
                    restTimerFinished = state.restTimerFinished,
                    settings = state.settings,
                    schoolFinishedDateKey = state.schoolFinishedDateKey,
                    forceRecreate = true
                )
            }
            delay(4000L)
        }
    }

    LaunchedEffect(state.isTimerRunning, state.mode) {
        while (state.isTimerRunning && state.mode.supportsTimer && state.remainingSeconds > 0) {
            delay(1000L)
            var reachedZero = false
            var finishedMode = state.mode
            var currentSettings = state.settings
            var recreateOngoing = false
            updateAndSave(forceNotificationRecreate = false) { current ->
                finishedMode = current.mode
                currentSettings = current.settings
                if (!current.isTimerRunning || !current.mode.supportsTimer) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    reachedZero = true
                    if (current.mode == PadMode.REST) {
                        recreateOngoing = true
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = true
                        )
                    } else {
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = false
                        )
                    }
                }
            }
            if (recreateOngoing) {
                AlertHelper.syncOngoingModeNotification(
                    context = context,
                    mode = finishedMode,
                    restTimerFinished = true,
                    settings = currentSettings,
                    forceRecreate = true
                )
            }
            if (reachedZero) {
                if (finishedMode == PadMode.SCHOOL || finishedMode == PadMode.CODING) {
                    showTimerFinishedBanner = true
                    AlertHelper.showTimerDoneNotification(context, finishedMode, currentSettings)
                } else if (finishedMode == PadMode.REST) {
                    AlertHelper.showRestDoneExternalNotification(context, currentSettings)
                }
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = animatedAccent,
        onPrimary = Color(0xFF060911),
        background = Color(0xFF060911),
        onBackground = mainMenuWhite,
        surface = Color(0xFF0E1525),
        onSurface = mainMenuWhite,
        surfaceVariant = Color(0xFF1A2438),
        onSurfaceVariant = Color(0xFFCBD5E1)
    )

    MaterialTheme(colorScheme = darkScheme) {
        Box(modifier = Modifier.fillMaxSize()) {
            SpaceVioletGraphBackground(
                backgroundTheme = state.settings.backgroundTheme,
                smoothAnimations = smooth,
                paceFactor = paceFactor,
                modifier = Modifier.fillMaxSize()
            )
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    val royalVioletToneDown = Color(0xFF7E22CE)
                    val royalVioletHeartActive = Color(0xFF9333EA)
                    TopAppBar(
                        title = {
                            NeonTitleWithUnderlay(
                                text = "Assistant",
                                neonColor = Color(0xFFD8B4FE),
                                glowColor = Color(0xFF9333EA),
                                smoothAnimations = smooth,
                                breathScale = breathPulse
                            )
                        },
                        actions = {
                            // Пустое сердечко слева от сброса счётчика:
                            // тап -> фиолетовый дым на 1..5 сек; зажатие -> бабл "Любимая Мия<3"
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = {
                                                smokeDurationSec = Random.nextInt(1, 6)
                                                smokeTriggerId += 1
                                            },
                                            onLongPress = {
                                                showMiaBubble = true
                                                miaBubbleTriggerId += 1
                                            }
                                        )
                                    }
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (showMiaBubble) "♥" else "♡",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (smokeDurationSec > 0 || showMiaBubble) royalVioletHeartActive else royalVioletToneDown
                                )
                            }
                            // Сброс счётчика с подтверждением "Вы уверены?"
                            TextButton(onClick = { showResetCounterConfirmDialog = true }) {
                                Text(
                                    text = "Сброс счётчика",
                                    fontWeight = FontWeight.SemiBold,
                                    color = royalVioletToneDown
                                )
                            }
                            TextButton(onClick = { showSettingsDialog = true }) {
                                Text(
                                    text = "Настройки",
                                    fontWeight = FontWeight.SemiBold,
                                    color = royalVioletToneDown
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFF0A0F1C),
                            titleContentColor = royalVioletToneDown
                        )
                    )
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .pointerInput(Unit) {
                            var startX = 0f
                            var startY = 0f
                            var triggered = false
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val down = event.changes.firstOrNull { it.pressed }
                                    if (down != null) {
                                        if (!triggered && startX == 0f && startY == 0f) {
                                            startX = down.position.x
                                            startY = down.position.y
                                        } else if (!triggered) {
                                            val dx = down.position.x - startX
                                            val dy = down.position.y - startY
                                            if (dx < -95f && abs(dx) > abs(dy) * 1.35f) {
                                                triggered = true
                                                showCalculatorDialog = true
                                            } else if (dx > 95f && abs(dx) > abs(dy) * 1.35f) {
                                                triggered = true
                                                showNotebookDialog = true
                                            }
                                        }
                                    } else {
                                        startX = 0f
                                        startY = 0f
                                        triggered = false
                                    }
                                }
                            }
                        }
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (showDeadlineBanner && state.mode == PadMode.DEADLINE) {
                        val dlTimeStr = String.format(Locale.getDefault(), "%02d:%02d", state.deadlineHour, state.deadlineMinute)
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, PadMode.DEADLINE.accent.copy(alpha = 0.85f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                PadMode.DEADLINE.accent.copy(alpha = 0.42f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "дедлайн",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = "Наступило заданное время ($dlTimeStr).",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = mainMenuWhite
                                    )
                                }
                                TextButton(onClick = { showDeadlineBanner = false }) {
                                    Text("ОК", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (showTimerFinishedBanner && (state.mode == PadMode.SCHOOL || state.mode == PadMode.CODING)) {
                        val bannerMessage = when (state.mode) {
                            PadMode.CODING -> "Время кодинга вышло. Самое время сделать паузу."
                            else -> "Урок завершился. Хотите что-то зафиксировать?"
                        }
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.78f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.36f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Таймер завершён (${state.mode.label})",
                                        fontWeight = FontWeight.Bold,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = bannerMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = mainMenuWhite
                                    )
                                }
                                TextButton(onClick = { showTimerFinishedBanner = false }) {
                                    Text("ОК", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Стеклянная карточка статуса + счётчик
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            animatedAccent.copy(alpha = 0.22f),
                                            Color.White.copy(alpha = 0.06f)
                                        )
                                    )
                                )
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            var bellStatus by remember {
                                mutableStateOf(SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey))
                            }
                            LaunchedEffect(state.mode, state.schoolFinishedDateKey, state.settings.notificationsEnabled) {
                                while (isActive) {
                                    val prevNotifText = bellStatus.notificationText
                                    val fresh = SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey)
                                    bellStatus = fresh
                                    if (state.mode == PadMode.SCHOOL && fresh.notificationText != prevNotifText) {
                                        AlertHelper.syncOngoingModeNotification(
                                            context = context,
                                            mode = PadMode.SCHOOL,
                                            restTimerFinished = false,
                                            settings = state.settings,
                                            schoolFinishedDateKey = state.schoolFinishedDateKey,
                                            forceRecreate = false
                                        )
                                    }
                                    delay(1000L)
                                }
                            }

                            val isSchoolFinishedManuallyToday =
                                state.schoolFinishedDateKey.isNotEmpty() &&
                                state.schoolFinishedDateKey == SchoolBellSchedule.todayKey()

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Режим: ${state.mode.label}",
                                    fontWeight = FontWeight.Bold,
                                    color = mainMenuWhite
                                )
                                if (state.mode == PadMode.SCHOOL) {
                                    Text(
                                        text = bellStatus.statusText,
                                        color = mainMenuWhite,
                                        fontWeight = FontWeight.Medium
                                    )
                                    if (bellStatus.countdownLabel != null) {
                                        Text(
                                            text = bellStatus.countdownLabel!!,
                                            color = buttonTextColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = bellStatus.dayNote,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                    if (!isSchoolFinishedManuallyToday && bellStatus.kind != SchoolPhaseKind.AFTER_SCHOOL && bellStatus.kind != SchoolPhaseKind.WEEKEND) {
                                        Spacer(Modifier.height(2.dp))
                                        OutlinedButton(
                                            onClick = { showNoMoreLessonsConfirmDialog = true },
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, buttonTextColor.copy(alpha = 0.65f)),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Text(
                                                text = "Уроков больше нет",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = buttonTextColor
                                            )
                                        }
                                    }
                                } else if (state.mode == PadMode.DEADLINE) {
                                    var nowSecOfDay by remember { mutableIntStateOf(0) }
                                    LaunchedEffect(state.mode, state.deadlineActive, state.deadlineHour, state.deadlineMinute) {
                                        while (isActive && state.mode == PadMode.DEADLINE) {
                                            val c = java.util.Calendar.getInstance()
                                            nowSecOfDay = c.get(java.util.Calendar.HOUR_OF_DAY) * 3600 +
                                                c.get(java.util.Calendar.MINUTE) * 60 +
                                                c.get(java.util.Calendar.SECOND)
                                            delay(1000L)
                                        }
                                    }
                                    val targetFormatted = String.format(
                                        Locale.getDefault(),
                                        "%02d:%02d",
                                        state.deadlineHour,
                                        state.deadlineMinute
                                    )
                                    val targetSec = state.deadlineHour * 3600 + state.deadlineMinute * 60
                                    val diffSec = if (targetSec >= nowSecOfDay) {
                                        targetSec - nowSecOfDay
                                    } else {
                                        24 * 3600 - nowSecOfDay + targetSec
                                    }
                                    val remH = diffSec / 3600
                                    val remM = (diffSec % 3600) / 60
                                    val remS = diffSec % 60
                                    val leftStr = String.format(Locale.getDefault(), "%02d:%02d:%02d", remH, remM, remS)

                                    val calNow = java.util.Calendar.getInstance()
                                    val nowMinuteKey = "${calNow.get(java.util.Calendar.YEAR)}-${calNow.get(java.util.Calendar.DAY_OF_YEAR)}-${calNow.get(java.util.Calendar.HOUR_OF_DAY)}-${calNow.get(java.util.Calendar.MINUTE)}"
                                    val triggeredNow = !state.deadlineActive && state.deadlineTriggeredKey == nowMinuteKey
                                    Text(
                                        text = when {
                                            state.deadlineActive -> "Дедлайн установлен на $targetFormatted"
                                            triggeredNow -> "Дедлайн ($targetFormatted) сработал"
                                            else -> "Дедлайн ($targetFormatted) не активен"
                                        },
                                        color = mainMenuWhite,
                                        fontWeight = FontWeight.Medium
                                    )
                                    if (state.deadlineActive) {
                                        Text(
                                            text = "Осталось: $leftStr",
                                            color = buttonTextColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = "Часы 06:00–23:45 (шаг 15 мин)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                } else {
                                    val timerText = when {
                                        state.mode == PadMode.EMPTY -> "Пусто"
                                        state.mode == PadMode.DASH -> "—"
                                        !state.mode.supportsTimer -> "Таймер: отключён"
                                        state.mode == PadMode.REST && state.remainingSeconds == 0 ->
                                            "Таймер: без таймера (00:00)"
                                        else -> "Таймер: ${formatSeconds(state.remainingSeconds)}"
                                    }
                                    Text(
                                        text = timerText,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = "Счётчик: +1 / -1 • Зажмите + или - (>2с) для автонакрутки",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            // Счётчик текущего урока (1..8) показываем ТОЛЬКО в режиме «Школа»
                            if (state.mode == PadMode.SCHOOL) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(end = 6.dp)
                                ) {
                                    Text(
                                        text = "Урок",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                    NeonHollowCounter(
                                        value = bellStatus.displayLessonCounter,
                                        neonColor = buttonTextColor,
                                        smoothAnimations = smooth,
                                        breathScale = breathPulse,
                                        morphDurationMs = max(120, animDuration)
                                    )
                                }
                            }

                            NeonHollowCounter(
                                value = state.counter,
                                neonColor = animatedAccent,
                                smoothAnimations = smooth,
                                breathScale = breathPulse,
                                morphDurationMs = max(120, animDuration)
                            )
                        }
                    }

                    // Кнопка 1 и Кнопка 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ColoredGlassButton(
                            text = "Заметка",
                            subtitle = "Записей: ${state.notes.size}",
                            badgeGlyph = "✎",
                            tint = animatedAccent,
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(66.dp),
                            onClick = { showNoteDialog = true }
                        )

                        val canToggleTimer = state.mode != PadMode.SCHOOL &&
                            state.mode != PadMode.DEADLINE &&
                            state.mode.supportsTimer &&
                            state.remainingSeconds > 0
                        val timerLabel = when {
                            state.mode == PadMode.SCHOOL -> "По звонкам"
                            state.mode == PadMode.DEADLINE -> "Время дедлайна"
                            !state.mode.supportsTimer -> "Без таймера"
                            state.mode == PadMode.REST && state.remainingSeconds == 0 -> "Задать время"
                            state.isTimerRunning -> "Пауза"
                            else -> "Старт"
                        }
                        val timerSub = when {
                            state.mode == PadMode.SCHOOL -> "Расписание"
                            state.mode == PadMode.DEADLINE -> "Срок и отсчёт"
                            !state.mode.supportsTimer -> "Свободный режим"
                            state.mode == PadMode.REST && state.remainingSeconds == 0 -> "Выбрать минуты"
                            state.isTimerRunning -> "Идёт отсчёт"
                            else -> "Готов к запуску"
                        }
                        val timerGlyph = when {
                            state.mode == PadMode.SCHOOL -> "🔔"
                            state.mode == PadMode.DEADLINE -> "⏳"
                            !state.mode.supportsTimer -> "∞"
                            state.isTimerRunning -> "❚❚"
                            else -> "▶"
                        }
                        ColoredGlassButton(
                            text = timerLabel,
                            subtitle = timerSub,
                            badgeGlyph = timerGlyph,
                            tint = Color(0xFF0EA5E9),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(66.dp),
                            onClick = {
                                if (state.mode == PadMode.SCHOOL) {
                                    val fresh = SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey)
                                    AlertHelper.syncOngoingModeNotification(
                                        context = context,
                                        mode = PadMode.SCHOOL,
                                        restTimerFinished = false,
                                        settings = state.settings,
                                        schoolFinishedDateKey = state.schoolFinishedDateKey,
                                        forceRecreate = true
                                    )
                                    showTimerFinishedBanner = false
                                    draftNote = fresh.statusText
                                } else if (state.mode == PadMode.DEADLINE) {
                                    showDeadlinePickerDialog = true
                                } else if (canToggleTimer) {
                                    showTimerFinishedBanner = false
                                    updateAndSave {
                                        it.copy(
                                            isTimerRunning = !it.isTimerRunning,
                                            restTimerFinished = if (!it.isTimerRunning) false else it.restTimerFinished
                                        )
                                    }
                                } else if (state.mode == PadMode.REST) {
                                    showCustomRestDialog = true
                                }
                            }
                        )
                    }

                    // Кнопка 3: левая половина (+1 счётчик, удержание >2с накручивает таймер вверх),
                    // правая половина (-1 счётчик, удержание >2с накручивает таймер вниз) и Кнопка 4 (радиальное меню)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.72f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.44f),
                                                animatedAccent.copy(alpha = 0.20f)
                                            )
                                        )
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter + 1) }
                                                },
                                                onPress = {
                                                    holdingPlus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingPlus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                                VerticalDivider(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .padding(vertical = 12.dp),
                                    thickness = 1.dp,
                                    color = animatedAccent.copy(alpha = 0.55f)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter - 1) }
                                                },
                                                onPress = {
                                                    holdingMinus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingMinus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "-1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                            }
                        }

                        ColoredGlassButton(
                            text = "Меню",
                            subtitle = "Режимы • Настройки",
                            badgeGlyph = "◈",
                            tint = Color(0xFF8B5CF6),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(66.dp),
                            onClick = { showRadialMenu = true }
                        )
                    }

                    ColoredGlassButton(
                        text = "Игра • Звёздный ловец",
                        tint = Color(0xFFD97706),
                        textColor = Color(0xFFFEF3C7),
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        onClick = { showMiniGameDialog = true }
                    )

                    var dateSearchQuery by remember { mutableStateOf("") }
                    var infoSearchQuery by remember { mutableStateOf("") }

                    // Строгий разбор даты: день.месяц, только через '.' (например 27.11)
                    val dateParts = dateSearchQuery.trim().split(".")
                    val hasDateQuery = dateSearchQuery.trim().isNotEmpty()
                    val isDateFormatValid = !hasDateQuery || (
                        dateParts.size == 2 &&
                            dateParts[0].isNotEmpty() && dateParts[1].isNotEmpty() &&
                            dateParts[0].all { it.isDigit() } && dateParts[1].all { it.isDigit() } &&
                            (dateParts[0].toIntOrNull() in 1..31) &&
                            (dateParts[1].toIntOrNull() in 1..12)
                        )
                    val normalizedDayMonth = if (hasDateQuery && isDateFormatValid) {
                        String.format(Locale.getDefault(), "%02d.%02d", dateParts[0].toInt(), dateParts[1].toInt())
                    } else {
                        null
                    }

                    val exactInfoQuery = infoSearchQuery.trim()
                    val filteredNotes = state.notes.filter { note ->
                        val matchesDate = when {
                            !hasDateQuery -> true
                            !isDateFormatValid || normalizedDayMonth == null -> false
                            else -> note.timestamp.startsWith(normalizedDayMonth)
                        }
                        val matchesInfo = if (exactInfoQuery.isEmpty()) {
                            true
                        } else {
                            // Точное совпадение текста записи (или точное совпадение слова/фразы без частичных обрезков)
                            note.text == exactInfoQuery ||
                                note.text.equals(exactInfoQuery, ignoreCase = false) ||
                                Regex("(?<!\\S)${Regex.escape(exactInfoQuery)}(?!\\S)").containsMatchIn(note.text)
                        }
                        matchesDate && matchesInfo
                    }

                    // Графа-поиск: по дате (день.месяц строго через '.') и по информации (точное совпадение)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.55f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFF4C1D95).copy(alpha = 0.28f),
                                            Color(0xFF0F172A).copy(alpha = 0.65f)
                                        )
                                    )
                                )
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Графа-поиск",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE9D5FF)
                                )
                                if (hasDateQuery || exactInfoQuery.isNotEmpty()) {
                                    TextButton(
                                        onClick = {
                                            dateSearchQuery = ""
                                            infoSearchQuery = ""
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text(
                                            text = "Сброс",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = mainMenuWhite
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = dateSearchQuery,
                                    onValueChange = { raw ->
                                        // Разрешаем только цифры и точку '.'
                                        dateSearchQuery = raw.filter { it.isDigit() || it == '.' }.take(5)
                                    },
                                    label = { Text("Дата (дд.мм)") },
                                    placeholder = { Text("27.11") },
                                    singleLine = true,
                                    isError = hasDateQuery && !isDateFormatValid,
                                    modifier = Modifier.weight(0.42f)
                                )
                                OutlinedTextField(
                                    value = infoSearchQuery,
                                    onValueChange = { infoSearchQuery = it },
                                    label = { Text("Информация (точно)") },
                                    placeholder = { Text("Точное совпадение") },
                                    singleLine = true,
                                    modifier = Modifier.weight(0.58f)
                                )
                            }

                            if (hasDateQuery && !isDateFormatValid) {
                                Text(
                                    text = "Дата считается только через точку в формате день.месяц (например, 27.11).",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFCA5A5)
                                )
                            }
                        }
                    }

                    Text(
                        text = "Сохранённые записи (${filteredNotes.size} из ${state.notes.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = mainMenuWhite
                    )

                    if (filteredNotes.isEmpty()) {
                        Text(
                            text = if (state.notes.isEmpty()) {
                                "Пока пусто. Нажмите «1. Заметка», чтобы добавить Вашу запись."
                            } else {
                                "Совпадений по запросу не найдено."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = mainMenuWhite.copy(alpha = 0.82f)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                val noteMode = PadMode.fromName(note.modeName)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, noteMode.accent.copy(alpha = 0.55f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(
                                                        noteMode.accent.copy(alpha = 0.28f),
                                                        noteMode.accent.copy(alpha = 0.08f)
                                                    )
                                                )
                                            )
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 8.dp)
                                        ) {
                                            Text(
                                                text = "${note.timestamp}  •  ${noteMode.label}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = noteMode.buttonBrightText
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                text = note.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = mainMenuWhite
                                            )
                                        }
                                        TextButton(
                                            onClick = {
                                                updateAndSave { current ->
                                                    current.copy(notes = current.notes.filterNot { it.id == note.id })
                                                }
                                            }
                                        ) {
                                            Text(
                                                text = "Удалить",
                                                color = mainMenuWhite,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Оверлей фиолетового дыма поверх экрана при нажатии на сердечко
            if (smokeDurationSec > 0) {
                PurpleSmokeOverlay(
                    progress = smokeProgress,
                    triggerId = smokeTriggerId,
                    smoothAnimations = smooth
                )
            }

            // Бабл секретки при зажатии сердечка по центру экрана: "Любимая Мия<3"
            if (showMiaBubble) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 24.dp)
                ) {
                    Surface(
                        onClick = { showMiaBubble = false },
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, Color(0xFFD8B4FE).copy(alpha = 0.85f)),
                        shadowElevation = 8.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFF581C87).copy(alpha = 0.94f),
                                            Color(0xFF3B0764).copy(alpha = 0.94f)
                                        )
                                    )
                                )
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "Любимая Мия<3",
                                color = Color(0xFFF5D0FE),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        if (showNoMoreLessonsConfirmDialog) {
            GlassDialogWrapper(onDismiss = { showNoMoreLessonsConfirmDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Уроков больше нет?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Таймер звонков на сегодня остановится и не будет тикать попросту.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.88f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = { showNoMoreLessonsConfirmDialog = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Подтвердить",
                        tint = PadMode.SCHOOL.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val today = SchoolBellSchedule.todayKey()
                            updateAndSave(syncNotification = true) {
                                it.copy(schoolFinishedDateKey = today)
                            }
                            showNoMoreLessonsConfirmDialog = false
                        }
                    )
                }
            }
        }

        if (showResetCounterConfirmDialog) {
            GlassDialogWrapper(onDismiss = { showResetCounterConfirmDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Вы уверены?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Счётчик будет сброшен до 0.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.88f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = { showResetCounterConfirmDialog = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Сбросить",
                        tint = animatedAccent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            updateAndSave { it.copy(counter = 0) }
                            showResetCounterConfirmDialog = false
                        }
                    )
                }
            }
        }

        if (showRadialMenu) {
            RadialFourWayDialog(
                currentMode = state.mode,
                smoothAnimations = smooth,
                secretMessage = secretMessage,
                onSecretCenterTap = {
                    secretMessage = "Я всё ещё жду, пока Вы создадите нас."
                    secretTriggerId += 1
                },
                onSelectMode = { chosen ->
                    showRadialMenu = false
                    applyModeSelection(chosen)
                },
                onSelectDashSilent = {
                    showRadialMenu = false
                    showTimerFinishedBanner = false
                    showDeadlineBanner = false
                    AlertHelper.cancelOngoingNotification(context)
                    runCatching {
                        context.stopService(Intent(context, KuroForegroundService::class.java))
                    }
                    state = state.copy(
                        mode = PadMode.EMPTY,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                    onPersist(state)
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showSettingsDialog) {
            var settingsTab by remember { mutableIntStateOf(0) } // 0 — Общее, 1 — Напоминания
            var reminderTextInput by remember { mutableStateOf("") }
            var reminderHour by remember { mutableIntStateOf(9) }
            var reminderMinute by remember { mutableIntStateOf(0) }
            var selectedDays by remember {
                mutableStateOf(
                    setOf(
                        java.util.Calendar.MONDAY,
                        java.util.Calendar.TUESDAY,
                        java.util.Calendar.WEDNESDAY,
                        java.util.Calendar.THURSDAY,
                        java.util.Calendar.FRIDAY
                    )
                )
            }
            val weekDayOptions = listOf(
                java.util.Calendar.MONDAY to "Пн",
                java.util.Calendar.TUESDAY to "Вт",
                java.util.Calendar.WEDNESDAY to "Ср",
                java.util.Calendar.THURSDAY to "Чт",
                java.util.Calendar.FRIDAY to "Пт",
                java.util.Calendar.SATURDAY to "Сб",
                java.util.Calendar.SUNDAY to "Вс"
            )

            GlassDialogWrapper(onDismiss = { showSettingsDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Настройки",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )

                // Вкладки внутри настроек: Общее / Напоминания
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ColoredGlassButton(
                        text = "Общее",
                        tint = if (settingsTab == 0) animatedAccent else Color(0xFF334155),
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(40.dp),
                        onClick = { settingsTab = 0 }
                    )
                    ColoredGlassButton(
                        text = "Напоминания (${state.customReminders.size})",
                        tint = if (settingsTab == 1) Color(0xFF9333EA) else Color(0xFF334155),
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(40.dp),
                        onClick = { settingsTab = 1 }
                    )
                }

                if (settingsTab == 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Уведомления",
                            color = mainMenuWhite,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = state.settings.notificationsEnabled,
                            onCheckedChange = { enabled ->
                                updateAndSave(forceNotificationRecreate = true) {
                                    it.copy(settings = it.settings.copy(notificationsEnabled = enabled))
                                }
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Вибрация (только Коддинг)",
                            color = mainMenuWhite,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = state.settings.codingVibrationEnabled,
                            onCheckedChange = { enabled ->
                                updateAndSave {
                                    it.copy(settings = it.settings.copy(codingVibrationEnabled = enabled))
                                }
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Плавные анимации",
                            color = mainMenuWhite,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = state.settings.smoothAnimationsEnabled,
                            onCheckedChange = { enabled ->
                                updateAndSave {
                                    it.copy(settings = it.settings.copy(smoothAnimationsEnabled = enabled))
                                }
                            }
                        )
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Темп анимаций и прокрутки",
                                color = mainMenuWhite,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "${state.settings.uiPacePercent.toInt()}%",
                                color = buttonTextColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = state.settings.uiPacePercent,
                            onValueChange = { newVal ->
                                state = state.copy(settings = state.settings.copy(uiPacePercent = newVal))
                            },
                            onValueChangeFinished = {
                                onPersist(state)
                            },
                            valueRange = 0f..100f
                        )
                    }

                    val themeLabels = mapOf(
                        1 to "1 — Исходный (космос-граф)",
                        2 to "2 — Космос (созвездия и орбиты)",
                        3 to "3 — Космос (туманность и кольца)",
                        4 to "4 — Код (фиолетовый матричный поток)"
                    )
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Фон (1–2–3–4)",
                                color = mainMenuWhite,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "${state.settings.backgroundTheme} / 4",
                                color = Color(0xFFC084FC),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (tIdx in 1..4) {
                                val active = state.settings.backgroundTheme == tIdx
                                Text(
                                    text = "$tIdx",
                                    fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
                                    color = if (active) Color(0xFFD8B4FE) else mainMenuWhite.copy(alpha = 0.65f)
                                )
                            }
                        }
                        Slider(
                            value = state.settings.backgroundTheme.toFloat(),
                            onValueChange = { rawTheme ->
                                val snapped = rawTheme.toInt().coerceIn(1, 4)
                                state = state.copy(settings = state.settings.copy(backgroundTheme = snapped))
                            },
                            onValueChangeFinished = {
                                onPersist(state)
                            },
                            valueRange = 1f..4f,
                            steps = 2
                        )
                        Text(
                            text = themeLabels[state.settings.backgroundTheme] ?: "",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFD8B4FE)
                        )
                    }
                } else {
                    // Вкладка "Напоминания": неограниченное количество автонапоминаний
                    OutlinedTextField(
                        value = reminderTextInput,
                        onValueChange = { reminderTextInput = it },
                        label = { Text("Текст для напоминания...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Время напоминания (часы 0..23 и минуты 0..59)
                    Text(
                        text = "Время напоминания: ${String.format(Locale.getDefault(), "%02d:%02d", reminderHour, reminderMinute)}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = mainMenuWhite
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ColoredGlassButton(
                            text = "-1ч",
                            tint = Color(0xFF7E22CE),
                            textColor = mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(38.dp),
                            onClick = { reminderHour = if (reminderHour <= 0) 23 else reminderHour - 1 }
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "%02dч", reminderHour),
                            color = mainMenuWhite,
                            fontWeight = FontWeight.Bold
                        )
                        ColoredGlassButton(
                            text = "+1ч",
                            tint = Color(0xFF7E22CE),
                            textColor = mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(38.dp),
                            onClick = { reminderHour = if (reminderHour >= 23) 0 else reminderHour + 1 }
                        )
                        ColoredGlassButton(
                            text = "-5м",
                            tint = Color(0xFF6D28D9),
                            textColor = mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(38.dp),
                            onClick = {
                                reminderMinute = if (reminderMinute < 5) 55 + reminderMinute else reminderMinute - 5
                            }
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "%02dм", reminderMinute),
                            color = mainMenuWhite,
                            fontWeight = FontWeight.Bold
                        )
                        ColoredGlassButton(
                            text = "+5м",
                            tint = Color(0xFF6D28D9),
                            textColor = mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(38.dp),
                            onClick = { reminderMinute = (reminderMinute + 5) % 60 }
                        )
                    }

                    // Дни напоминания: можно выбрать несколько, хоть все в неделе
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Дни напоминания",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = mainMenuWhite
                        )
                        TextButton(
                            onClick = {
                                val allDays = weekDayOptions.map { it.first }.toSet()
                                selectedDays = if (selectedDays.size == allDays.size) emptySet() else allDays
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(
                                text = if (selectedDays.size == 7) "Снять все" else "Все дни",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFD8B4FE)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        weekDayOptions.forEach { (dayConst, dayLabel) ->
                            val active = dayConst in selectedDays
                            Surface(
                                onClick = {
                                    selectedDays = if (active) selectedDays - dayConst else selectedDays + dayConst
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (active) Color(0xFF9333EA).copy(alpha = 0.65f) else Color(0xFF1E293B).copy(alpha = 0.65f),
                                border = BorderStroke(
                                    1.dp,
                                    if (active) Color(0xFFE9D5FF) else Color.White.copy(alpha = 0.20f)
                                ),
                                modifier = Modifier.weight(1f).height(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = dayLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Normal,
                                        color = mainMenuWhite
                                    )
                                }
                            }
                        }
                    }

                    ColoredGlassButton(
                        text = "Добавить напоминание",
                        tint = Color(0xFF9333EA),
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.fillMaxWidth().height(42.dp),
                        onClick = {
                            val cleanText = reminderTextInput.trim()
                            if (cleanText.isNotEmpty() && selectedDays.isNotEmpty()) {
                                val newItem = CustomAutoReminder(
                                    id = System.currentTimeMillis(),
                                    text = cleanText,
                                    hour = reminderHour,
                                    minute = reminderMinute,
                                    daysOfWeek = selectedDays,
                                    enabled = true
                                )
                                val updatedReminders = listOf(newItem) + state.customReminders
                                updateAndSave { it.copy(customReminders = updatedReminders) }
                                ReminderScheduler.scheduleCustomReminders(context, updatedReminders)
                                reminderTextInput = ""
                            }
                        }
                    )

                    if (state.customReminders.isEmpty()) {
                        Text(
                            text = "Автонапоминаний пока нет. Добавьте первое выше.",
                            style = MaterialTheme.typography.bodySmall,
                            color = mainMenuWhite.copy(alpha = 0.78f)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 170.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(state.customReminders, key = { it.id }) { item ->
                                val daysStr = weekDayOptions
                                    .filter { it.first in item.daysOfWeek }
                                    .joinToString(", ") { it.second }
                                val timeStr = String.format(Locale.getDefault(), "%02d:%02d", item.hour, item.minute)
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF1E293B).copy(alpha = 0.75f),
                                    border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.45f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "$timeStr  •  $daysStr",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFD8B4FE)
                                            )
                                            Text(
                                                text = item.text,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = mainMenuWhite
                                            )
                                        }
                                        Switch(
                                            checked = item.enabled,
                                            onCheckedChange = { checked ->
                                                val updated = state.customReminders.map { r ->
                                                    if (r.id == item.id) r.copy(enabled = checked) else r
                                                }
                                                updateAndSave { it.copy(customReminders = updated) }
                                                ReminderScheduler.scheduleCustomReminders(context, updated)
                                            }
                                        )
                                        TextButton(
                                            onClick = {
                                                val updated = state.customReminders.filterNot { r -> r.id == item.id }
                                                updateAndSave { it.copy(customReminders = updated) }
                                                ReminderScheduler.scheduleCustomReminders(context, updated)
                                            },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                                        ) {
                                            Text("Удалить", color = Color(0xFFFCA5A5), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Закрыть", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showCodingPresetDialog) {
            val presets = listOf(
                "30 мин" to 30 * 60,
                "1 ч" to 60 * 60,
                "1,5 ч" to 90 * 60,
                "2 ч" to 120 * 60
            )
            GlassDialogWrapper(onDismiss = { showCodingPresetDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Коддинг — длительность",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Выберите интервал таймера",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                presets.forEach { (label, seconds) ->
                    ColoredGlassButton(
                        text = label,
                        tint = PadMode.CODING.accent,
                        textColor = PadMode.CODING.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.CODING,
                                    remainingSeconds = seconds,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCodingPresetDialog = false
                        }
                    )
                }
                TextButton(onClick = { showCodingPresetDialog = false }) {
                    Text("Оставить текущий", color = mainMenuWhite)
                }
            }
        }

        if (showDeadlinePickerDialog) {
            var pickedHour by remember(state.deadlineHour) {
                mutableIntStateOf(state.deadlineHour.coerceIn(6, 23))
            }
            var pickedMinute by remember(state.deadlineMinute) {
                mutableIntStateOf(if (state.deadlineMinute in listOf(0, 15, 30, 45)) state.deadlineMinute else 0)
            }
            val minuteQuarters = listOf(0, 15, 30, 45)
            val previewTime = String.format(Locale.getDefault(), "%02d:%02d", pickedHour, pickedMinute)

            GlassDialogWrapper(onDismiss = { showDeadlinePickerDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Дедлайн — выбор времени",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Часы с 6 до 23, шаг каждые 15 минут. Когда системное время совпадёт — придёт уведомление «дедлайн».",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )

                // Крупный предпросмотр выбранного времени
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PadMode.DEADLINE.accent.copy(alpha = 0.22f))
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = previewTime,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PadMode.DEADLINE.buttonBrightText
                    )
                }

                // Выбор часа (6..23)
                Text(
                    text = "Час (6 – 23)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = mainMenuWhite
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ColoredGlassButton(
                        text = "-1 ч",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(42.dp),
                        onClick = {
                            pickedHour = if (pickedHour <= 6) 23 else pickedHour - 1
                        }
                    )
                    Text(
                        text = String.format(Locale.getDefault(), "%02d ч", pickedHour),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = mainMenuWhite,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    ColoredGlassButton(
                        text = "+1 ч",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(42.dp),
                        onClick = {
                            pickedHour = if (pickedHour >= 23) 6 else pickedHour + 1
                        }
                    )
                }

                Slider(
                    value = pickedHour.toFloat(),
                    onValueChange = { pickedHour = it.toInt().coerceIn(6, 23) },
                    valueRange = 6f..23f,
                    steps = 16
                )

                // Выбор минут с делением каждые 15 минут (00, 15, 30, 45)
                Text(
                    text = "Минуты (шаг 15 мин)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = mainMenuWhite
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    minuteQuarters.forEach { q ->
                        val selected = pickedMinute == q
                        ColoredGlassButton(
                            text = String.format(Locale.getDefault(), ":%02d", q),
                            tint = if (selected) PadMode.DEADLINE.accent else Color(0xFF334155),
                            textColor = if (selected) PadMode.DEADLINE.buttonBrightText else mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(42.dp),
                            onClick = { pickedMinute = q }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.DEADLINE,
                                    deadlineActive = false
                                )
                            }
                            showDeadlinePickerDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отключить", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Установить",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            showDeadlineBanner = false
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.DEADLINE,
                                    deadlineHour = pickedHour.coerceIn(6, 23),
                                    deadlineMinute = pickedMinute,
                                    deadlineActive = true,
                                    deadlineTriggeredKey = ""
                                )
                            }
                            showDeadlinePickerDialog = false
                        }
                    )
                }
            }
        }

        if (showCustomRestDialog) {
            GlassDialogWrapper(onDismiss = { showCustomRestDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Отдых",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Режим работает без таймера, но при желании Вы можете задать своё время в минутах.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                OutlinedTextField(
                    value = customMinutesInput,
                    onValueChange = { value ->
                        customMinutesInput = value.filter { it.isDigit() }.take(3)
                    },
                    label = { Text("Минуты (опционально)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.REST,
                                    remainingSeconds = 0,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Без таймера", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Задать",
                        tint = PadMode.REST.accent,
                        textColor = PadMode.REST.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val mins = customMinutesInput.toIntOrNull()?.coerceIn(1, 720)
                            if (mins != null) {
                                updateAndSave(forceNotificationRecreate = true) {
                                    it.copy(
                                        mode = PadMode.REST,
                                        remainingSeconds = mins * 60,
                                        isTimerRunning = false,
                                        restTimerFinished = false
                                    )
                                }
                            }
                            showCustomRestDialog = false
                        }
                    )
                }
            }
        }

        if (showCalculatorDialog) {
            ScientificCalculatorDialog(
                smoothAnimations = smooth,
                animDuration = animDuration,
                onDismiss = { showCalculatorDialog = false }
            )
        }

        NotebookSlideOutPanel(
            visible = showNotebookDialog,
            notebookEntries = state.notebookEntries,
            quickNotes = state.notes,
            smoothAnimations = smooth,
            animDuration = animDuration,
            onAddEntry = { titleText, bodyText ->
                val stamp = SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date())
                val nowMs = System.currentTimeMillis()
                val entry = NotebookEntry(
                    id = nowMs,
                    title = titleText.trim().ifBlank { "Без названия" },
                    text = bodyText,
                    createdAt = nowMs,
                    timestamp = stamp
                )
                updateAndSave { it.copy(notebookEntries = listOf(entry) + it.notebookEntries) }
            },
            onUpdateEntry = { targetId, newTitle, newBody ->
                updateAndSave { cur ->
                    cur.copy(
                        notebookEntries = cur.notebookEntries.map { item ->
                            if (item.id == targetId) {
                                item.copy(
                                    title = newTitle.trim().ifBlank { "Без названия" },
                                    text = newBody
                                )
                            } else {
                                item
                            }
                        }
                    )
                }
            },
            onDeleteEntry = { entryId ->
                updateAndSave { cur ->
                    cur.copy(notebookEntries = cur.notebookEntries.filterNot { it.id == entryId })
                }
            },
            onDismiss = { showNotebookDialog = false }
        )

        if (showMiniGameDialog) {
            StarCatcherMiniGameDialog(
                savedBestScore = state.gameBestScore,
                onSaveBestScore = { newBest ->
                    if (newBest > state.gameBestScore) {
                        updateAndSave { it.copy(gameBestScore = newBest) }
                    }
                },
                smoothAnimations = smooth,
                animDuration = animDuration,
                onDismiss = { showMiniGameDialog = false }
            )
        }

        if (showNoteDialog) {
            GlassDialogWrapper(onDismiss = { showNoteDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Новая заметка (${state.mode.label})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                OutlinedTextField(
                    value = draftNote,
                    onValueChange = { draftNote = it },
                    placeholder = { Text("Короткая мысль или задача...") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    timestamp = stamp,
                                    text = clean,
                                    modeName = state.mode.name
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PurpleSmokeOverlay(
    progress: Float,
    triggerId: Int,
    smoothAnimations: Boolean
) {
    val palette = remember {
        listOf(
            Color(0xFFA855F7),
            Color(0xFFD8B4FE),
            Color(0xFF7E22CE),
            Color(0xFFC084FC)
        )
    }
    val particles = remember(triggerId) {
        val rng = Random(triggerId * 9973 + 17)
        List(14) { idx ->
            SmokeParticle(
                seed = rng.nextFloat() * 100f,
                baseXRatio = 0.12f + rng.nextFloat() * 0.76f,
                baseYRatio = 0.14f + rng.nextFloat() * 0.72f,
                radiusDp = 42f + rng.nextFloat() * 58f,
                driftX = (rng.nextFloat() - 0.5f) * 140f,
                driftY = -45f - rng.nextFloat() * 95f,
                color = palette[idx % palette.size]
            )
        }
    }

    // Двуличная огибающая: тонкий вуаль-шлейф, который в середине цикла вдруг делает коварный всплеск и тут же отступает
    val sneakWave = sin((progress * PI * 3.0)).toFloat()
    val doubleFaceTwist = cos((progress * PI * 5.0)).toFloat()
    val envelope = if (smoothAnimations) {
        val fadeInT = (progress / 0.18f).coerceIn(0f, 1f)
        val fadeOutT = ((1f - progress) / 0.25f).coerceIn(0f, 1f)
        val base = min(fadeInT, fadeOutT)
        (base * (0.72f + 0.28f * max(0.25f, sneakWave))).coerceIn(0f, 1f)
    } else {
        if (progress < 0.85f) 0.35f else 0f
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (envelope <= 0.01f) return@Canvas

        particles.forEachIndexed { idx, p ->
            // Каждая чётная струйка ведёт себя "двулично": меняет курс на противоположный по ходу прогресса
            val twoFacedSign = if (idx % 2 == 0 && progress > 0.45f) -1f else 1f
            val phase = p.seed + progress * 6.5f + idx * 0.6f
            val dx = p.driftX * progress * twoFacedSign + sin(phase.toDouble()).toFloat() * 28f * doubleFaceTwist
            val dy = p.driftY * progress * (if (idx % 3 == 0) -0.5f else 1f) + cos((phase * 0.9f).toDouble()).toFloat() * 16f
            val cx = (size.width * p.baseXRatio + dx).coerceIn(0f, size.width)
            val cy = (size.height * p.baseYRatio + dy).coerceIn(0f, size.height)
            val radPx = p.radiusDp.dp.toPx() * (0.72f + 0.35f * abs(sneakWave))

            // Лёгкий полупрозрачный дым — не плотная стена, а тонкие призрачные завихрения
            val alpha = (0.30f * envelope * (0.65f + 0.35f * abs(doubleFaceTwist))).coerceIn(0f, 0.42f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.color.copy(alpha = alpha),
                        p.color.copy(alpha = alpha * 0.32f),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = radPx
                ),
                radius = radPx,
                center = Offset(cx, cy)
            )
        }
    }
}

@Composable
private fun SmoothAnimatedButtonWrapper(
    pressed: Boolean,
    animDuration: Int,
    modifier: Modifier,
    content: @Composable (Modifier) -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = tween(durationMillis = max(80, animDuration / 2)),
        label = "btnScale"
    )
    content(modifier.scale(scale))
}


@Composable
private fun NeonTitleWithUnderlay(
    text: String,
    neonColor: Color,
    glowColor: Color,
    smoothAnimations: Boolean,
    breathScale: Float
) {
    val pulseAlpha = if (smoothAnimations) {
        (0.28f + 0.14f * ((breathScale - 0.96f) / 0.08f)).coerceIn(0.18f, 0.48f)
    } else {
        0.34f
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        glowColor.copy(alpha = pulseAlpha),
                        Color(0xFF3B0764).copy(alpha = pulseAlpha * 0.85f),
                        Color.Transparent
                    )
                )
            )
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Box(contentAlignment = Alignment.CenterStart) {
                Text(
                    text = text,
                    style = TextStyle(
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = glowColor.copy(alpha = 0.75f),
                        drawStyle = Stroke(width = 5.5f, join = StrokeJoin.Round)
                    ),
                    maxLines = 1
                )
                Text(
                    text = text,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = neonColor,
                    maxLines = 1
                )
            }
            // Неоновая подводка под названием приложения
            Box(
                modifier = Modifier
                    .width(126.dp)
                    .height(2.5.dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                neonColor,
                                glowColor,
                                Color(0xFF38BDF8).copy(alpha = 0.7f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }
    }
}

@Composable
private fun ColoredGlassButton(
    text: String,
    tint: Color,
    textColor: Color = Color.White,
    subtitle: String? = null,
    badgeGlyph: String? = null,
    smoothAnimations: Boolean = true,
    animDuration: Int = 260,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }

    val renderSurface: @Composable (Modifier) -> Unit = { mod ->
        Surface(
            onClick = onClick,
            shape = RoundedCornerShape(17.dp),
            color = Color.Transparent,
            shadowElevation = if (pressed) 2.dp else 7.dp,
            border = BorderStroke(
                width = 1.35.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.44f),
                        tint.copy(alpha = 0.92f),
                        tint.copy(alpha = 0.52f)
                    )
                )
            ),
            modifier = mod.pointerInput(smoothAnimations) {
                if (smoothAnimations) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    )
                }
            }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                tint.copy(alpha = if (pressed) 0.62f else 0.50f),
                                tint.copy(alpha = 0.25f),
                                Color(0xFF060911).copy(alpha = 0.42f)
                            )
                        )
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(1.5.dp)
                        .border(
                            width = 0.6.dp,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.24f),
                                    Color.Transparent,
                                    tint.copy(alpha = 0.30f)
                                )
                            ),
                            shape = RoundedCornerShape(15.5.dp)
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.22f),
                                    Color.Transparent
                                )
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    tint.copy(alpha = if (pressed) 0.42f else 0.28f)
                                )
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!badgeGlyph.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(0.7.dp, Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.padding(end = 7.dp)
                        ) {
                            Text(
                                text = badgeGlyph,
                                color = textColor,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = text,
                            fontWeight = FontWeight.SemiBold,
                            color = textColor,
                            maxLines = 1
                        )
                        if (!subtitle.isNullOrBlank()) {
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = textColor.copy(alpha = 0.76f),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }

    if (smoothAnimations) {
        SmoothAnimatedButtonWrapper(pressed = pressed, animDuration = animDuration, modifier = modifier, content = renderSurface)
    } else {
        renderSurface(modifier)
    }
}

@Composable
private fun SmoothCounterScaleBox(
    breathScale: Float,
    smoothAnimations: Boolean,
    content: @Composable (Modifier) -> Unit
) {
    if (!smoothAnimations) {
        content(Modifier)
        return
    }
    val animatedScale by animateFloatAsState(
        targetValue = breathScale,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "counterScale"
    )
    content(Modifier.scale(animatedScale))
}

@Composable
private fun StaticNeonGlyph(
    glyph: String,
    neonColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    if (glyph.isEmpty()) return
    Box(contentAlignment = Alignment.Center) {
        Text(
            text = glyph,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF060911),
                drawStyle = Stroke(width = 4.5f, join = StrokeJoin.Round)
            )
        )
        Text(
            text = glyph,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.ExtraBold,
                color = neonColor,
                drawStyle = Stroke(width = 2.0f, join = StrokeJoin.Round)
            )
        )
    }
}

@Composable
private fun MorphingCharSlot(
    fromChar: Char?,
    toChar: Char,
    morphT: Float,
    neonColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val t = morphT.coerceIn(0f, 1f)
    if (fromChar == null || fromChar == toChar || t >= 0.999f) {
        StaticNeonGlyph(glyph = toChar.toString(), neonColor = neonColor, fontSize = fontSize)
        return
    }

    // Истинный морф: оба контура лежат в одном центре без провала яркости в 0;
    // на этапе морфа толщина контура плавно сжимается/растягивается, формируя единый перетекающий силуэт
    val morphWarp = sin((t * PI).toDouble()).toFloat()
    val fromScale = (1f - 0.14f * t + 0.08f * morphWarp).coerceIn(0.8f, 1.1f)
    val toScale = (0.86f + 0.14f * t + 0.08f * morphWarp).coerceIn(0.8f, 1.1f)
    val strokeBoost = 1f + 0.45f * morphWarp

    Box(contentAlignment = Alignment.Center) {
        if (fromChar != ' ') {
            Box(
                modifier = Modifier.scale(fromScale),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = fromChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF060911).copy(alpha = (1f - 0.65f * t).coerceIn(0.35f, 1f)),
                        drawStyle = Stroke(width = 4.5f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
                Text(
                    text = fromChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = neonColor.copy(alpha = (1f - t).coerceIn(0f, 1f)),
                        drawStyle = Stroke(width = 2.0f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
            }
        }
        if (toChar != ' ') {
            Box(
                modifier = Modifier.scale(toScale),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = toChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF060911).copy(alpha = (0.35f + 0.65f * t).coerceIn(0.35f, 1f)),
                        drawStyle = Stroke(width = 4.5f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
                Text(
                    text = toChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = neonColor.copy(alpha = t.coerceIn(0f, 1f)),
                        drawStyle = Stroke(width = 2.0f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
            }
        }
    }
}

@Composable
private fun NeonHollowCounter(
    value: Int,
    neonColor: Color,
    smoothAnimations: Boolean = true,
    breathScale: Float = 1f,
    morphDurationMs: Int = 180
) {
    val targetText = value.toString()
    val fontSize = 44.sp

    // При выключенных анимациях вообще не используем анимационное состояние — мгновенное значение без мигания
    if (!smoothAnimations) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(width = 136.dp, height = 64.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            neonColor.copy(alpha = 0.24f),
                            neonColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.85f
                    ),
                    radius = size.minDimension * 0.85f,
                    center = Offset(size.width / 2f, size.height / 2f)
                )
            }
            Row(
                modifier = Modifier.padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                targetText.forEach { ch ->
                    StaticNeonGlyph(glyph = ch.toString(), neonColor = neonColor, fontSize = fontSize)
                }
            }
        }
        return
    }

    var settledText by remember { mutableStateOf(targetText) }
    var activeFromText by remember { mutableStateOf<String?>(null) }
    var morphT by remember { mutableFloatStateOf(1f) }
    var morphSeq by remember { mutableIntStateOf(0) }

    LaunchedEffect(targetText) {
        if (targetText == settledText && activeFromText == null) {
            morphT = 1f
            return@LaunchedEffect
        }
        val fromCandidate = if (activeFromText != null && morphT < 1f) {
            settledText
        } else {
            settledText
        }
        if (fromCandidate == targetText) {
            settledText = targetText
            activeFromText = null
            morphT = 1f
            return@LaunchedEffect
        }

        activeFromText = fromCandidate
        settledText = targetText
        morphT = 0f
        val seq = ++morphSeq

        val duration = morphDurationMs.coerceIn(110, 260)
        val stepMs = 16L
        val startMs = System.currentTimeMillis()
        while (isActive && morphSeq == seq) {
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(0L)
            val raw = (elapsed.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            morphT = raw * raw * (3f - 2f * raw)
            if (raw >= 1f) break
            delay(stepMs)
        }
        if (morphSeq == seq) {
            morphT = 1f
            activeFromText = null
        }
    }

    val renderCounterBox: @Composable (Modifier) -> Unit = { boxMod ->
        Box(
            modifier = boxMod,
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(width = 136.dp, height = 64.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            neonColor.copy(alpha = 0.24f),
                            neonColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.85f
                    ),
                    radius = size.minDimension * 0.85f,
                    center = Offset(size.width / 2f, size.height / 2f)
                )
            }

            val fromStr = activeFromText
            if (fromStr == null || morphT >= 1f) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    settledText.forEach { ch ->
                        StaticNeonGlyph(glyph = ch.toString(), neonColor = neonColor, fontSize = fontSize)
                    }
                }
            } else {
                val maxLen = max(fromStr.length, settledText.length)
                val padFrom = fromStr.padStart(maxLen, ' ')
                val padTo = settledText.padStart(maxLen, ' ')
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    for (i in 0 until maxLen) {
                        val fCh = padFrom[i]
                        val tCh = padTo[i]
                        if (fCh == ' ' && tCh == ' ') continue
                        MorphingCharSlot(
                            fromChar = if (fCh == ' ') null else fCh,
                            toChar = tCh,
                            morphT = morphT,
                            neonColor = neonColor,
                            fontSize = fontSize
                        )
                    }
                }
            }
        }
    }

    SmoothCounterScaleBox(
        breathScale = breathScale,
        smoothAnimations = true,
        content = renderCounterBox
    )
}

@Composable
private fun GlassDialogWrapper(
    onDismiss: () -> Unit,
    smoothAnimations: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    var ready by remember(smoothAnimations) { mutableStateOf(!smoothAnimations) }
    LaunchedEffect(smoothAnimations) {
        if (smoothAnimations) {
            ready = true
        }
    }

    val materializeScale by animateFloatAsState(
        targetValue = if (!smoothAnimations || ready) 1f else 0.78f,
        animationSpec = if (smoothAnimations) {
            tween(durationMillis = 220, easing = FastOutSlowInEasing)
        } else {
            snap()
        },
        label = "dialogMaterializeScale"
    )
    val materializeAlpha by animateFloatAsState(
        targetValue = if (!smoothAnimations || ready) 1f else 0f,
        animationSpec = if (smoothAnimations) {
            tween(durationMillis = 190, easing = FastOutSlowInEasing)
        } else {
            snap()
        },
        label = "dialogMaterializeAlpha"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = true,
            decorFitsSystemWindows = true
        )
    ) {
        val dialogWindow = (androidx.compose.ui.platform.LocalView.current.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
        SideEffect {
            if (!smoothAnimations) {
                dialogWindow?.setWindowAnimations(0)
            }
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .scale(materializeScale)
                .graphicsLayer { alpha = materializeAlpha }
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.Transparent,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF1E293B).copy(alpha = 0.90f),
                                    Color(0xFF0F172A).copy(alpha = 0.95f)
                                )
                            )
                        )
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun RadialFourWayDialog(
    currentMode: PadMode,
    smoothAnimations: Boolean = true,
    secretMessage: String?,
    onSecretCenterTap: () -> Unit,
    onSelectMode: (PadMode) -> Unit,
    onSelectDashSilent: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val sectors = listOf(
        PadMode.SCHOOL,
        PadMode.CODING,
        PadMode.REST,
        PadMode.SLEEP,
        PadMode.EMPTY,
        PadMode.DEADLINE
    )
    // Начинаем сверху (-90°), чтобы первый сектор Школа был ровно на севере и обход шёл логично по часовой/против часовой
    val startAngle = -90f
    val sweepAngle = 360f / sectors.size.toFloat()
    val isDashMode = currentMode == PadMode.DASH
    val initialIdx = if (isDashMode) 0 else sectors.indexOf(currentMode).coerceAtLeast(0)

    fun normalizeDeg(deg: Float): Float {
        var d = deg % 360f
        if (d < 0f) d += 360f
        return d
    }

    fun shortestAngularDelta(fromDeg: Float, toDeg: Float): Float {
        val diff = ((toDeg - fromDeg + 180f) % 360f + 360f) % 360f - 180f
        return diff
    }

    var pendingMode by remember { mutableStateOf<PadMode?>(null) }
    var dashDissolveStarted by remember { mutableStateOf(false) }
    var circleWhiteAlpha by remember { mutableFloatStateOf(if (isDashMode) 0f else 0.92f) }
    var dashOutlineProgress by remember { mutableFloatStateOf(if (currentMode == PadMode.DASH) 1f else 0f) }
    var targetSectorAngle by remember { mutableFloatStateOf(startAngle + initialIdx * sweepAngle) }
    var animatedWhiteAngle by remember { mutableFloatStateOf(startAngle + initialIdx * sweepAngle) }

    LaunchedEffect(dashDissolveStarted, smoothAnimations) {
        if (!dashDissolveStarted) return@LaunchedEffect
        if (!smoothAnimations) {
            circleWhiteAlpha = 0f
            dashOutlineProgress = 1f
            dashDissolveStarted = false
            onSelectMode(PadMode.DASH)
            return@LaunchedEffect
        }
        val animMs = 380L
        val stepMs = 16L
        val startMs = System.currentTimeMillis()
        val startWhite = circleWhiteAlpha
        val startOutline = dashOutlineProgress
        while (isActive && dashDissolveStarted) {
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(0L)
            val raw = (elapsed.toFloat() / animMs.toFloat()).coerceIn(0f, 1f)
            val eased = raw * raw * (3f - 2f * raw)
            circleWhiteAlpha = (startWhite * (1f - eased)).coerceIn(0f, 1f)
            dashOutlineProgress = (startOutline + (1f - startOutline) * eased).coerceIn(0f, 1f)
            if (raw >= 1f) break
            delay(stepMs)
        }
        circleWhiteAlpha = 0f
        dashOutlineProgress = 1f
        dashDissolveStarted = false
        onSelectMode(PadMode.DASH)
    }

    LaunchedEffect(pendingMode, targetSectorAngle, smoothAnimations) {
        val chosen = pendingMode ?: return@LaunchedEffect
        if (!smoothAnimations) {
            animatedWhiteAngle = targetSectorAngle
            circleWhiteAlpha = 0.92f
            dashOutlineProgress = 0f
            pendingMode = null
            onSelectMode(chosen)
            return@LaunchedEffect
        }
        // Мягкий и нерезкий проход по кратчайшей дуге круга (420 мс, плавная кривая без резкого рывка)
        val travelMs = 420L
        val stepMs = 16L
        val fromAngle = animatedWhiteAngle
        val deltaAngle = shortestAngularDelta(fromAngle, targetSectorAngle)
        val startWhite = circleWhiteAlpha
        val startOutline = dashOutlineProgress
        val startMs = System.currentTimeMillis()
        while (isActive && pendingMode == chosen) {
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(0L)
            val raw = (elapsed.toFloat() / travelMs.toFloat()).coerceIn(0f, 1f)
            // Плавный старт и мягкое торможение (easeInOutCubic)
            val eased = if (raw < 0.5f) {
                4f * raw * raw * raw
            } else {
                val k = -2f * raw + 2f
                1f - (k * k * k) / 2f
            }
            animatedWhiteAngle = fromAngle + deltaAngle * eased
            circleWhiteAlpha = (startWhite + (0.92f - startWhite) * eased).coerceIn(0f, 1f)
            dashOutlineProgress = (startOutline * (1f - eased)).coerceIn(0f, 1f)
            if (raw >= 1f) break
            delay(stepMs)
        }
        if (pendingMode == chosen) {
            animatedWhiteAngle = targetSectorAngle
            circleWhiteAlpha = 0.92f
            dashOutlineProgress = 0f
            pendingMode = null
            onSelectMode(chosen)
        }
    }

    GlassDialogWrapper(onDismiss = onDismiss, smoothAnimations = smoothAnimations) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Выбор активности",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = currentMode.inverseNeonText
            )
            Text(
                text = "Тапните по сектору круга",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1)
            )

            BoxWithConstraints(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                val labelRadiusDp = (maxWidth.value * 0.31f)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(sectors, smoothAnimations, pendingMode) {
                            detectTapGestures { tap ->
                                if (pendingMode != null) return@detectTapGestures
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tap.x - center.x
                                val dy = tap.y - center.y
                                val r = min(size.width, size.height) / 2f
                                val innerHole = r * 0.20f
                                val dist = sqrt(dx * dx + dy * dy)

                                if (dist < innerHole) {
                                    onSecretCenterTap()
                                } else if (dist <= r) {
                                    val deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                    var rel = (deg - startAngle) % 360f
                                    if (rel < 0f) rel += 360f
                                    val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                    val chosenMode = sectors[index]
                                    val desiredNorm = normalizeDeg(startAngle + index * sweepAngle)
                                    val currentNorm = normalizeDeg(animatedWhiteAngle)
                                    val destAngle = animatedWhiteAngle + shortestAngularDelta(currentNorm, desiredNorm)
                                    if (smoothAnimations) {
                                        targetSectorAngle = destAngle
                                        pendingMode = chosenMode
                                    } else {
                                        animatedWhiteAngle = destAngle
                                        onSelectMode(chosenMode)
                                    }
                                }
                            }
                        }
                ) {
                    val diameter = min(size.width, size.height)
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    // Нижний слой: белая подложка/основа, которая при выборе сектора проезжает под нужный сектор,
                    // а при выборе "—" растворяется/уходит с круга
                    if (circleWhiteAlpha > 0.01f) {
                        val underTopLeft = Offset(topLeft.x - 2.dp.toPx(), topLeft.y - 2.dp.toPx())
                        val underSize = Size(diameter + 4.dp.toPx(), diameter + 4.dp.toPx())
                        drawArc(
                            color = Color.White.copy(alpha = circleWhiteAlpha),
                            startAngle = animatedWhiteAngle,
                            sweepAngle = sweepAngle,
                            useCenter = true,
                            topLeft = underTopLeft,
                            size = underSize
                        )
                    }

                    sectors.forEachIndexed { idx, mode ->
                        val sectorStart = startAngle + idx * sweepAngle
                        val activeVis = pendingMode ?: if (dashDissolveStarted) PadMode.DASH else currentMode
                        val isSelected = activeVis != PadMode.DASH && mode == activeVis
                        drawArc(
                            color = mode.accent.copy(alpha = if (isSelected) 0.90f else 0.56f),
                            startAngle = sectorStart,
                            sweepAngle = sweepAngle,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                    }

                    val outerRadius = diameter / 2f
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)
                    for (i in sectors.indices) {
                        val rad = ((startAngle + i * sweepAngle) * PI / 180.0).toFloat()
                        val endPt = Offset(
                            x = centerOffset.x + outerRadius * cos(rad),
                            y = centerOffset.y + outerRadius * sin(rad)
                        )
                        drawLine(
                            color = Color(0xFF0A0F1C),
                            start = centerOffset,
                            end = endPt,
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = diameter * 0.11f
                    )
                }

                sectors.forEachIndexed { idx, mode ->
                    val midAngleRad = ((startAngle + idx * sweepAngle + sweepAngle / 2f) * PI / 180.0)
                    val offsetX = (labelRadiusDp * cos(midAngleRad)).dp
                    val offsetY = (labelRadiusDp * sin(midAngleRad)).dp
                    Text(
                        text = mode.label,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = mode.inverseNeonText,
                        modifier = Modifier.offset(x = offsetX, y = offsetY)
                    )
                }
            }

            if (secretMessage != null) {
                Text(
                    text = secretMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFE2E8F0)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val effectiveOutline = max(dashOutlineProgress, if (currentMode == PadMode.DASH && !dashDissolveStarted && pendingMode == null) 1f else 0f)
                Surface(
                    onClick = {
                        if (dashDissolveStarted) return@Surface
                        pendingMode = null
                        dashDissolveStarted = true
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B).copy(alpha = 0.65f + 0.25f * effectiveOutline),
                    border = BorderStroke(
                        width = (1f + 1.5f * effectiveOutline).dp,
                        color = Color.White.copy(alpha = (0.35f + 0.65f * effectiveOutline).coerceIn(0f, 1f))
                    ),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "—",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = (0.78f + 0.22f * effectiveOutline).coerceIn(0f, 1f))
                        )
                    }
                }
                TextButton(
                    onClick = {
                        pendingMode = null
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f).height(42.dp)
                ) {
                    Text("Закрыть", color = Color(0xFFCBD5E1))
                }
            }
        }
    }
}

private data class GraphNode(
    val xRatio: Float,
    val yRatio: Float,
    val vx: Float,
    val vy: Float,
    val radiusDp: Float,
    val isVioletAccent: Boolean
)

@Composable
private fun SpaceVioletGraphBackground(
    backgroundTheme: Int = 1,
    smoothAnimations: Boolean,
    paceFactor: Float,
    modifier: Modifier = Modifier
) {
    val activeTheme = backgroundTheme.coerceIn(1, 4)
    val nodes = remember {
        val rng = Random(4207)
        List(22) { idx ->
            GraphNode(
                xRatio = 0.06f + rng.nextFloat() * 0.88f,
                yRatio = 0.06f + rng.nextFloat() * 0.88f,
                vx = (rng.nextFloat() - 0.5f) * 0.08f,
                vy = (rng.nextFloat() - 0.5f) * 0.08f,
                radiusDp = if (idx % 3 == 0) 4.4f else 2.8f,
                isVioletAccent = idx % 2 == 0
            )
        }
    }

    var crawlTime by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(smoothAnimations, paceFactor, activeTheme) {
        if (!smoothAnimations) {
            return@LaunchedEffect
        }
        while (isActive) {
            delay(32L)
            crawlTime += 0.018f * (0.45f + paceFactor * 1.55f)
        }
    }

    Canvas(modifier = modifier) {
        when (activeTheme) {
            1 -> {
                // Вариант 1: глубокий космос со звёздным полем и плавающими графами с конечными рёбрами
                drawRect(color = Color(0xFF03050B))

                for (s in 0 until 64) {
                    val sx = ((s * 97 + 13) % 1000) / 1000f * size.width
                    val sy = ((s * 53 + 29) % 1000) / 1000f * size.height
                    val twinkle = if (smoothAnimations) {
                        0.65f + 0.35f * sin((crawlTime * 1.4f + s * 0.7f).toDouble()).toFloat()
                    } else {
                        0.85f
                    }
                    val starColor = when (s % 4) {
                        0 -> Color(0xFFE2E8F0)
                        1 -> Color(0xFFBAE6FD)
                        2 -> Color(0xFFDDD6FE)
                        else -> Color(0xFFFDE68A)
                    }
                    val starRadius = if (s % 9 == 0) 2.2.dp.toPx() else 1.2.dp.toPx()
                    drawCircle(
                        color = starColor.copy(alpha = (0.35f + 0.45f * twinkle).coerceIn(0.15f, 0.9f)),
                        radius = starRadius,
                        center = Offset(sx, sy)
                    )
                }

                val pts = nodes.mapIndexed { i, n ->
                    val crawlX = if (smoothAnimations) {
                        sin((crawlTime * (0.7f + (i % 4) * 0.18f) + n.seedOffset(i)).toDouble()).toFloat() * 44f +
                            cos((crawlTime * 0.43f + i * 1.1f).toDouble()).toFloat() * 20f
                    } else {
                        0f
                    }
                    val crawlY = if (smoothAnimations) {
                        cos((crawlTime * (0.62f + (i % 3) * 0.22f) + i * 0.85f).toDouble()).toFloat() * 44f +
                            sin((crawlTime * 0.37f + i * 0.6f).toDouble()).toFloat() * 20f
                    } else {
                        0f
                    }
                    val px = (size.width * n.xRatio + crawlX).coerceIn(14f, size.width - 14f)
                    val py = (size.height * n.yRatio + crawlY).coerceIn(14f, size.height - 14f)
                    Offset(px, py)
                }

                val maxEdgeDist = min(size.width, size.height) * 0.34f
                for (i in pts.indices) {
                    for (j in i + 1 until pts.size) {
                        val dx = pts[i].x - pts[j].x
                        val dy = pts[i].y - pts[j].y
                        val dist = sqrt(dx * dx + dy * dy)
                        if (dist < maxEdgeDist) {
                            val closeness = 1f - (dist / maxEdgeDist)
                            val edgeColor = if (nodes[i].isVioletAccent || nodes[j].isVioletAccent) {
                                Color(0xFFA855F7)
                            } else {
                                Color(0xFF7DD3FC)
                            }
                            drawLine(
                                color = edgeColor.copy(alpha = (0.18f + closeness * 0.28f)),
                                start = pts[i],
                                end = pts[j],
                                strokeWidth = (1.1f + closeness * 1.1f).dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                // Конечные рёбра (ветки-отростки, оканчивающиеся свободной конечной точкой)
                pts.forEachIndexed { i, pt ->
                    if (i % 2 == 0) {
                        val branchAngle = (i * 1.35f + (if (smoothAnimations) crawlTime * 0.25f else 0f)).toDouble()
                        val branchLen = (24f + (i % 3) * 10f).dp.toPx()
                        val endPt = Offset(
                            x = (pt.x + cos(branchAngle).toFloat() * branchLen).coerceIn(10f, size.width - 10f),
                            y = (pt.y + sin(branchAngle).toFloat() * branchLen).coerceIn(10f, size.height - 10f)
                        )
                        drawLine(
                            color = Color(0xFFC084FC).copy(alpha = 0.45f),
                            start = pt,
                            end = endPt,
                            strokeWidth = 1.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        drawCircle(
                            color = Color(0xFFE9D5FF).copy(alpha = 0.75f),
                            radius = 2.dp.toPx(),
                            center = endPt
                        )
                    }
                }

                pts.forEachIndexed { i, pt ->
                    val n = nodes[i]
                    val nodeColor = if (n.isVioletAccent) Color(0xFFD8B4FE) else Color(0xFFBAE6FD)
                    val glowColor = if (n.isVioletAccent) Color(0xFF9333EA) else Color(0xFF38BDF8)
                    val rPx = n.radiusDp.dp.toPx()
                    drawCircle(color = glowColor.copy(alpha = 0.24f), radius = rPx * 2.4f, center = pt)
                    drawCircle(color = nodeColor.copy(alpha = 0.90f), radius = rPx, center = pt)
                }
            }

            2 -> {
                // Вариант 2 (детализированный): Космос в фиолетовых тонах — астролябия, созвездия и орбиты
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF070212),
                            Color(0xFF1E083A),
                            Color(0xFF2D0B52),
                            Color(0xFF080314)
                        )
                    )
                )
                // Тонкая радиальная сетка координат астролябии
                val center = Offset(size.width * 0.52f, size.height * 0.44f)
                val maxR = min(size.width, size.height) * 0.62f
                for (ray in 0 until 12) {
                    val ang = ray * (PI / 6.0)
                    val outerRay = Offset(
                        x = center.x + cos(ang).toFloat() * maxR,
                        y = center.y + sin(ang).toFloat() * maxR
                    )
                    drawLine(
                        color = Color(0xFFC084FC).copy(alpha = if (ray % 3 == 0) 0.18f else 0.08f),
                        start = center,
                        end = outerRay,
                        strokeWidth = 1.dp.toPx()
                    )
                }
                for (ring in 1..5) {
                    val rPx = maxR * (ring / 5f)
                    val rot = if (smoothAnimations) crawlTime * (0.35f * ring) else 0f
                    drawCircle(
                        color = Color(0xFFA855F7).copy(alpha = 0.16f + ring * 0.03f),
                        radius = rPx,
                        center = center,
                        style = Stroke(width = if (ring % 2 == 0) 1.5.dp.toPx() else 1.dp.toPx())
                    )
                    // Дуговой акцент орбиты
                    drawArc(
                        color = Color(0xFFE9D5FF).copy(alpha = 0.45f),
                        startAngle = (rot * 45f) % 360f,
                        sweepAngle = 54f,
                        useCenter = false,
                        topLeft = Offset(center.x - rPx, center.y - rPx),
                        size = Size(rPx * 2f, rPx * 2f),
                        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
                    )
                    val orbAngle = rot + ring * 1.15f
                    val orbPt = Offset(
                        x = center.x + rPx * cos(orbAngle.toDouble()).toFloat(),
                        y = center.y + rPx * sin(orbAngle.toDouble()).toFloat()
                    )
                    drawCircle(color = Color(0xFF9333EA).copy(alpha = 0.35f), radius = 10.dp.toPx(), center = orbPt)
                    drawCircle(color = Color(0xFFF3E8FF).copy(alpha = 0.90f), radius = 3.8.dp.toPx(), center = orbPt)
                }
                // Созвездие из связанных вершин с лучами
                val constPts = listOf(
                    Offset(size.width * 0.14f, size.height * 0.20f),
                    Offset(size.width * 0.28f, size.height * 0.14f),
                    Offset(size.width * 0.36f, size.height * 0.28f),
                    Offset(size.width * 0.22f, size.height * 0.36f),
                    Offset(size.width * 0.80f, size.height * 0.72f),
                    Offset(size.width * 0.88f, size.height * 0.58f),
                    Offset(size.width * 0.70f, size.height * 0.84f)
                )
                val links = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 0, 4 to 5, 4 to 6)
                for ((a, b) in links) {
                    drawLine(
                        color = Color(0xFFD8B4FE).copy(alpha = 0.32f),
                        start = constPts[a],
                        end = constPts[b],
                        strokeWidth = 1.2.dp.toPx()
                    )
                }
                constPts.forEachIndexed { idx, p ->
                    val tw = if (smoothAnimations) 0.7f + 0.3f * sin((crawlTime * 2f + idx).toDouble()).toFloat() else 1f
                    drawCircle(color = Color(0xFFE9D5FF).copy(alpha = 0.85f * tw), radius = 3.2.dp.toPx(), center = p)
                }
            }

            3 -> {
                // Вариант 3 (детализированный): Космос в фиолетовых тонах — многослойная туманность, спиральные вихри и звёздная пыль
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF140429),
                            Color(0xFF2B0A52),
                            Color(0xFF1A0636),
                            Color(0xFF070210)
                        )
                    )
                )
                val nebCenters = listOf(
                    Triple(0.24f, 0.24f, Color(0xFFC084FC)),
                    Triple(0.78f, 0.34f, Color(0xFFA855F7)),
                    Triple(0.50f, 0.74f, Color(0xFF7E22CE))
                )
                nebCenters.forEachIndexed { idx, (rx, ry, col) ->
                    val shiftX = if (smoothAnimations) sin((crawlTime * 0.6f + idx).toDouble()).toFloat() * 18f else 0f
                    val shiftY = if (smoothAnimations) cos((crawlTime * 0.5f + idx).toDouble()).toFloat() * 14f else 0f
                    val rad = max(size.width, size.height) * (0.48f - idx * 0.06f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                col.copy(alpha = 0.30f),
                                Color(0xFF581C87).copy(alpha = 0.16f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * rx + shiftX, size.height * ry + shiftY),
                            radius = rad
                        ),
                        radius = rad,
                        center = Offset(size.width * rx + shiftX, size.height * ry + shiftY)
                    )
                }
                // Спиральные нити туманности
                for (arm in 0..1) {
                    val baseRot = if (smoothAnimations) crawlTime * (if (arm == 0) 0.45f else -0.35f) else 0f
                    var prevPt: Offset? = null
                    for (step in 0..24) {
                        val frac = step / 24f
                        val theta = baseRot + arm * PI.toFloat() + frac * 3.8f
                        val r = frac * min(size.width, size.height) * 0.46f
                        val pt = Offset(
                            x = size.width * 0.5f + cos(theta.toDouble()).toFloat() * r,
                            y = size.height * 0.52f + sin(theta.toDouble()).toFloat() * r * 0.82f
                        )
                        if (prevPt != null) {
                            drawLine(
                                color = Color(0xFFE9D5FF).copy(alpha = (0.34f * (1f - frac * 0.6f)).coerceIn(0.05f, 0.4f)),
                                start = prevPt!!,
                                end = pt,
                                strokeWidth = (2.4f * (1f - frac * 0.5f)).dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                        prevPt = pt
                    }
                }
                // Мерцающие звёзды разных размеров с крестовым свечением
                for (k in 0 until 44) {
                    val fx = ((k * 79 + 17) % 100) / 100f
                    val fy = ((k * 43 + 29) % 100) / 100f
                    val driftX = if (smoothAnimations) cos((crawlTime * 0.8f + k).toDouble()).toFloat() * 12f else 0f
                    val pt = Offset(
                        x = (size.width * fx + driftX).coerceIn(8f, size.width - 8f),
                        y = (size.height * fy).coerceIn(8f, size.height - 8f)
                    )
                    val rStar = if (k % 5 == 0) 3.2.dp.toPx() else 1.7.dp.toPx()
                    drawCircle(
                        color = Color(0xFFF3E8FF).copy(alpha = if (k % 3 == 0) 0.85f else 0.45f),
                        radius = rStar,
                        center = pt
                    )
                    if (k % 7 == 0) {
                        val sparkle = 7.dp.toPx()
                        drawLine(
                            color = Color(0xFFE9D5FF).copy(alpha = 0.55f),
                            start = Offset(pt.x - sparkle, pt.y),
                            end = Offset(pt.x + sparkle, pt.y),
                            strokeWidth = 1.dp.toPx()
                        )
                        drawLine(
                            color = Color(0xFFE9D5FF).copy(alpha = 0.55f),
                            start = Offset(pt.x, pt.y - sparkle),
                            end = Offset(pt.x, pt.y + sparkle),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }
            }

            else -> {
                // Вариант 4 (детализированный): Тематика код в фиолетовых тонах — сетка, скобки/блоки, узлы ветвления и потоки данных
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF060210),
                            Color(0xFF1A0636),
                            Color(0xFF120426),
                            Color(0xFF05020C)
                        )
                    )
                )
                // Тонкая инженерная сетка кода на фоне
                val gridStep = 36.dp.toPx()
                var gx = 0f
                while (gx <= size.width) {
                    drawLine(
                        color = Color(0xFF9333EA).copy(alpha = 0.08f),
                        start = Offset(gx, 0f),
                        end = Offset(gx, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                    gx += gridStep
                }
                var gy = 0f
                while (gy <= size.height) {
                    drawLine(
                        color = Color(0xFF9333EA).copy(alpha = 0.08f),
                        start = Offset(0f, gy),
                        end = Offset(size.width, gy),
                        strokeWidth = 1.dp.toPx()
                    )
                    gy += gridStep
                }

                // Горизонтальные "строки кода" с отступами, маркерами скобок и подсветкой активных инструкций
                val codeLines = 18
                val lineSpacing = size.height / codeLines.toFloat()
                for (row in 0 until codeLines) {
                    val baseY = (row + 0.5f) * lineSpacing
                    val indentLevel = ((row * 3) % 4)
                    val xStart = (16f + indentLevel * 18f).dp.toPx()
                    val pulse = if (smoothAnimations) {
                        0.5f + 0.5f * sin((crawlTime * 2.1f + row * 0.65f).toDouble()).toFloat()
                    } else {
                        0.6f
                    }
                    // Номер строки / маркер блока
                    drawCircle(
                        color = Color(0xFFC084FC).copy(alpha = 0.25f + 0.45f * pulse),
                        radius = 2.2.dp.toPx(),
                        center = Offset(xStart - 8.dp.toPx(), baseY)
                    )
                    // 2-3 сегмента "токенов" в строке (ключевое слово, идентификатор, литерал)
                    val seg1Len = (24 + ((row * 17) % 36)).dp.toPx()
                    drawLine(
                        color = Color(0xFFD8B4FE).copy(alpha = 0.30f + 0.35f * pulse),
                        start = Offset(xStart, baseY),
                        end = Offset((xStart + seg1Len).coerceAtMost(size.width - 24f), baseY),
                        strokeWidth = 3.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                    val gap = 8.dp.toPx()
                    val seg2Start = xStart + seg1Len + gap
                    val seg2Len = (18 + ((row * 29) % 44)).dp.toPx()
                    if (seg2Start + seg2Len < size.width - 16f) {
                        drawLine(
                            color = Color(0xFFA855F7).copy(alpha = 0.22f + 0.30f * (1f - pulse)),
                            start = Offset(seg2Start, baseY),
                            end = Offset(seg2Start + seg2Len, baseY),
                            strokeWidth = 2.6.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Вертикальные бегущие потоки сигналов поверх строк кода
                val cols = 8
                val colWidth = size.width / cols.toFloat()
                for (c in 0 until cols) {
                    val xCenter = colWidth * (c + 0.5f)
                    val streamShift = if (smoothAnimations) {
                        ((crawlTime * 46f + c * 59f) % max(120f, size.height))
                    } else {
                        (c * 61f) % max(120f, size.height)
                    }
                    drawLine(
                        color = Color(0xFF7E22CE).copy(alpha = 0.16f),
                        start = Offset(xCenter, 0f),
                        end = Offset(xCenter, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                    for (s in 0 until 5) {
                        val yPos = ((s * (size.height / 5f) + streamShift) % size.height)
                        val packetLen = (14 + ((c + s) % 3) * 8).dp.toPx()
                        drawLine(
                            color = Color(0xFFF3E8FF).copy(alpha = if ((c + s) % 2 == 0) 0.58f else 0.32f),
                            start = Offset(xCenter, yPos),
                            end = Offset(xCenter, (yPos + packetLen).coerceAtMost(size.height)),
                            strokeWidth = 3.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
    }
}

private fun GraphNode.seedOffset(index: Int): Float = (xRatio * 13.7f + yRatio * 7.3f + index * 0.9f)



private object ScientificMathEngine {
    fun formatNumber(value: Double): String {
        if (value.isNaN()) return "Ошибка"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        val rounded = if (abs(value - kotlin.math.round(value)) < 1e-11) {
            kotlin.math.round(value).toDouble()
        } else {
            value
        }
        if (abs(rounded) >= 1e12 || (abs(rounded) > 0 && abs(rounded) < 1e-7)) {
            return String.format(Locale.US, "%.6g", rounded)
        }
        val asLong = rounded.toLong()
        if (rounded == asLong.toDouble() && abs(rounded) < 1e12) {
            return asLong.toString()
        }
        val formatted = String.format(Locale.US, "%.8f", rounded).trimEnd('0').trimEnd('.')
        return if (formatted.isEmpty() || formatted == "-0") "0" else formatted
    }

    fun evaluate(rawExpr: String, useRadians: Boolean = false): Result<Double> {
        return runCatching {
            val expr = normalizeExpression(rawExpr)
            require(expr.isNotEmpty()) { "Пустое выражение" }
            val tokens = tokenize(expr)
            val parser = Parser(tokens, useRadians = useRadians)
            val res = parser.parseExpression()
            require(parser.pos == tokens.size) { "Неожиданный символ" }
            require(!res.isNaN() && !res.isInfinite()) { "Недопустимая операция" }
            res
        }
    }

    private fun normalizeExpression(input: String): String {
        var s = input
            .replace("−", "-")
            .replace("–", "-")
            .replace("—", "-")
            .replace("×", "*")
            .replace("·", "*")
            .replace(":", "/")
            .replace("÷", "/")
            .replace("√", "sqrt")
            .replace("²", "^2")
            .replace("³", "^3")
            .replace("₀", "0")
            .replace("₁", "1")
            .replace("₂", "2")
            .replace("₃", "3")
            .replace("₄", "4")
            .replace("₅", "5")
            .replace("₆", "6")
            .replace("₇", "7")
            .replace("₈", "8")
            .replace("₉", "9")
            .replace("π", "(${PI})")
            .replace("pi", "(${PI})", ignoreCase = true)
            .replace("\s+".toRegex(), "")
            .replace(Regex("log_([0-9]+)\(", RegexOption.IGNORE_CASE), "log$1(")

        // Поддержка постфиксного квадрата вида число² или )² уже превращена в ^2,
        // а также неявного умножения вида 2(3), 2sin(30), (2)(3), sin(30)cos(60)
        s = s.replace("(?<=[0-9\)])(?=\()".toRegex(), "*")
        s = s.replace("(?<=[0-9\)])(?=[a-zA-Z])".toRegex(), "*")
        // Заменяем отдельную константу e (не в составе exp/sqrt/sin/cos/tan/asin/acos/atan/log)
        s = s.replace("(?<![a-zA-Z])e(?![a-zA-Z0-9_])".toRegex(), "(${kotlin.math.E})")
        return s
    }

    private sealed class Token {
        data class Num(val value: Double) : Token()
        data class Op(val symbol: String) : Token()
        data class Func(val name: String) : Token()
        data object Comma : Token()
        data object LParen : Token()
        data object RParen : Token()
    }

    private fun tokenize(s: String): List<Token> {
        val out = mutableListOf<Token>()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            when {
                ch.isDigit() || ch == '.' -> {
                    val start = i
                    var dotCount = 0
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) {
                        if (s[i] == '.') dotCount++
                        i++
                    }
                    require(dotCount <= 1) { "Некорректное число" }
                    val numStr = s.substring(start, i)
                    val v = numStr.toDoubleOrNull() ?: error("Некорректное число")
                    out.add(Token.Num(v))
                }
                ch.isLetter() -> {
                    val start = i
                    while (i < s.length && s[i].isLetter()) i++
                    val digitStart = i
                    while (i < s.length && s[i].isDigit()) i++
                    if (i > digitStart && (i >= s.length || s[i] != '(')) {
                        i = digitStart
                    }
                    val fn = s.substring(start, i).lowercase(Locale.ROOT)
                    out.add(Token.Func(fn))
                }
                ch == '(' -> {
                    out.add(Token.LParen)
                    i++
                }
                ch == ',' || ch == ';' -> {
                    out.add(Token.Comma)
                    i++
                }
                ch == ')' -> {
                    out.add(Token.RParen)
                    i++
                }
                ch in listOf('+', '-', '*', '/', '^') -> {
                    out.add(Token.Op(ch.toString()))
                    i++
                }
                else -> error("Неизвестный символ: $ch")
            }
        }
        return out
    }

    private class Parser(private val tokens: List<Token>, private val useRadians: Boolean = false) {
        var pos: Int = 0

        fun parseExpression(): Double = parseAddSub()

        private fun parseAddSub(): Double {
            var acc = parseMulDiv()
            while (pos < tokens.size) {
                val tok = tokens[pos]
                if (tok is Token.Op && (tok.symbol == "+" || tok.symbol == "-")) {
                    pos++
                    val rhs = parseMulDiv()
                    acc = if (tok.symbol == "+") acc + rhs else acc - rhs
                } else {
                    break
                }
            }
            return acc
        }

        private fun parseMulDiv(): Double {
            var acc = parsePower()
            while (pos < tokens.size) {
                val tok = tokens[pos]
                if (tok is Token.Op && (tok.symbol == "*" || tok.symbol == "/")) {
                    pos++
                    val rhs = parsePower()
                    if (tok.symbol == "/") {
                        require(abs(rhs) > 1e-15) { "Деление на ноль" }
                        acc /= rhs
                    } else {
                        acc *= rhs
                    }
                } else {
                    break
                }
            }
            return acc
        }

        private fun parsePower(): Double {
            var base = parseUnary()
            if (pos < tokens.size) {
                val tok = tokens[pos]
                if (tok is Token.Op && tok.symbol == "^") {
                    pos++
                    // Правоассоциативность для степени (например 2^3^2 = 2^(3^2))
                    val exp = parsePower()
                    base = Math.pow(base, exp)
                }
            }
            return base
        }

        private fun parseUnary(): Double {
            if (pos < tokens.size) {
                val tok = tokens[pos]
                if (tok is Token.Op && tok.symbol == "+") {
                    pos++
                    return parseUnary()
                }
                if (tok is Token.Op && tok.symbol == "-") {
                    pos++
                    return -parseUnary()
                }
            }
            return parsePrimary()
        }

        private fun parsePrimary(): Double {
            require(pos < tokens.size) { "Неожиданный конец выражения" }
            val tok = tokens[pos]
            return when (tok) {
                is Token.Num -> {
                    pos++
                    tok.value
                }
                is Token.LParen -> {
                    pos++
                    val inner = parseExpression()
                    require(pos < tokens.size && tokens[pos] is Token.RParen) { "Не закрыта скобка" }
                    pos++
                    inner
                }
                is Token.Func -> {
                    pos++
                    val args = mutableListOf<Double>()
                    if (pos < tokens.size && tokens[pos] is Token.LParen) {
                        pos++
                        args.add(parseExpression())
                        while (pos < tokens.size && tokens[pos] is Token.Comma) {
                            pos++
                            args.add(parseExpression())
                        }
                        require(pos < tokens.size && tokens[pos] is Token.RParen) { "Не закрыта скобка функции" }
                        pos++
                    } else {
                        args.add(parseUnary())
                    }
                    applyFunction(tok.name, args)
                }
                else -> error("Ожидалось число или выражение")
            }
        }

        private fun applyFunction(name: String, args: List<Double>): Double {
            require(args.isNotEmpty()) { "Отсутствует аргумент функции" }
            val arg = args[0]
            fun cleanResult(v: Double): Double {
                if (v.isNaN() || v.isInfinite()) return v
                if (abs(v) < 1e-13) return 0.0
                val nearInt = kotlin.math.round(v)
                if (abs(v - nearInt) < 1e-12) return nearInt
                return v
            }
            fun toRad(angle: Double): Double = if (useRadians) angle else angle * PI / 180.0

            return when (name) {
                "sin" -> {
                    require(args.size == 1) { "sin принимает 1 аргумент" }
                    if (useRadians) {
                        val twoPi = 2.0 * PI
                        val mod = ((arg % twoPi) + twoPi) % twoPi
                        if (abs(mod) < 1e-12 || abs(mod - PI) < 1e-12) 0.0
                        else if (abs(mod - PI / 2.0) < 1e-12) 1.0
                        else if (abs(mod - 3.0 * PI / 2.0) < 1e-12) -1.0
                        else cleanResult(kotlin.math.sin(arg))
                    } else {
                        val mod = ((arg % 360.0) + 360.0) % 360.0
                        if (abs(mod) < 1e-11 || abs(mod - 180.0) < 1e-11) 0.0
                        else if (abs(mod - 90.0) < 1e-11) 1.0
                        else if (abs(mod - 270.0) < 1e-11) -1.0
                        else cleanResult(kotlin.math.sin(toRad(arg)))
                    }
                }
                "cos" -> {
                    require(args.size == 1) { "cos принимает 1 аргумент" }
                    if (useRadians) {
                        val twoPi = 2.0 * PI
                        val mod = ((arg % twoPi) + twoPi) % twoPi
                        if (abs(mod - PI / 2.0) < 1e-12 || abs(mod - 3.0 * PI / 2.0) < 1e-12) 0.0
                        else if (abs(mod) < 1e-12) 1.0
                        else if (abs(mod - PI) < 1e-12) -1.0
                        else cleanResult(kotlin.math.cos(arg))
                    } else {
                        val mod = ((arg % 360.0) + 360.0) % 360.0
                        if (abs(mod - 90.0) < 1e-11 || abs(mod - 270.0) < 1e-11) 0.0
                        else if (abs(mod) < 1e-11) 1.0
                        else if (abs(mod - 180.0) < 1e-11) -1.0
                        else cleanResult(kotlin.math.cos(toRad(arg)))
                    }
                }
                "tan", "tg" -> {
                    require(args.size == 1) { "tan принимает 1 аргумент" }
                    if (useRadians) {
                        val piVal = PI
                        val mod = ((arg % piVal) + piVal) % piVal
                        require(abs(mod - piVal / 2.0) > 1e-12) { "tan(π/2) не определён" }
                        if (abs(mod) < 1e-12) 0.0 else cleanResult(kotlin.math.tan(arg))
                    } else {
                        val mod = ((arg % 180.0) + 180.0) % 180.0
                        require(abs(mod - 90.0) > 1e-11) { "tan(90°) не определён" }
                        if (abs(mod) < 1e-11) 0.0 else cleanResult(kotlin.math.tan(toRad(arg)))
                    }
                }
                "asin", "arcsin" -> {
                    require(arg in -1.0..1.0) { "arcsin вне [-1; 1]" }
                    val raw = kotlin.math.asin(arg)
                    cleanResult(if (useRadians) raw else raw * 180.0 / PI)
                }
                "acos", "arccos" -> {
                    require(arg in -1.0..1.0) { "arccos вне [-1; 1]" }
                    val raw = kotlin.math.acos(arg)
                    cleanResult(if (useRadians) raw else raw * 180.0 / PI)
                }
                "atan", "arctan" -> {
                    val raw = kotlin.math.atan(arg)
                    cleanResult(if (useRadians) raw else raw * 180.0 / PI)
                }
                "sqrt" -> {
                    require(arg >= 0.0) { "Корень из отрицательного числа" }
                    cleanResult(kotlin.math.sqrt(arg))
                }
                "cbrt" -> cleanResult(kotlin.math.cbrt(arg))
                "ln" -> {
                    require(args.size == 1) { "ln принимает 1 аргумент" }
                    require(arg > 0.0) { "ln определён для x > 0" }
                    cleanResult(kotlin.math.ln(arg))
                }
                "lg", "log", "log10" -> {
                    if (args.size == 2) {
                        val base = args[0]
                        val x = args[1]
                        require(base > 0.0 && abs(base - 1.0) > 1e-12) { "Недопустимое основание логарифма" }
                        require(x > 0.0) { "Аргумент логарифма должен быть > 0" }
                        cleanResult(kotlin.math.ln(x) / kotlin.math.ln(base))
                    } else {
                        require(args.size == 1) { "log принимает 1 или 2 аргумента" }
                        require(arg > 0.0) { "log определён для x > 0" }
                        cleanResult(kotlin.math.log10(arg))
                    }
                }
                "log2", "lb" -> {
                    require(args.size == 1) { "log2 принимает 1 аргумент" }
                    require(arg > 0.0) { "log2 определён для x > 0" }
                    cleanResult(kotlin.math.log2(arg))
                }
                "abs" -> kotlin.math.abs(arg)
                "exp" -> kotlin.math.exp(arg)
                else -> {
                    if (name.startsWith("log") && name.length > 3) {
                        val base = name.removePrefix("log").toDoubleOrNull()
                            ?: error("Неизвестная функция: $name")
                        require(args.size == 1) { "$name принимает 1 аргумент" }
                        require(base > 0.0 && abs(base - 1.0) > 1e-12) { "Недопустимое основание логарифма" }
                        require(arg > 0.0) { "Аргумент логарифма должен быть > 0" }
                        cleanResult(kotlin.math.ln(arg) / kotlin.math.ln(base))
                    } else {
                        error("Неизвестная функция: $name")
                    }
                }
            }
        }
    }
}


@Composable
private fun ScientificCalculatorDialog(
    smoothAnimations: Boolean,
    animDuration: Int,
    onDismiss: () -> Unit
) {
    var expr by remember { mutableStateOf("") }
    var livePreview by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var useRadians by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    fun recomputePreview(nextExpr: String, radMode: Boolean = useRadians) {
        if (nextExpr.isBlank()) {
            livePreview = ""
            isError = false
            return
        }
        ScientificMathEngine.evaluate(nextExpr, useRadians = radMode).fold(
            onSuccess = { valNum ->
                livePreview = ScientificMathEngine.formatNumber(valNum)
                isError = false
            },
            onFailure = {
                livePreview = ""
                isError = false
            }
        )
    }

    fun appendToken(tok: String) {
        val updated = expr + tok
        expr = updated
        recomputePreview(updated)
    }

    fun applySquareToCurrent() {
        if (expr.isBlank()) {
            appendToken("0²")
            return
        }
        val updated = if (expr.endsWith(")")) "$expr²" else "($expr)²"
        expr = updated
        recomputePreview(updated)
    }

    fun calculateNow() {
        if (expr.isBlank()) return
        ScientificMathEngine.evaluate(expr, useRadians = useRadians).fold(
            onSuccess = { res ->
                val formatted = ScientificMathEngine.formatNumber(res)
                history = (listOf(expr to formatted) + history).take(6)
                expr = formatted
                livePreview = ""
                isError = false
            },
            onFailure = { err ->
                livePreview = err.message ?: "Ошибка"
                isError = true
            }
        )
    }

    GlassDialogWrapper(onDismiss = onDismiss, smoothAnimations = smoothAnimations) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Калькулятор (свайп влево)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE9D5FF)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    onClick = {
                        val nextRad = !useRadians
                        useRadians = nextRad
                        recomputePreview(expr, radMode = nextRad)
                    },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(
                        text = if (useRadians) "RAD" else "DEG",
                        color = Color(0xFFFDE68A),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                TextButton(
                    onClick = onDismiss,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Закрыть", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        // Дисплей выражения и результата
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF070B14).copy(alpha = 0.88f),
            border = BorderStroke(1.dp, if (isError) Color(0xFFF87171) else Color(0xFFA855F7).copy(alpha = 0.65f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (history.isNotEmpty()) {
                    Text(
                        text = "${history.first().first} = ${history.first().second}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8),
                        maxLines = 1
                    )
                }
                Text(
                    text = if (expr.isEmpty()) "0" else expr,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF8FAFC),
                    maxLines = 2
                )
                Text(
                    text = if (livePreview.isNotEmpty()) {
                        if (isError) livePreview else "= $livePreview"
                    } else {
                        if (useRadians) "Тригонометрия (рад), ln, log10, log2, log(b,x), √, x²" else "Тригонометрия (град), ln, log10, log2, log(b,x), √, x²"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isError) Color(0xFFFCA5A5) else Color(0xFFD8B4FE),
                    maxLines = 1
                )
            }
        }

        // Научные функции: sin, cos, tan, ln, log10, log2, √, x², ^, (, ), π
        val sciRows = listOf(
            listOf("sin(" to "sin(", "cos(" to "cos(", "tan(" to "tan(", "√(" to "sqrt("),
            listOf("ln(" to "ln(", "log(" to "log(", "log10(" to "log10(", "log2(" to "log2("),
            listOf("(" to "(", ")" to ")", "," to ",", "^" to "^", "π" to "π", "x²" to "SQUARE")
        )
        sciRows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                row.forEach { (label, token) ->
                    ColoredGlassButton(
                        text = label,
                        tint = Color(0xFF7E22CE),
                        textColor = Color(0xFFF3E8FF),
                        smoothAnimations = smoothAnimations,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(38.dp),
                        onClick = {
                            if (token == "SQUARE") applySquareToCurrent() else appendToken(token)
                        }
                    )
                }
            }
        }

        // Управление и арифметика: C, ⌫, :, ×, −, +
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ColoredGlassButton(
                text = "C",
                tint = Color(0xFFDC2626),
                textColor = Color(0xFFFECACA),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(42.dp),
                onClick = {
                    expr = ""
                    livePreview = ""
                    isError = false
                }
            )
            ColoredGlassButton(
                text = "⌫",
                tint = Color(0xFF475569),
                textColor = Color(0xFFF8FAFC),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(42.dp),
                onClick = {
                    if (expr.isNotEmpty()) {
                        expr = expr.dropLast(1)
                        recomputePreview(expr)
                    }
                }
            )
            ColoredGlassButton(
                text = ":",
                tint = Color(0xFF0284C7),
                textColor = Color(0xFFE0F2FE),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(42.dp),
                onClick = { appendToken(":") }
            )
            ColoredGlassButton(
                text = "×",
                tint = Color(0xFF0284C7),
                textColor = Color(0xFFE0F2FE),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(42.dp),
                onClick = { appendToken("×") }
            )
        }

        val numRows = listOf(
            listOf("7", "8", "9", "−"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", ".")
        )
        numRows.forEach { r ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                r.forEach { key ->
                    val isOp = key in listOf("+", "−")
                    ColoredGlassButton(
                        text = key,
                        tint = if (isOp) Color(0xFF0284C7) else Color(0xFF334155),
                        textColor = if (isOp) Color(0xFFE0F2FE) else Color(0xFFF8FAFC),
                        smoothAnimations = smoothAnimations,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = { appendToken(key) }
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ColoredGlassButton(
                text = "0",
                tint = Color(0xFF334155),
                textColor = Color(0xFFF8FAFC),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(46.dp),
                onClick = { appendToken("0") }
            )
            ColoredGlassButton(
                text = "=",
                tint = Color(0xFF9333EA),
                textColor = Color(0xFFFDF4FF),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(2f).height(46.dp),
                onClick = { calculateNow() }
            )
        }
    }
}

private data class FallingEntity(
    val id: Int,
    val xRatio: Float, // 0.08..0.92
    val yRatio: Float, // -0.1..1.1
    val speedPerSec: Float,
    val isStar: Boolean
)

@Composable
private fun StarCatcherMiniGameDialog(
    savedBestScore: Int = 0,
    onSaveBestScore: (Int) -> Unit = {},
    smoothAnimations: Boolean,
    animDuration: Int,
    onDismiss: () -> Unit
) {
    var playerX by remember { mutableFloatStateOf(0.5f) } // 0.1..0.9
    var score by remember { mutableIntStateOf(0) }
    var bestScore by remember(savedBestScore) { mutableIntStateOf(max(savedBestScore, 0)) }
    var lives by remember { mutableIntStateOf(3) }
    var gameOver by remember { mutableStateOf(false) }
    var entities by remember { mutableStateOf<List<FallingEntity>>(emptyList()) }
    var nextId by remember { mutableIntStateOf(1) }

    fun resetGame() {
        playerX = 0.5f
        score = 0
        lives = 3
        gameOver = false
        entities = emptyList()
        nextId = 1
    }

    LaunchedEffect(gameOver) {
        if (gameOver) return@LaunchedEffect
        val rng = Random(System.currentTimeMillis().toInt())
        var lastTick = System.currentTimeMillis()
        var spawnAccum = 0f

        while (isActive && !gameOver) {
            delay(24L)
            val now = System.currentTimeMillis()
            val dt = ((now - lastTick).coerceAtLeast(1L) / 1000f).coerceAtMost(0.08f)
            lastTick = now

            spawnAccum += dt
            val spawnInterval = max(0.36f, 0.78f - score * 0.012f)
            var currentList = entities
            if (spawnAccum >= spawnInterval) {
                spawnAccum = 0f
                val isStar = rng.nextFloat() < 0.68f
                val speed = (0.34f + rng.nextFloat() * 0.22f + min(0.35f, score * 0.01f))
                currentList = currentList + FallingEntity(
                    id = nextId++,
                    xRatio = 0.10f + rng.nextFloat() * 0.80f,
                    yRatio = -0.06f,
                    speedPerSec = speed,
                    isStar = isStar
                )
            }

            val updated = mutableListOf<FallingEntity>()
            var deltaScore = 0
            var deltaLives = 0
            val playerY = 0.86f

            for (ent in currentList) {
                val ny = ent.yRatio + ent.speedPerSec * dt
                val hitY = abs(ny - playerY) < 0.075f
                val hitX = abs(ent.xRatio - playerX) < 0.13f
                if (hitY && hitX) {
                    if (ent.isStar) {
                        deltaScore += 1
                    } else {
                        deltaLives += 1
                    }
                } else if (ny <= 1.08f) {
                    updated.add(ent.copy(yRatio = ny))
                }
            }

            entities = updated
            if (deltaScore > 0) {
                score += deltaScore
                if (score > bestScore) {
                    bestScore = score
                    onSaveBestScore(score)
                }
            }
            if (deltaLives > 0) {
                lives = (lives - deltaLives).coerceAtLeast(0)
                if (lives == 0) {
                    gameOver = true
                }
            }
        }
    }

    GlassDialogWrapper(onDismiss = onDismiss, smoothAnimations = smoothAnimations) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Кнопка 5 • Звёздный ловец",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFDE68A)
            )
            Text(
                text = "★ $score  |  Рекорд $bestScore",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD8B4FE)
            )
        }

        Text(
            text = "Жизни: ${"♥".repeat(lives)}${"♡".repeat((3 - lives).coerceAtLeast(0))} • Лови ★, избегай ▲",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFFE2E8F0)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF090517),
                            Color(0xFF1A0933),
                            Color(0xFF070412)
                        )
                    )
                )
                .pointerInput(gameOver) {
                    if (!gameOver) {
                        detectTapGestures { tap ->
                            playerX = (tap.x / size.width.coerceAtLeast(1)).coerceIn(0.10f, 0.90f)
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Звёздное поле фона
                for (bgIdx in 0 until 28) {
                    val bx = ((bgIdx * 73 + 19) % 100) / 100f * w
                    val by = ((bgIdx * 41 + 11) % 100) / 100f * h
                    drawCircle(
                        color = Color(0xFFE9D5FF).copy(alpha = if (bgIdx % 3 == 0) 0.36f else 0.16f),
                        radius = if (bgIdx % 4 == 0) 2.1.dp.toPx() else 1.2.dp.toPx(),
                        center = Offset(bx, by)
                    )
                }

                // Падающие звёзды и метеориты
                for (ent in entities) {
                    val cx = w * ent.xRatio
                    val cy = h * ent.yRatio
                    if (ent.isStar) {
                        val outerR = 11.5.dp.toPx()
                        val innerR = 4.8.dp.toPx()
                        drawCircle(
                            color = Color(0xFFFDE047).copy(alpha = 0.25f),
                            radius = 18.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                        val starPath = androidx.compose.ui.graphics.Path().apply {
                            for (p in 0 until 10) {
                                val angle = -PI / 2.0 + p * (PI / 5.0)
                                val rad = if (p % 2 == 0) outerR else innerR
                                val sx = cx + cos(angle).toFloat() * rad
                                val sy = cy + sin(angle).toFloat() * rad
                                if (p == 0) moveTo(sx, sy) else lineTo(sx, sy)
                            }
                            close()
                        }
                        drawPath(path = starPath, color = Color(0xFFFACC15))
                        drawCircle(
                            color = Color(0xFFFEF9C3),
                            radius = 3.2.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    } else {
                        val r = 11.dp.toPx()
                        drawCircle(
                            color = Color(0xFFF43F5E).copy(alpha = 0.20f),
                            radius = 15.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                        val path = androidx.compose.ui.graphics.Path().apply {
                            moveTo(cx, cy - r)
                            lineTo(cx + r, cy + r * 0.85f)
                            lineTo(cx, cy + r * 0.55f)
                            lineTo(cx - r, cy + r * 0.85f)
                            close()
                        }
                        drawPath(path = path, color = Color(0xFFF43F5E))
                        drawCircle(
                            color = Color(0xFF881337),
                            radius = 2.6.dp.toPx(),
                            center = Offset(cx - r * 0.25f, cy + r * 0.15f)
                        )
                    }
                }

                // Игрок — фиолетово-золотая платформа-корабль
                val px = w * playerX
                val py = h * 0.86f
                val padHalfW = 28.dp.toPx()
                val padHalfH = 8.dp.toPx()
                drawRoundRect(
                    color = Color(0xFFC084FC).copy(alpha = 0.28f),
                    topLeft = Offset(px - padHalfW - 3.dp.toPx(), py - padHalfH - 2.dp.toPx()),
                    size = Size((padHalfW + 3.dp.toPx()) * 2f, (padHalfH + 2.dp.toPx()) * 2f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
                )
                drawRoundRect(
                    color = Color(0xFFA855F7),
                    topLeft = Offset(px - padHalfW, py - padHalfH),
                    size = Size(padHalfW * 2f, padHalfH * 2f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
                drawLine(
                    color = Color(0xFFF3E8FF).copy(alpha = 0.78f),
                    start = Offset(px - padHalfW * 0.65f, py - padHalfH * 0.45f),
                    end = Offset(px + padHalfW * 0.65f, py - padHalfH * 0.45f),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color(0xFFFDE68A),
                    radius = 5.dp.toPx(),
                    center = Offset(px, py)
                )
            }

            if (gameOver) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0F172A).copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, Color(0xFFF43F5E).copy(alpha = 0.8f)),
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Раунд окончен",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = "Собрано звёзд: $score (рекорд: $bestScore)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFD8B4FE)
                        )
                    }
                }
            }
        }

        Slider(
            value = playerX,
            onValueChange = { newX ->
                if (!gameOver) {
                    playerX = newX.coerceIn(0.10f, 0.90f)
                }
            },
            valueRange = 0.10f..0.90f,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ColoredGlassButton(
                text = if (gameOver) "Играть снова" else "Рестарт",
                tint = Color(0xFF9333EA),
                textColor = Color(0xFFFDF4FF),
                smoothAnimations = smoothAnimations,
                animDuration = animDuration,
                modifier = Modifier.weight(1f).height(42.dp),
                onClick = { resetGame() }
            )
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f).height(42.dp)
            ) {
                Text("Закрыть", color = Color(0xFFCBD5E1))
            }
        }
    }
}


private fun detectTrailingFormulaSuggestion(text: String): String? {
    if (!text.endsWith("=")) return null
    val withoutEq = text.dropLast(1)
    val match = Regex("([0-9a-zA-Zа-яА-Я.,_π√²³+\-*/:×÷^()]+)$").find(withoutEq)
        ?: return null
    val expr = match.value
    if (!Regex("[+\-*/:×÷^()]").containsMatchIn(expr)) return null
    return ScientificMathEngine.evaluate(expr).fold(
        onSuccess = { res ->
            if (res.isNaN() || res.isInfinite()) null else ScientificMathEngine.formatNumber(res)
        },
        onFailure = { null }
    )
}

@Composable
private fun NotebookSlideOutPanel(
    visible: Boolean,
    notebookEntries: List<NotebookEntry>,
    quickNotes: List<QuickNote>,
    smoothAnimations: Boolean,
    animDuration: Int,
    onAddEntry: (String, String) -> Unit,
    onUpdateEntry: (Long, String, String) -> Unit,
    onDeleteEntry: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var editingId by remember { mutableStateOf<Long?>(null) }
    var openedEntryId by remember { mutableStateOf<Long?>(null) }
    var titleInput by remember { mutableStateOf("") }
    var bodyInput by remember { mutableStateOf("") }
    var sortByTitle by remember { mutableStateOf(false) }

    val suggestion = remember(bodyInput) { detectTrailingFormulaSuggestion(bodyInput) }

    val sortedEntries = remember(notebookEntries, sortByTitle) {
        if (sortByTitle) {
            notebookEntries.sortedBy { it.title.lowercase(Locale.getDefault()) }
        } else {
            notebookEntries.sortedByDescending { it.createdAt }
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = if (smoothAnimations) {
            slideInHorizontally(
                initialOffsetX = { -it },
                animationSpec = tween(durationMillis = animDuration.coerceAtLeast(160), easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(durationMillis = animDuration.coerceAtLeast(140)))
        } else {
            EnterTransition.None
        },
        exit = if (smoothAnimations) {
            slideOutHorizontally(
                targetOffsetX = { -it },
                animationSpec = tween(durationMillis = animDuration.coerceAtLeast(140), easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(durationMillis = animDuration.coerceAtLeast(120)))
        } else {
            ExitTransition.None
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.52f))
                .pointerInput(Unit) {
                    detectTapGestures { onDismiss() }
                }
        ) {
            Surface(
                shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                color = Color(0xFF0B1020).copy(alpha = 0.98f),
                border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.92f)
                    .align(Alignment.CenterStart)
                    .pointerInput(Unit) {
                        var startX = 0f
                        var startY = 0f
                        var swipedBack = false
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                val down = event.changes.firstOrNull { it.pressed }
                                if (down != null) {
                                    if (!swipedBack && startX == 0f && startY == 0f) {
                                        startX = down.position.x
                                        startY = down.position.y
                                    } else if (!swipedBack) {
                                        val dx = down.position.x - startX
                                        val dy = down.position.y - startY
                                        if (dx < -105f && abs(dx) > abs(dy) * 1.35f) {
                                            swipedBack = true
                                            onDismiss()
                                        }
                                    }
                                } else {
                                    startX = 0f
                                    startY = 0f
                                    swipedBack = false
                                }
                            }
                        }
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Блокнот",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE9D5FF)
                        )
                        TextButton(
                            onClick = {
                                editingId = null
                                onDismiss()
                            }
                        ) {
                            Text("Закрыть", color = Color(0xFFCBD5E1))
                        }
                    }

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it.replace("\n", " ") },
                        singleLine = true,
                        label = { Text("Название") },
                        placeholder = { Text("Одна строка") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = bodyInput,
                        onValueChange = { bodyInput = it },
                        minLines = 3,
                        maxLines = 8,
                        label = { Text("Текст") },
                        placeholder = { Text("Любое число строк; например 2+3=") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (suggestion != null) {
                        Surface(
                            onClick = { bodyInput += suggestion },
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF1E293B).copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, Color(0xFF94A3B8).copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = suggestion,
                                    color = Color(0xFF94A3B8),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "Нажмите для вставки",
                                    color = Color(0xFF64748B),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ColoredGlassButton(
                            text = if (editingId != null) "Сохранить правку" else "Сохранить",
                            tint = Color(0xFF9333EA),
                            textColor = Color(0xFFFDF4FF),
                            smoothAnimations = smoothAnimations,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(42.dp),
                            onClick = {
                                if (titleInput.isNotBlank() || bodyInput.isNotBlank()) {
                                    val activeEditId = editingId
                                    if (activeEditId != null) {
                                        onUpdateEntry(activeEditId, titleInput, bodyInput)
                                        editingId = null
                                    } else {
                                        onAddEntry(titleInput, bodyInput)
                                    }
                                    titleInput = ""
                                    bodyInput = ""
                                }
                            }
                        )
                        ColoredGlassButton(
                            text = if (sortByTitle) "Сорт: Название" else "Сорт: Дата",
                            tint = Color(0xFF334155),
                            textColor = Color(0xFFE2E8F0),
                            smoothAnimations = smoothAnimations,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(42.dp),
                            onClick = { sortByTitle = !sortByTitle }
                        )
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (sortedEntries.isNotEmpty()) {
                            item {
                                Text(
                                    text = "Записи блокнота (${sortedEntries.size})",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD8B4FE)
                                )
                            }
                            items(sortedEntries, key = { it.id }) { item ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFF0F172A).copy(alpha = 0.88f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (editingId == item.id) Color(0xFFFDE68A) else Color(0xFFA855F7).copy(alpha = 0.35f)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = item.title,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFF8FAFC),
                                                style = MaterialTheme.typography.bodyMedium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = item.timestamp,
                                                color = Color(0xFF94A3B8),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                        if (item.text.isNotBlank()) {
                                            Text(
                                                text = item.text,
                                                color = Color(0xFFE2E8F0),
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            ColoredGlassButton(
                                                text = "Открыть",
                                                badgeGlyph = "↗",
                                                tint = Color(0xFF7E22CE),
                                                textColor = Color(0xFFF3E8FF),
                                                smoothAnimations = smoothAnimations,
                                                animDuration = animDuration,
                                                modifier = Modifier.height(34.dp).width(124.dp),
                                                onClick = { openedEntryId = item.id }
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                TextButton(
                                                    onClick = {
                                                        editingId = item.id
                                                        titleInput = item.title
                                                        bodyInput = item.text
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Изменить", color = Color(0xFFD8B4FE), style = MaterialTheme.typography.labelSmall)
                                                }
                                                TextButton(
                                                    onClick = {
                                                        if (editingId == item.id) {
                                                            editingId = null
                                                            titleInput = ""
                                                            bodyInput = ""
                                                        }
                                                        if (openedEntryId == item.id) {
                                                            openedEntryId = null
                                                        }
                                                        onDeleteEntry(item.id)
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Удалить", color = Color(0xFFF87171), style = MaterialTheme.typography.labelSmall)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (quickNotes.isNotEmpty()) {
                            item {
                                Text(
                                    text = "Заметки с главного экрана (${quickNotes.size})",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF93C5FD)
                                )
                            }
                            items(quickNotes, key = { "main_${it.id}" }) { qn ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFF0F172A).copy(alpha = 0.72f),
                                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.30f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Text(
                                            text = qn.timestamp,
                                            color = Color(0xFF94A3B8),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                        Text(
                                            text = qn.text,
                                            color = Color(0xFFE2E8F0),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }

                        if (sortedEntries.isEmpty() && quickNotes.isEmpty()) {
                            item {
                                Text(
                                    text = "Записей пока нет",
                                    color = Color(0xFF94A3B8),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            val openedEntry = notebookEntries.firstOrNull { it.id == openedEntryId }
            if (openedEntry != null) {
                Surface(
                    color = Color(0xFF070B16).copy(alpha = 0.99f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 18.dp, vertical = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = openedEntry.title,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF8FAFC)
                                )
                                Text(
                                    text = openedEntry.timestamp,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            TextButton(onClick = { openedEntryId = null }) {
                                Text("Назад", color = Color(0xFFD8B4FE), fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(color = Color(0xFFA855F7).copy(alpha = 0.35f))

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = openedEntry.text.ifBlank { "Пустая запись" },
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color(0xFFE2E8F0)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ColoredGlassButton(
                                text = "Изменить",
                                badgeGlyph = "✎",
                                tint = Color(0xFF7E22CE),
                                textColor = Color(0xFFF3E8FF),
                                smoothAnimations = smoothAnimations,
                                animDuration = animDuration,
                                modifier = Modifier.weight(1f).height(44.dp),
                                onClick = {
                                    editingId = openedEntry.id
                                    titleInput = openedEntry.title
                                    bodyInput = openedEntry.text
                                    openedEntryId = null
                                }
                            )
                            ColoredGlassButton(
                                text = "Удалить",
                                badgeGlyph = "✕",
                                tint = Color(0xFFDC2626),
                                textColor = Color(0xFFFECACA),
                                smoothAnimations = smoothAnimations,
                                animDuration = animDuration,
                                modifier = Modifier.weight(1f).height(44.dp),
                                onClick = {
                                    val targetDelete = openedEntry.id
                                    openedEntryId = null
                                    if (editingId == targetDelete) {
                                        editingId = null
                                        titleInput = ""
                                        bodyInput = ""
                                    }
                                    onDeleteEntry(targetDelete)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
