package com.example.fourbuttonpad

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class QuickNote(
    val id: Long,
    val timestamp: String,
    val text: String,
    val modeName: String = PadMode.SCHOOL.name
)

enum class PadMode(
    val label: String,
    val accent: Color,
    val inverseNeonText: Color,
    val buttonBrightText: Color,
    val defaultSeconds: Int?,
    val supportsTimer: Boolean
) {
    SCHOOL(
        label = "Школа",
        accent = Color(0xFFE11D48),
        inverseNeonText = Color(0xFF5EEAD4),
        buttonBrightText = Color(0xFFFFA3B5),
        defaultSeconds = 40 * 60,
        supportsTimer = true
    ),
    CODING(
        label = "Коддинг",
        accent = Color(0xFF9333EA),
        inverseNeonText = Color(0xFFBEF264),
        buttonBrightText = Color(0xFFD8B4FE),
        defaultSeconds = 60 * 60,
        supportsTimer = true
    ),
    REST(
        label = "Отдых",
        accent = Color(0xFF84CC16),
        inverseNeonText = Color(0xFFC084FC),
        buttonBrightText = Color(0xFFD9F99D),
        defaultSeconds = null,
        supportsTimer = true
    ),
    SLEEP(
        label = "Сон",
        accent = Color(0xFF93C5FD),
        inverseNeonText = Color(0xFFFDE68A),
        buttonBrightText = Color(0xFFDBEAFE),
        defaultSeconds = null,
        supportsTimer = false
    ),
    EMPTY(
        label = "Пусто",
        accent = Color(0xFF64748B),
        inverseNeonText = Color(0xFFE2E8F0),
        buttonBrightText = Color(0xFFF1F5F9),
        defaultSeconds = null,
        supportsTimer = false
    ),
    DEADLINE(
        label = "Дедлайн",
        accent = Color(0xFFF97316),
        inverseNeonText = Color(0xFF38BDF8),
        buttonBrightText = Color(0xFFFDBA74),
        defaultSeconds = null,
        supportsTimer = true
    );

    companion object {
        fun fromName(name: String?): PadMode {
            if (name == "STUDY") return SCHOOL
            return runCatching { valueOf(name ?: "") }.getOrDefault(SCHOOL)
        }
    }
}

data class AppSettings(
    val notificationsEnabled: Boolean = true,
    val codingVibrationEnabled: Boolean = true,
    val smoothAnimationsEnabled: Boolean = true,
    // Реально работающий ползунок: задаёт темп/интенсивность дыхания UI (0..100), влияет на скорость пульсации и шаг прокрутки
    val uiPacePercent: Float = 50f,
    // 4-конечный ползунок оформления фона (1..4): 1 — исходный космос, 2–3 — тематика космос в фиолетовых тонах, 4 — тематика код в фиолетовых тонах
    val backgroundTheme: Int = 1
)

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.SCHOOL,
    val remainingSeconds: Int = 40 * 60,
    val isTimerRunning: Boolean = false,
    val restTimerFinished: Boolean = false,
    val schoolFinishedDateKey: String = "",
    val deadlineHour: Int = 18,
    val deadlineMinute: Int = 0,
    val deadlineActive: Boolean = false,
    val deadlineTriggeredKey: String = "",
    val notes: List<QuickNote> = emptyList(),
    val settings: AppSettings = AppSettings()
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val mode = PadMode.fromName(obj.optString("mode", PadMode.SCHOOL.name))
            val defaultSec = mode.defaultSeconds ?: 0
            val remainingSeconds = obj.optInt("remainingSeconds", defaultSec).coerceAtLeast(0)
            val isTimerRunning = if (mode.supportsTimer) obj.optBoolean("isTimerRunning", false) else false
            val restTimerFinished = if (mode == PadMode.REST) obj.optBoolean("restTimerFinished", false) else false
            val schoolFinishedDateKey = obj.optString("schoolFinishedDateKey", "")
            val deadlineHour = obj.optInt("deadlineHour", 18).coerceIn(6, 23)
            val rawDeadlineMin = obj.optInt("deadlineMinute", 0)
            val deadlineMinute = if (rawDeadlineMin in listOf(0, 15, 30, 45)) rawDeadlineMin else 0
            val deadlineActive = obj.optBoolean("deadlineActive", false)
            val deadlineTriggeredKey = obj.optString("deadlineTriggeredKey", "")

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    val rawStamp = item.optString("timestamp", "").ifBlank {
                        item.optString("time", "01.01.26, 00:00")
                    }
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            timestamp = rawStamp,
                            text = item.optString("text", ""),
                            modeName = PadMode.fromName(item.optString("modeName", mode.name)).name
                        )
                    )
                }
            }

            val settingsObj = obj.optJSONObject("settings") ?: JSONObject()
            val settings = AppSettings(
                notificationsEnabled = settingsObj.optBoolean("notificationsEnabled", true),
                codingVibrationEnabled = settingsObj.optBoolean("codingVibrationEnabled", true),
                smoothAnimationsEnabled = settingsObj.optBoolean("smoothAnimationsEnabled", true),
                uiPacePercent = settingsObj.optDouble("uiPacePercent", 50.0).toFloat().coerceIn(0f, 100f),
                backgroundTheme = settingsObj.optInt("backgroundTheme", 1).coerceIn(1, 4)
            )

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                restTimerFinished = restTimerFinished,
                schoolFinishedDateKey = schoolFinishedDateKey,
                deadlineHour = deadlineHour,
                deadlineMinute = deadlineMinute,
                deadlineActive = deadlineActive,
                deadlineTriggeredKey = deadlineTriggeredKey,
                notes = notes,
                settings = settings
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)
            put("restTimerFinished", state.restTimerFinished)
            put("schoolFinishedDateKey", state.schoolFinishedDateKey)
            put("deadlineHour", state.deadlineHour)
            put("deadlineMinute", state.deadlineMinute)
            put("deadlineActive", state.deadlineActive)
            put("deadlineTriggeredKey", state.deadlineTriggeredKey)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("timestamp", n.timestamp)
                        put("text", n.text)
                        put("modeName", n.modeName)
                    }
                )
            }
            put("notes", arr)

            put(
                "settings",
                JSONObject().apply {
                    put("notificationsEnabled", state.settings.notificationsEnabled)
                    put("codingVibrationEnabled", state.settings.codingVibrationEnabled)
                    put("smoothAnimationsEnabled", state.settings.smoothAnimationsEnabled)
                    put("uiPacePercent", state.settings.uiPacePercent.toDouble())
                    put("backgroundTheme", state.settings.backgroundTheme.coerceIn(1, 4))
                }
            )
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

object AlertHelper {
    const val CHANNEL_SCHOOL_NO_VIBRATE = "kuro_school_silent_v6"
    const val CHANNEL_CODING_VIBRATE = "kuro_coding_vibrate_v6"
    const val CHANNEL_ONGOING_QUIET = "kuro_ongoing_quiet_v6"

    private const val TIMER_DONE_ID = 1001
    const val ONGOING_STATUS_ID = 2001
    @Volatile
    private var lastOngoingContentKey: String? = null

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val schoolChannel = NotificationChannel(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Школа — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Школа без вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
            }

            val codingChannel = NotificationChannel(
                CHANNEL_CODING_VIBRATE,
                "Коддинг — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Внешнее уведомление по окончании таймера в режиме Коддинг с вибрацией"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 300L, 150L, 300L)
            }

            val ongoingQuietChannel = NotificationChannel(
                CHANNEL_ONGOING_QUIET,
                "Сон и Отдых — постоянный статус",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Постоянное статус-уведомление для режимов Сон и Отдых без звука и вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
                setShowBadge(false)
            }

            manager.createNotificationChannel(schoolChannel)
            manager.createNotificationChannel(codingChannel)
            manager.createNotificationChannel(ongoingQuietChannel)
        }
    }

    private fun createReturnToAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags)
    }

    fun canNotify(context: Context, settings: AppSettings): Boolean {
        if (!settings.notificationsEnabled) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun isOngoingNotificationPresent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return runCatching {
                manager.activeNotifications.any { it.id == ONGOING_STATUS_ID }
            }.getOrDefault(false)
        }
        return false
    }

    fun showTimerDoneNotification(context: Context, mode: PadMode, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val (channelId, title, message, vibrateEnabled) = when (mode) {
            PadMode.CODING -> Quadruple(
                CHANNEL_CODING_VIBRATE,
                "Помощник Куро — Коддинг",
                "Таймер закончился. Пора отдохнуть.",
                settings.codingVibrationEnabled
            )
            PadMode.SCHOOL -> Quadruple(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Помощник Куро — Школа",
                "Урок кончился? Есть что записать? Я здесь.",
                false
            )
            else -> return
        }

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1101)
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(!vibrateEnabled)
            .setAutoCancel(true)
            .apply {
                if (vibrateEnabled) {
                    setVibrate(longArrayOf(0L, 300L, 150L, 300L))
                } else {
                    setVibrate(longArrayOf(0L))
                }
            }
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun showDeadlineNotification(context: Context, targetTimeText: String, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1103)
        val notification = NotificationCompat.Builder(context, CHANNEL_CODING_VIBRATE)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle("Помощник Куро — Дедлайн")
            .setContentText("дедлайн ($targetTimeText)")
            .setStyle(NotificationCompat.BigTextStyle().bigText("дедлайн ($targetTimeText)"))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(!settings.codingVibrationEnabled)
            .setAutoCancel(true)
            .apply {
                if (settings.codingVibrationEnabled) {
                    setVibrate(longArrayOf(0L, 300L, 150L, 300L))
                } else {
                    setVibrate(longArrayOf(0L))
                }
            }
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    fun showRestDoneExternalNotification(context: Context, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val message = "Отдых кончился... Вернемся к работе?"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 1102)
        val notification = NotificationCompat.Builder(context, CHANNEL_SCHOOL_NO_VIBRATE)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle("Помощник Куро — Отдых")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    private fun createLargeStarBitmap(context: Context): android.graphics.Bitmap? {
        return runCatching {
            val sizePx = (96f * context.resources.displayMetrics.density).toInt().coerceAtLeast(192)
            val bmp = android.graphics.Bitmap.createBitmap(sizePx, sizePx, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            val bgPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#0A0F1C")
            }
            canvas.drawRoundRect(0f, 0f, sizePx.toFloat(), sizePx.toFloat(), sizePx * 0.24f, sizePx * 0.24f, bgPaint)

            val drawable = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.ic_launcher_la_star)
            if (drawable != null) {
                val pad = (sizePx * 0.10f).toInt()
                drawable.setBounds(pad, pad, sizePx - pad, sizePx - pad)
                drawable.draw(canvas)
            }
            bmp
        }.getOrNull()
    }

    private fun resolveOngoingMessage(
        mode: PadMode,
        restTimerFinished: Boolean,
        schoolFinishedDateKey: String = ""
    ): String? {
        return when (mode) {
            PadMode.SCHOOL -> SchoolBellSchedule.evaluateNow(finishedDateKey = schoolFinishedDateKey).notificationText
            PadMode.SLEEP -> "Вы спите?"
            PadMode.REST -> {
                if (restTimerFinished) {
                    "Отдых кончился... Вернемся к работе?"
                } else {
                    "Ждём, когда Вы отдохнете... Не торопитесь, я здесь."
                }
            }
            else -> null
        }
    }

    fun buildOngoingNotification(
        context: Context,
        mode: PadMode,
        restTimerFinished: Boolean,
        settings: AppSettings,
        schoolFinishedDateKey: String = ""
    ): android.app.Notification? {
        if (!canNotify(context, settings)) return null
        val message = resolveOngoingMessage(mode, restTimerFinished, schoolFinishedDateKey) ?: return null

        val title = "Помощник Куро — ${mode.label}"
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 2101)
        val largeIcon = createLargeStarBitmap(context)
        return NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply {
                if (largeIcon != null) setLargeIcon(largeIcon)
            }
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setAutoCancel(false)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .build()
    }

    fun syncOngoingModeNotification(
        context: Context,
        mode: PadMode,
        restTimerFinished: Boolean,
        settings: AppSettings,
        schoolFinishedDateKey: String = "",
        forceRecreate: Boolean = false
    ) {
        if (!canNotify(context, settings)) {
            cancelOngoingNotification(context)
            return
        }

        val message = resolveOngoingMessage(mode, restTimerFinished, schoolFinishedDateKey)
        if (message == null) {
            cancelOngoingNotification(context)
            return
        }

        val contentKey = "${mode.name}|$message"
        val isPresent = isOngoingNotificationPresent(context)

        // Повторяем/создаём уведомление ТОЛЬКО если оно отсутствует в панели уведомлений
        // или если реально изменился режим/текст уведомления (но не при клике на счётчик)
        if (isPresent && !forceRecreate && lastOngoingContentKey == contentKey) {
            return
        }

        val notification = buildOngoingNotification(
            context = context,
            mode = mode,
            restTimerFinished = restTimerFinished,
            settings = settings,
            schoolFinishedDateKey = schoolFinishedDateKey
        ) ?: return
        lastOngoingContentKey = contentKey
        runCatching {
            NotificationManagerCompat.from(context).notify(ONGOING_STATUS_ID, notification)
        }
    }

    private const val SCHEDULED_REMINDER_ID = 3001
    private const val REST_IDLE_REMINDER_ID = 3002

    fun showScheduledReminderNotification(context: Context, title: String, message: String, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 3101)
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .apply { createLargeStarBitmap(context)?.let { setLargeIcon(it) } }
            .setShowWhen(false)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(SCHEDULED_REMINDER_ID, notification)
        }
    }

    fun showRestIdleReminderNotification(context: Context, settings: AppSettings) {
        if (!canNotify(context, settings)) return

        val message = "Вы про нас забыли? Возвращайтесь. Я скучаю."
        val contentIntent = createReturnToAppPendingIntent(context, requestCode = 3102)
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(R.drawable.ic_notif_la_star)
            .setContentTitle("Помощник Куро — Отдых")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(REST_IDLE_REMINDER_ID, notification)
        }
    }

    fun cancelOngoingNotification(context: Context) {
        lastOngoingContentKey = null
        runCatching {
            NotificationManagerCompat.from(context).cancel(ONGOING_STATUS_ID)
        }
    }

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D
    )
}

class ScheduledReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: return
        val store = MemoryStore(File(context.filesDir, "pad_memory.json"))
        val state = store.load()
        AlertHelper.ensureChannels(context)

        val cal = java.util.Calendar.getInstance()
        val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val isWeekday = dayOfWeek in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY

        when (kind) {
            ReminderScheduler.KIND_BEDTIME_2200 -> {
                AlertHelper.showScheduledReminderNotification(
                    context = context,
                    title = "Помощник Куро — Вечер",
                    message = "Сон важен. Готовьтесь ко сну. Набирайтесь сил.",
                    settings = state.settings
                )
                ReminderScheduler.scheduleNextBedtime(context)
            }
            ReminderScheduler.KIND_WAKE_0630 -> {
                if (isWeekday) {
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Утро",
                        message = "Вам пора вставать.",
                        settings = state.settings
                    )
                }
                ReminderScheduler.scheduleNextWeekdayWake(context)
            }
        }
    }
}

object ReminderScheduler {
    const val EXTRA_KIND = "reminder_kind"
    const val KIND_BEDTIME_2200 = "bedtime_2200"
    const val KIND_WAKE_0630 = "wake_0630"

    private const val REQ_BEDTIME = 4101
    private const val REQ_WAKE = 4102

    fun scheduleAll(context: Context) {
        scheduleNextBedtime(context)
        scheduleNextWeekdayWake(context)
    }

    fun scheduleNextBedtime(context: Context) {
        val now = System.currentTimeMillis()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 22)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        }
        setAlarm(context, target.timeInMillis, REQ_BEDTIME, KIND_BEDTIME_2200)
    }

    fun scheduleNextWeekdayWake(context: Context) {
        val now = System.currentTimeMillis()
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 6)
            set(java.util.Calendar.MINUTE, 30)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            while (get(java.util.Calendar.DAY_OF_WEEK) !in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY) {
                add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        }
        setAlarm(context, target.timeInMillis, REQ_WAKE, KIND_WAKE_0630)
    }

    private fun setAlarm(context: Context, triggerAtMs: Long, reqCode: Int, kind: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager ?: return
        val intent = Intent(context, ScheduledReminderReceiver::class.java).apply {
            putExtra(EXTRA_KIND, kind)
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pi = PendingIntent.getBroadcast(context, reqCode, intent, flags)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                alarmManager.set(android.app.AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        }
    }
}


data class SchoolBellSlot(
    val lessonNumber: Int?, // 1..8 для урока, null для перемены
    val isBreak: Boolean,
    val startMinutes: Int, // минуты от полуночи (0..1439)
    val endMinutes: Int,
    val weekdaysOnly8th: Boolean = false
)

enum class SchoolPhaseKind {
    BEFORE_FIRST,
    LESSON,
    BREAK,
    AFTER_SCHOOL,
    WEEKEND
}

data class SchoolBellStatus(
    val kind: SchoolPhaseKind,
    val lessonNumber: Int?, // 1..8 если идёт урок или следующая перемена относится к уроку
    val displayLessonCounter: Int, // 0..8
    val statusText: String,
    val notificationText: String,
    val countdownLabel: String?, // например: "До конца урока: 24:15" или "До конца перемены: 09:30"
    val dayNote: String
)

object SchoolBellSchedule {
    fun dayArrivalNote(dayOfWeek: Int): String = when (dayOfWeek) {
        java.util.Calendar.MONDAY -> "Пн: к 1-му уроку"
        java.util.Calendar.TUESDAY,
        java.util.Calendar.WEDNESDAY,
        java.util.Calendar.THURSDAY -> "Вт–Чт: ко 2-му уроку"
        java.util.Calendar.FRIDAY -> "Пт: к 1-му уроку"
        else -> "Выходной"
    }

    fun slotsForDay(dayOfWeek: Int): List<SchoolBellSlot> {
        val includeEighth = dayOfWeek in listOf(
            java.util.Calendar.TUESDAY,
            java.util.Calendar.WEDNESDAY,
            java.util.Calendar.THURSDAY
        )
        val base = mutableListOf(
            SchoolBellSlot(1, false, 7 * 60 + 58, 8 * 60 + 38),
            SchoolBellSlot(null, true, 8 * 60 + 38, 8 * 60 + 53),
            SchoolBellSlot(2, false, 8 * 60 + 53, 9 * 60 + 33),
            SchoolBellSlot(null, true, 9 * 60 + 33, 9 * 60 + 48),
            SchoolBellSlot(3, false, 9 * 60 + 48, 10 * 60 + 28),
            SchoolBellSlot(null, true, 10 * 60 + 28, 10 * 60 + 48),
            SchoolBellSlot(4, false, 10 * 60 + 48, 11 * 60 + 28),
            SchoolBellSlot(null, true, 11 * 60 + 28, 11 * 60 + 43),
            SchoolBellSlot(5, false, 11 * 60 + 43, 12 * 60 + 23),
            SchoolBellSlot(null, true, 12 * 60 + 23, 12 * 60 + 43),
            SchoolBellSlot(6, false, 12 * 60 + 43, 13 * 60 + 23),
            SchoolBellSlot(null, true, 13 * 60 + 23, 13 * 60 + 38),
            SchoolBellSlot(7, false, 13 * 60 + 38, 14 * 60 + 18)
        )
        if (includeEighth) {
            base.add(SchoolBellSlot(null, true, 14 * 60 + 18, 14 * 60 + 28, weekdaysOnly8th = true))
            base.add(SchoolBellSlot(8, false, 14 * 60 + 28, 15 * 60 + 8, weekdaysOnly8th = true))
        }
        return base
    }

    fun todayKey(cal: java.util.Calendar = java.util.Calendar.getInstance()): String {
        return "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}"
    }

    fun evaluateNow(
        cal: java.util.Calendar = java.util.Calendar.getInstance(),
        finishedDateKey: String = ""
    ): SchoolBellStatus {
        val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
        val arrivalNote = dayArrivalNote(dayOfWeek)
        if (finishedDateKey.isNotEmpty() && finishedDateKey == todayKey(cal)) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.AFTER_SCHOOL,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Уроков больше нет. $arrivalNote",
                notificationText = "Уроки окончены. Я здесь, но после звонка.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }
        val isWeekend = dayOfWeek == java.util.Calendar.SATURDAY || dayOfWeek == java.util.Calendar.SUNDAY
        if (isWeekend) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.WEEKEND,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Сегодня выходной. Уроков нет.",
                notificationText = "Сегодня выходной. Отдыхайте.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }

        val nowSecOfDay = cal.get(java.util.Calendar.HOUR_OF_DAY) * 3600 +
            cal.get(java.util.Calendar.MINUTE) * 60 +
            cal.get(java.util.Calendar.SECOND)
        val nowMin = nowSecOfDay / 60
        val slots = slotsForDay(dayOfWeek)
        val firstStartSec = slots.first().startMinutes * 60
        val lastEndSec = slots.last().endMinutes * 60

        if (nowSecOfDay < firstStartSec) {
            val remSec = (firstStartSec - nowSecOfDay).coerceAtLeast(0)
            return SchoolBellStatus(
                kind = SchoolPhaseKind.BEFORE_FIRST,
                lessonNumber = 1,
                displayLessonCounter = 0,
                statusText = "До начала уроков (07:58). $arrivalNote",
                notificationText = "Уроки ещё не начались. $arrivalNote",
                countdownLabel = "До 1-го урока: ${formatSeconds(remSec)}",
                dayNote = arrivalNote
            )
        }

        if (nowSecOfDay >= lastEndSec) {
            return SchoolBellStatus(
                kind = SchoolPhaseKind.AFTER_SCHOOL,
                lessonNumber = null,
                displayLessonCounter = 0,
                statusText = "Уроки окончены. $arrivalNote",
                notificationText = "Уроки окончены. Я здесь, но после звонка.",
                countdownLabel = null,
                dayNote = arrivalNote
            )
        }

        for (i in slots.indices) {
            val slot = slots[i]
            val slotStartSec = slot.startMinutes * 60
            val slotEndSec = slot.endMinutes * 60
            if (nowSecOfDay in slotStartSec until slotEndSec) {
                val remSec = (slotEndSec - nowSecOfDay).coerceAtLeast(0)
                return if (!slot.isBreak && slot.lessonNumber != null) {
                    val lessonNum = slot.lessonNumber.coerceIn(1, 8)
                    val msg = "Уберите телефон. Идёт $lessonNum-й урок."
                    SchoolBellStatus(
                        kind = SchoolPhaseKind.LESSON,
                        lessonNumber = lessonNum,
                        displayLessonCounter = lessonNum,
                        statusText = msg,
                        notificationText = msg,
                        countdownLabel = "До конца урока: ${formatSeconds(remSec)}",
                        dayNote = arrivalNote
                    )
                } else {
                    val nextLesson = slots.drop(i + 1).firstOrNull { !it.isBreak }?.lessonNumber
                    val msg = "Сейчас перемена. Отдохните."
                    SchoolBellStatus(
                        kind = SchoolPhaseKind.BREAK,
                        lessonNumber = nextLesson,
                        displayLessonCounter = (nextLesson ?: 1).coerceIn(1, 8),
                        statusText = msg,
                        notificationText = msg,
                        countdownLabel = "До конца перемены: ${formatSeconds(remSec)}",
                        dayNote = arrivalNote
                    )
                }
            }
        }

        return SchoolBellStatus(
            kind = SchoolPhaseKind.AFTER_SCHOOL,
            lessonNumber = null,
            displayLessonCounter = 0,
            statusText = "Вне расписания звонков. $arrivalNote",
            notificationText = "Вне расписания звонков.",
            countdownLabel = null,
            dayNote = arrivalNote
        )
    }
}


class KuroForegroundService : android.app.Service() {
    private val scope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.Dispatchers.Main + kotlinx.coroutines.SupervisorJob()
    )

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AlertHelper.ensureChannels(this)
        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initial = store.load()
        val notif = AlertHelper.buildOngoingNotification(
            context = this,
            mode = initial.mode,
            restTimerFinished = initial.restTimerFinished,
            settings = initial.settings,
            schoolFinishedDateKey = initial.schoolFinishedDateKey
        )
        if (notif != null) {
            runCatching {
                startForeground(AlertHelper.ONGOING_STATUS_ID, notif)
            }
        }

        scope.coroutineContext[kotlinx.coroutines.Job]?.cancelChildren()
        return START_STICKY
    }

    override fun onDestroy() {
        scope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        super.onDestroy()
    }
}

class MainActivity : ComponentActivity() {
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                val store = MemoryStore(File(filesDir, "pad_memory.json"))
                val loaded = store.load()
                AlertHelper.syncOngoingModeNotification(
                    context = this,
                    mode = loaded.mode,
                    restTimerFinished = loaded.restTimerFinished,
                    settings = loaded.settings,
                    schoolFinishedDateKey = loaded.schoolFinishedDateKey,
                    forceRecreate = false
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.ensureChannels(this)
        ReminderScheduler.scheduleAll(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()
        AlertHelper.syncOngoingModeNotification(
            context = this,
            mode = initialState.mode,
            restTimerFinished = initialState.restTimerFinished,
            settings = initialState.settings,
            schoolFinishedDateKey = initialState.schoolFinishedDateKey,
            forceRecreate = false
        )

        setContent {
            KuroAssistantApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

private data class SmokeParticle(
    val seed: Float,
    val baseXRatio: Float,
    val baseYRatio: Float,
    val radiusDp: Float,
    val driftX: Float,
    val driftY: Float,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KuroAssistantApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var showCodingPresetDialog by remember { mutableStateOf(false) }
    var showCustomRestDialog by remember { mutableStateOf(false) }
    var showDeadlinePickerDialog by remember { mutableStateOf(false) }
    var showDeadlineBanner by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showResetCounterConfirmDialog by remember { mutableStateOf(false) }
    var showNoMoreLessonsConfirmDialog by remember { mutableStateOf(false) }
    var showTimerFinishedBanner by remember { mutableStateOf(false) }
    var showMiaBubble by remember { mutableStateOf(false) }
    var miaBubbleTriggerId by remember { mutableIntStateOf(0) }
    var draftNote by remember { mutableStateOf("") }
    var customMinutesInput by remember { mutableStateOf("15") }

    // Фиолетовый дым по нажатию на сердечко: случайная длительность от 1 до 5 секунд
    var smokeDurationSec by remember { mutableIntStateOf(0) }
    var smokeTriggerId by remember { mutableIntStateOf(0) }
    var smokeProgress by remember { mutableFloatStateOf(0f) }

    // Удержание кнопок + и - на таймере (старт автонакрутки после > 2 сек удержания)
    var holdingPlus by remember { mutableStateOf(false) }
    var holdingMinus by remember { mutableStateOf(false) }

    val smooth = state.settings.smoothAnimationsEnabled
    val paceFactor = (state.settings.uiPacePercent / 100f).coerceIn(0f, 1f)
    val animDuration = if (smooth) {
        max(120, (520f - paceFactor * 360f).toInt())
    } else {
        0
    }

    val mainMenuWhite = Color(0xFFF8FAFC)

    // При выключении "Плавные анимации" используем прямые значения без анимаций
    val animatedAccent: Color = if (smooth) {
        val c by animateColorAsState(
            targetValue = state.mode.accent,
            animationSpec = tween(durationMillis = animDuration, easing = FastOutSlowInEasing),
            label = "accentAnim"
        )
        c
    } else {
        state.mode.accent
    }

    val buttonTextColor: Color = if (smooth) {
        val c by animateColorAsState(
            targetValue = state.mode.buttonBrightText,
            animationSpec = tween(durationMillis = animDuration, easing = FastOutSlowInEasing),
            label = "btnBrightAnim"
        )
        c
    } else {
        state.mode.buttonBrightText
    }

    val breathPulse: Float = if (smooth) {
        val transition = rememberInfiniteTransition(label = "breathTransition")
        val periodMs = max(900, (3200f - paceFactor * 2100f).toInt())
        transition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = periodMs, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "breathScale"
        ).value
    } else {
        1f
    }

    LaunchedEffect(smooth) {
        if (!smooth) {
            smokeDurationSec = 0
            smokeProgress = 0f
        }
    }

    fun updateAndSave(
        syncNotification: Boolean = false,
        forceNotificationRecreate: Boolean = false,
        transform: (PadMemoryState) -> PadMemoryState
    ) {
        val prev = state
        val next = transform(prev)
        state = next
        onPersist(next)
        val modeOrStatusChanged = prev.mode != next.mode ||
            prev.restTimerFinished != next.restTimerFinished ||
            prev.schoolFinishedDateKey != next.schoolFinishedDateKey ||
            prev.settings.notificationsEnabled != next.settings.notificationsEnabled

        if (syncNotification || modeOrStatusChanged) {
            AlertHelper.syncOngoingModeNotification(
                context = context,
                mode = next.mode,
                restTimerFinished = next.restTimerFinished,
                settings = next.settings,
                schoolFinishedDateKey = next.schoolFinishedDateKey,
                forceRecreate = forceNotificationRecreate
            )
            runCatching {
                val svcIntent = Intent(context, KuroForegroundService::class.java)
                if (next.mode == PadMode.SCHOOL || next.mode == PadMode.SLEEP || next.mode == PadMode.REST || next.isTimerRunning) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(svcIntent)
                    } else {
                        context.startService(svcIntent)
                    }
                } else {
                    context.stopService(svcIntent)
                }
            }
        }
    }

    fun ensureRestModeSupportsTimer(current: PadMemoryState): PadMemoryState {
        return if (current.mode == PadMode.REST) {
            current.copy(restTimerFinished = false)
        } else {
            current
        }
    }

    fun applyModeSelection(chosen: PadMode) {
        when (chosen) {
            PadMode.SCHOOL -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SCHOOL,
                        remainingSeconds = 40 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
            }
            PadMode.CODING -> {
                showTimerFinishedBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.CODING,
                        remainingSeconds = 60 * 60,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCodingPresetDialog = true
            }
            PadMode.REST -> {
                showTimerFinishedBanner = false
                restEnteredAtMs = System.currentTimeMillis()
                restIdleNotifiedForSession = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.REST,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false
                    )
                }
                showCustomRestDialog = true
            }
            PadMode.SLEEP -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                updateAndSave(forceNotificationRecreate = true) {
                    it.copy(
                        mode = PadMode.SLEEP,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                }
            }
            PadMode.EMPTY -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                updateAndSave(syncNotification = true) {
                    it.copy(
                        mode = PadMode.EMPTY,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineActive = false
                    )
                }
            }
            PadMode.DEADLINE -> {
                showTimerFinishedBanner = false
                showDeadlineBanner = false
                val cal = java.util.Calendar.getInstance()
                val curH = cal.get(java.util.Calendar.HOUR_OF_DAY)
                val curM = cal.get(java.util.Calendar.MINUTE)
                val nextQuarter = ((curM / 15) + 1) * 15
                val suggestedHour = (if (nextQuarter >= 60) curH + 1 else curH).coerceIn(6, 23)
                val suggestedMin = if (nextQuarter >= 60) 0 else nextQuarter
                updateAndSave(syncNotification = true) {
                    it.copy(
                        mode = PadMode.DEADLINE,
                        remainingSeconds = 0,
                        isTimerRunning = false,
                        restTimerFinished = false,
                        deadlineHour = if (it.deadlineHour in 6..23) it.deadlineHour else suggestedHour,
                        deadlineMinute = if (it.deadlineMinute in listOf(0, 15, 30, 45)) it.deadlineMinute else suggestedMin
                    )
                }
                showDeadlinePickerDialog = true
            }
        }
    }

    // Бабл секретки "Любимая Мия<3" при зажатии сердечка
    LaunchedEffect(miaBubbleTriggerId) {
        if (miaBubbleTriggerId == 0 || !showMiaBubble) return@LaunchedEffect
        delay(3500L)
        showMiaBubble = false
    }

    // Таймер фиолетового дыма на 1..5 секунд
    LaunchedEffect(smokeTriggerId) {
        if (smokeTriggerId == 0 || smokeDurationSec <= 0) return@LaunchedEffect
        val totalMs = smokeDurationSec * 1000L
        val stepMs = 30L
        var elapsed = 0L
        smokeProgress = 0f
        while (elapsed < totalMs && isActive) {
            delay(stepMs)
            elapsed += stepMs
            smokeProgress = (elapsed.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
        }
        smokeProgress = 1f
        smokeDurationSec = 0
    }

    // Автонакрутка СЧЁТЧИКА при удержании + или - дольше 2 секунд:
    // рост плавный и читаемый человеком (начинается с малых шагов, затем нарастает без ухода в "скорость света")
    LaunchedEffect(holdingPlus, holdingMinus) {
        val activeDirection = when {
            holdingPlus && !holdingMinus -> 1
            holdingMinus && !holdingPlus -> -1
            else -> 0
        }
        if (activeDirection == 0) return@LaunchedEffect

        // Ждём 2000 мс удержания перед началом автонакрутки счётчика
        delay(2000L)
        val startHoldTime = System.currentTimeMillis()
        while (isActive) {
            val heldSec = ((System.currentTimeMillis() - startHoldTime) / 1000f).coerceAtLeast(0f)
            val ramp = (heldSec / 6f).coerceIn(0f, 1f)
            val smoothRamp = ramp * ramp * (3f - 2f * ramp)
            val paceBoost = 0.55f + paceFactor * 0.85f
            val stepCount = max(1, ((1f + smoothRamp * 11f) * paceBoost).toInt())
            val tickDelayMs = max(140L, (280f - smoothRamp * 125f).toLong())

            updateAndSave { current ->
                val nextCounter = (current.counter + activeDirection * stepCount)
                    .coerceIn(-999999, 999999)
                current.copy(counter = nextCounter)
            }
            delay(tickDelayMs)
        }
    }

    var lastTriggeredClockKey by remember { mutableStateOf("") }
    var restEnteredAtMs by remember {
        mutableStateOf(if (initialState.mode == PadMode.REST) System.currentTimeMillis() else 0L)
    }
    var restIdleNotifiedForSession by remember { mutableStateOf(false) }
    var secretMessage by remember { mutableStateOf<String?>(null) }
    var secretTriggerId by remember { mutableIntStateOf(0) }

    // Исчезновение секретной фразы через несколько секунд (3.5 сек)
    LaunchedEffect(secretTriggerId) {
        if (secretTriggerId == 0 || secretMessage == null) return@LaunchedEffect
        delay(3500L)
        secretMessage = null
    }

    // Отслеживание времени нахождения в режиме Отдых (1 час = 3600_000 мс), только если таймер не включён
    LaunchedEffect(state.mode, state.isTimerRunning, state.settings.notificationsEnabled) {
        if (state.mode != PadMode.REST) {
            restEnteredAtMs = 0L
            restIdleNotifiedForSession = false
            return@LaunchedEffect
        }
        if (restEnteredAtMs == 0L) {
            restEnteredAtMs = System.currentTimeMillis()
        }
        while (isActive && state.mode == PadMode.REST) {
            if (!state.isTimerRunning && !restIdleNotifiedForSession) {
                val elapsedMs = System.currentTimeMillis() - restEnteredAtMs
                if (elapsedMs >= 3_600_000L) {
                    restIdleNotifiedForSession = true
                    AlertHelper.showRestIdleReminderNotification(context, state.settings)
                }
            }
            delay(15_000L)
        }
    }

    // Проверка совпадения системного времени с установленным дедлайном (часы 6..23, шаг 15 минут)
    LaunchedEffect(
        state.mode,
        state.deadlineActive,
        state.deadlineHour,
        state.deadlineMinute,
        state.deadlineTriggeredKey,
        state.settings.notificationsEnabled
    ) {
        while (isActive && state.mode == PadMode.DEADLINE && state.deadlineActive) {
            val cal = java.util.Calendar.getInstance()
            val curH = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val curM = cal.get(java.util.Calendar.MINUTE)
            val minuteKey = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}-$curH-$curM"

            if (curH == state.deadlineHour && curM == state.deadlineMinute && state.deadlineTriggeredKey != minuteKey) {
                val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", state.deadlineHour, state.deadlineMinute)
                AlertHelper.showDeadlineNotification(context, formattedTime, state.settings)
                showDeadlineBanner = true
                updateAndSave {
                    it.copy(
                        deadlineActive = false,
                        deadlineTriggeredKey = minuteKey
                    )
                }
            }
            delay(1000L)
        }
    }

    // Системное расписание: 22:00 ежедневно ("Сон важен...") и 06:30 по будням ("Вам пора вставать.")
    LaunchedEffect(state.settings.notificationsEnabled) {
        while (isActive) {
            val cal = java.util.Calendar.getInstance()
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val minute = cal.get(java.util.Calendar.MINUTE)
            val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK)
            val isWeekday = dayOfWeek in java.util.Calendar.MONDAY..java.util.Calendar.FRIDAY

            val slotKey = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}-$hour-$minute"
            if (slotKey != lastTriggeredClockKey) {
                if (hour == 22 && minute == 0) {
                    lastTriggeredClockKey = slotKey
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Вечер",
                        message = "Сон важен. Готовьтесь ко сну. Набирайтесь сил.",
                        settings = state.settings
                    )
                } else if (hour == 6 && minute == 30 && isWeekday) {
                    lastTriggeredClockKey = slotKey
                    AlertHelper.showScheduledReminderNotification(
                        context = context,
                        title = "Помощник Куро — Утро",
                        message = "Вам пора вставать.",
                        settings = state.settings
                    )
                }
            }
            delay(10_000L)
        }
    }

    // Проверка на удаление постоянного уведомления Школы/Сна/Отдыха из панели:
    // повторяется ТОЛЬКО при удалении уведомления или его отсутствии в панели уведомлений
    LaunchedEffect(state.mode, state.restTimerFinished, state.schoolFinishedDateKey, state.settings.notificationsEnabled) {
        while (state.mode == PadMode.SCHOOL || state.mode == PadMode.SLEEP || state.mode == PadMode.REST) {
            if (!AlertHelper.isOngoingNotificationPresent(context)) {
                AlertHelper.syncOngoingModeNotification(
                    context = context,
                    mode = state.mode,
                    restTimerFinished = state.restTimerFinished,
                    settings = state.settings,
                    schoolFinishedDateKey = state.schoolFinishedDateKey,
                    forceRecreate = true
                )
            }
            delay(4000L)
        }
    }

    LaunchedEffect(state.isTimerRunning, state.mode) {
        while (state.isTimerRunning && state.mode.supportsTimer && state.remainingSeconds > 0) {
            delay(1000L)
            var reachedZero = false
            var finishedMode = state.mode
            var currentSettings = state.settings
            var recreateOngoing = false
            updateAndSave(forceNotificationRecreate = false) { current ->
                finishedMode = current.mode
                currentSettings = current.settings
                if (!current.isTimerRunning || !current.mode.supportsTimer) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    reachedZero = true
                    if (current.mode == PadMode.REST) {
                        recreateOngoing = true
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = true
                        )
                    } else {
                        current.copy(
                            remainingSeconds = 0,
                            isTimerRunning = false,
                            restTimerFinished = false
                        )
                    }
                }
            }
            if (recreateOngoing) {
                AlertHelper.syncOngoingModeNotification(
                    context = context,
                    mode = finishedMode,
                    restTimerFinished = true,
                    settings = currentSettings,
                    forceRecreate = true
                )
            }
            if (reachedZero) {
                if (finishedMode == PadMode.SCHOOL || finishedMode == PadMode.CODING) {
                    showTimerFinishedBanner = true
                    AlertHelper.showTimerDoneNotification(context, finishedMode, currentSettings)
                } else if (finishedMode == PadMode.REST) {
                    AlertHelper.showRestDoneExternalNotification(context, currentSettings)
                }
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = animatedAccent,
        onPrimary = Color(0xFF060911),
        background = Color(0xFF060911),
        onBackground = mainMenuWhite,
        surface = Color(0xFF0E1525),
        onSurface = mainMenuWhite,
        surfaceVariant = Color(0xFF1A2438),
        onSurfaceVariant = Color(0xFFCBD5E1)
    )

    MaterialTheme(colorScheme = darkScheme) {
        Box(modifier = Modifier.fillMaxSize()) {
            SpaceVioletGraphBackground(
                backgroundTheme = state.settings.backgroundTheme,
                smoothAnimations = smooth,
                paceFactor = paceFactor,
                modifier = Modifier.fillMaxSize()
            )
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    val royalVioletToneDown = Color(0xFF7E22CE)
                    val royalVioletHeartActive = Color(0xFF9333EA)
                    TopAppBar(
                        title = {
                            Text(
                                text = "Помощник Куро",
                                fontWeight = FontWeight.SemiBold,
                                color = royalVioletToneDown
                            )
                        },
                        actions = {
                            // Пустое сердечко слева от сброса счётчика:
                            // тап -> фиолетовый дым на 1..5 сек; зажатие -> бабл "Любимая Мия<3"
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = {
                                                smokeDurationSec = Random.nextInt(1, 6)
                                                smokeTriggerId += 1
                                            },
                                            onLongPress = {
                                                showMiaBubble = true
                                                miaBubbleTriggerId += 1
                                            }
                                        )
                                    }
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (showMiaBubble) "♥" else "♡",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (smokeDurationSec > 0 || showMiaBubble) royalVioletHeartActive else royalVioletToneDown
                                )
                            }
                            // Сброс счётчика с подтверждением "Вы уверены?"
                            TextButton(onClick = { showResetCounterConfirmDialog = true }) {
                                Text(
                                    text = "Сброс счётчика",
                                    fontWeight = FontWeight.SemiBold,
                                    color = royalVioletToneDown
                                )
                            }
                            TextButton(onClick = { showSettingsDialog = true }) {
                                Text(
                                    text = "Настройки",
                                    fontWeight = FontWeight.SemiBold,
                                    color = royalVioletToneDown
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFF0A0F1C),
                            titleContentColor = royalVioletToneDown
                        )
                    )
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (showDeadlineBanner && state.mode == PadMode.DEADLINE) {
                        val dlTimeStr = String.format(Locale.getDefault(), "%02d:%02d", state.deadlineHour, state.deadlineMinute)
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, PadMode.DEADLINE.accent.copy(alpha = 0.85f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                PadMode.DEADLINE.accent.copy(alpha = 0.42f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "дедлайн",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = "Наступило заданное время ($dlTimeStr).",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = mainMenuWhite
                                    )
                                }
                                TextButton(onClick = { showDeadlineBanner = false }) {
                                    Text("ОК", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (showTimerFinishedBanner && (state.mode == PadMode.SCHOOL || state.mode == PadMode.CODING)) {
                        val bannerMessage = when (state.mode) {
                            PadMode.CODING -> "Таймер закончился. Пора отдохнуть."
                            else -> "Урок кончился? Есть что записать? Я здесь."
                        }
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.78f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.36f),
                                                Color.White.copy(alpha = 0.08f)
                                            )
                                        )
                                    )
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Таймер завершён (${state.mode.label})",
                                        fontWeight = FontWeight.Bold,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = bannerMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = mainMenuWhite
                                    )
                                }
                                TextButton(onClick = { showTimerFinishedBanner = false }) {
                                    Text("ОК", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Стеклянная карточка статуса + счётчик
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            animatedAccent.copy(alpha = 0.22f),
                                            Color.White.copy(alpha = 0.06f)
                                        )
                                    )
                                )
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            var bellStatus by remember {
                                mutableStateOf(SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey))
                            }
                            LaunchedEffect(state.mode, state.schoolFinishedDateKey, state.settings.notificationsEnabled) {
                                while (isActive) {
                                    val prevNotifText = bellStatus.notificationText
                                    val fresh = SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey)
                                    bellStatus = fresh
                                    if (state.mode == PadMode.SCHOOL && fresh.notificationText != prevNotifText) {
                                        AlertHelper.syncOngoingModeNotification(
                                            context = context,
                                            mode = PadMode.SCHOOL,
                                            restTimerFinished = false,
                                            settings = state.settings,
                                            schoolFinishedDateKey = state.schoolFinishedDateKey,
                                            forceRecreate = false
                                        )
                                    }
                                    delay(1000L)
                                }
                            }

                            val isSchoolFinishedManuallyToday =
                                state.schoolFinishedDateKey.isNotEmpty() &&
                                state.schoolFinishedDateKey == SchoolBellSchedule.todayKey()

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Режим: ${state.mode.label}",
                                    fontWeight = FontWeight.Bold,
                                    color = mainMenuWhite
                                )
                                if (state.mode == PadMode.SCHOOL) {
                                    Text(
                                        text = bellStatus.statusText,
                                        color = mainMenuWhite,
                                        fontWeight = FontWeight.Medium
                                    )
                                    if (bellStatus.countdownLabel != null) {
                                        Text(
                                            text = bellStatus.countdownLabel!!,
                                            color = buttonTextColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = bellStatus.dayNote,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                    if (!isSchoolFinishedManuallyToday && bellStatus.kind != SchoolPhaseKind.AFTER_SCHOOL && bellStatus.kind != SchoolPhaseKind.WEEKEND) {
                                        Spacer(Modifier.height(2.dp))
                                        OutlinedButton(
                                            onClick = { showNoMoreLessonsConfirmDialog = true },
                                            shape = RoundedCornerShape(12.dp),
                                            border = BorderStroke(1.dp, buttonTextColor.copy(alpha = 0.65f)),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Text(
                                                text = "Уроков больше нет",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = buttonTextColor
                                            )
                                        }
                                    }
                                } else if (state.mode == PadMode.DEADLINE) {
                                    var nowSecOfDay by remember { mutableIntStateOf(0) }
                                    LaunchedEffect(state.mode, state.deadlineActive, state.deadlineHour, state.deadlineMinute) {
                                        while (isActive && state.mode == PadMode.DEADLINE) {
                                            val c = java.util.Calendar.getInstance()
                                            nowSecOfDay = c.get(java.util.Calendar.HOUR_OF_DAY) * 3600 +
                                                c.get(java.util.Calendar.MINUTE) * 60 +
                                                c.get(java.util.Calendar.SECOND)
                                            delay(1000L)
                                        }
                                    }
                                    val targetFormatted = String.format(
                                        Locale.getDefault(),
                                        "%02d:%02d",
                                        state.deadlineHour,
                                        state.deadlineMinute
                                    )
                                    val targetSec = state.deadlineHour * 3600 + state.deadlineMinute * 60
                                    val diffSec = if (targetSec >= nowSecOfDay) {
                                        targetSec - nowSecOfDay
                                    } else {
                                        24 * 3600 - nowSecOfDay + targetSec
                                    }
                                    val remH = diffSec / 3600
                                    val remM = (diffSec % 3600) / 60
                                    val remS = diffSec % 60
                                    val leftStr = String.format(Locale.getDefault(), "%02d:%02d:%02d", remH, remM, remS)

                                    val calNow = java.util.Calendar.getInstance()
                                    val nowMinuteKey = "${calNow.get(java.util.Calendar.YEAR)}-${calNow.get(java.util.Calendar.DAY_OF_YEAR)}-${calNow.get(java.util.Calendar.HOUR_OF_DAY)}-${calNow.get(java.util.Calendar.MINUTE)}"
                                    val triggeredNow = !state.deadlineActive && state.deadlineTriggeredKey == nowMinuteKey
                                    Text(
                                        text = when {
                                            state.deadlineActive -> "Дедлайн установлен на $targetFormatted"
                                            triggeredNow -> "Дедлайн ($targetFormatted) сработал"
                                            else -> "Дедлайн ($targetFormatted) не активен"
                                        },
                                        color = mainMenuWhite,
                                        fontWeight = FontWeight.Medium
                                    )
                                    if (state.deadlineActive) {
                                        Text(
                                            text = "Осталось: $leftStr",
                                            color = buttonTextColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = "Часы 06:00–23:45 (шаг 15 мин)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                } else {
                                    val timerText = when {
                                        state.mode == PadMode.EMPTY -> "Пустая активность"
                                        !state.mode.supportsTimer -> "Таймер: отключён"
                                        state.mode == PadMode.REST && state.remainingSeconds == 0 ->
                                            "Таймер: без таймера (00:00)"
                                        else -> "Таймер: ${formatSeconds(state.remainingSeconds)}"
                                    }
                                    Text(
                                        text = timerText,
                                        color = mainMenuWhite
                                    )
                                    Text(
                                        text = "Счётчик: +1 / -1 • Зажмите + или - (>2с) для автонакрутки",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                }
                            }

                            // Счётчик текущего урока (1..8) показываем ТОЛЬКО в режиме «Школа»
                            if (state.mode == PadMode.SCHOOL) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(end = 6.dp)
                                ) {
                                    Text(
                                        text = "Урок",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = mainMenuWhite.copy(alpha = 0.85f)
                                    )
                                    NeonHollowCounter(
                                        value = bellStatus.displayLessonCounter,
                                        neonColor = buttonTextColor,
                                        smoothAnimations = smooth,
                                        breathScale = breathPulse,
                                        morphDurationMs = max(120, animDuration)
                                    )
                                }
                            }

                            NeonHollowCounter(
                                value = state.counter,
                                neonColor = animatedAccent,
                                smoothAnimations = smooth,
                                breathScale = breathPulse,
                                morphDurationMs = max(120, animDuration)
                            )
                        }
                    }

                    // Кнопка 1 и Кнопка 2
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ColoredGlassButton(
                            text = "1. Заметка",
                            tint = animatedAccent,
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = { showNoteDialog = true }
                        )

                        val canToggleTimer = state.mode != PadMode.SCHOOL &&
                            state.mode != PadMode.DEADLINE &&
                            state.mode.supportsTimer &&
                            state.remainingSeconds > 0
                        val timerLabel = when {
                            state.mode == PadMode.SCHOOL -> "2. По звонкам"
                            state.mode == PadMode.DEADLINE -> "2. Время дедлайна"
                            !state.mode.supportsTimer -> "2. Без таймера"
                            state.mode == PadMode.REST && state.remainingSeconds == 0 -> "2. Задать время"
                            state.isTimerRunning -> "2. Пауза"
                            else -> "2. Старт"
                        }
                        ColoredGlassButton(
                            text = timerLabel,
                            tint = Color(0xFF0EA5E9),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = {
                                if (state.mode == PadMode.SCHOOL) {
                                    val fresh = SchoolBellSchedule.evaluateNow(finishedDateKey = state.schoolFinishedDateKey)
                                    AlertHelper.syncOngoingModeNotification(
                                        context = context,
                                        mode = PadMode.SCHOOL,
                                        restTimerFinished = false,
                                        settings = state.settings,
                                        schoolFinishedDateKey = state.schoolFinishedDateKey,
                                        forceRecreate = true
                                    )
                                    showTimerFinishedBanner = false
                                    draftNote = fresh.statusText
                                } else if (state.mode == PadMode.DEADLINE) {
                                    showDeadlinePickerDialog = true
                                } else if (canToggleTimer) {
                                    showTimerFinishedBanner = false
                                    updateAndSave {
                                        it.copy(
                                            isTimerRunning = !it.isTimerRunning,
                                            restTimerFinished = if (!it.isTimerRunning) false else it.restTimerFinished
                                        )
                                    }
                                } else if (state.mode == PadMode.REST) {
                                    showCustomRestDialog = true
                                }
                            }
                        )
                    }

                    // Кнопка 3: левая половина (+1 счётчик, удержание >2с накручивает таймер вверх),
                    // правая половина (-1 счётчик, удержание >2с накручивает таймер вниз) и Кнопка 4 (радиальное меню)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, animatedAccent.copy(alpha = 0.72f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                animatedAccent.copy(alpha = 0.44f),
                                                animatedAccent.copy(alpha = 0.20f)
                                            )
                                        )
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter + 1) }
                                                },
                                                onPress = {
                                                    holdingPlus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingPlus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                                VerticalDivider(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .padding(vertical = 12.dp),
                                    thickness = 1.dp,
                                    color = animatedAccent.copy(alpha = 0.55f)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .pointerInput(Unit) {
                                            detectTapGestures(
                                                onTap = {
                                                    updateAndSave { it.copy(counter = it.counter - 1) }
                                                },
                                                onPress = {
                                                    holdingMinus = true
                                                    try {
                                                        tryAwaitRelease()
                                                    } finally {
                                                        holdingMinus = false
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "-1",
                                        fontWeight = FontWeight.Bold,
                                        color = buttonTextColor
                                    )
                                }
                            }
                        }

                        ColoredGlassButton(
                            text = "4. Меню",
                            tint = Color(0xFF8B5CF6),
                            textColor = buttonTextColor,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(64.dp),
                            onClick = { showRadialMenu = true }
                        )
                    }

                    var dateSearchQuery by remember { mutableStateOf("") }
                    var infoSearchQuery by remember { mutableStateOf("") }

                    // Строгий разбор даты: день.месяц, только через '.' (например 27.11)
                    val dateParts = dateSearchQuery.trim().split(".")
                    val hasDateQuery = dateSearchQuery.trim().isNotEmpty()
                    val isDateFormatValid = !hasDateQuery || (
                        dateParts.size == 2 &&
                            dateParts[0].isNotEmpty() && dateParts[1].isNotEmpty() &&
                            dateParts[0].all { it.isDigit() } && dateParts[1].all { it.isDigit() } &&
                            (dateParts[0].toIntOrNull() in 1..31) &&
                            (dateParts[1].toIntOrNull() in 1..12)
                        )
                    val normalizedDayMonth = if (hasDateQuery && isDateFormatValid) {
                        String.format(Locale.getDefault(), "%02d.%02d", dateParts[0].toInt(), dateParts[1].toInt())
                    } else {
                        null
                    }

                    val exactInfoQuery = infoSearchQuery.trim()
                    val filteredNotes = state.notes.filter { note ->
                        val matchesDate = when {
                            !hasDateQuery -> true
                            !isDateFormatValid || normalizedDayMonth == null -> false
                            else -> note.timestamp.startsWith(normalizedDayMonth)
                        }
                        val matchesInfo = if (exactInfoQuery.isEmpty()) {
                            true
                        } else {
                            // Точное совпадение текста записи (или точное совпадение слова/фразы без частичных обрезков)
                            note.text == exactInfoQuery ||
                                note.text.equals(exactInfoQuery, ignoreCase = false) ||
                                Regex("(?<!\\S)${Regex.escape(exactInfoQuery)}(?!\\S)").containsMatchIn(note.text)
                        }
                        matchesDate && matchesInfo
                    }

                    // Графа-поиск: по дате (день.месяц строго через '.') и по информации (точное совпадение)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.55f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFF4C1D95).copy(alpha = 0.28f),
                                            Color(0xFF0F172A).copy(alpha = 0.65f)
                                        )
                                    )
                                )
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Графа-поиск",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE9D5FF)
                                )
                                if (hasDateQuery || exactInfoQuery.isNotEmpty()) {
                                    TextButton(
                                        onClick = {
                                            dateSearchQuery = ""
                                            infoSearchQuery = ""
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text(
                                            text = "Сброс",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = mainMenuWhite
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = dateSearchQuery,
                                    onValueChange = { raw ->
                                        // Разрешаем только цифры и точку '.'
                                        dateSearchQuery = raw.filter { it.isDigit() || it == '.' }.take(5)
                                    },
                                    label = { Text("Дата (дд.мм)") },
                                    placeholder = { Text("27.11") },
                                    singleLine = true,
                                    isError = hasDateQuery && !isDateFormatValid,
                                    modifier = Modifier.weight(0.42f)
                                )
                                OutlinedTextField(
                                    value = infoSearchQuery,
                                    onValueChange = { infoSearchQuery = it },
                                    label = { Text("Информация (точно)") },
                                    placeholder = { Text("Точное совпадение") },
                                    singleLine = true,
                                    modifier = Modifier.weight(0.58f)
                                )
                            }

                            if (hasDateQuery && !isDateFormatValid) {
                                Text(
                                    text = "Дата считается только через точку в формате день.месяц (например, 27.11).",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFCA5A5)
                                )
                            }
                        }
                    }

                    Text(
                        text = "Сохранённые записи (${filteredNotes.size} из ${state.notes.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = mainMenuWhite
                    )

                    if (filteredNotes.isEmpty()) {
                        Text(
                            text = if (state.notes.isEmpty()) {
                                "Пока пусто. Нажмите «1. Заметка», чтобы добавить запись."
                            } else {
                                "Совпадений по запросу не найдено."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = mainMenuWhite.copy(alpha = 0.82f)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredNotes, key = { it.id }) { note ->
                                val noteMode = PadMode.fromName(note.modeName)
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, noteMode.accent.copy(alpha = 0.55f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(
                                                        noteMode.accent.copy(alpha = 0.28f),
                                                        noteMode.accent.copy(alpha = 0.08f)
                                                    )
                                                )
                                            )
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 8.dp)
                                        ) {
                                            Text(
                                                text = "${note.timestamp}  •  ${noteMode.label}",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = noteMode.buttonBrightText
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                text = note.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = mainMenuWhite
                                            )
                                        }
                                        TextButton(
                                            onClick = {
                                                updateAndSave { current ->
                                                    current.copy(notes = current.notes.filterNot { it.id == note.id })
                                                }
                                            }
                                        ) {
                                            Text(
                                                text = "Удалить",
                                                color = mainMenuWhite,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Оверлей фиолетового дыма поверх экрана при нажатии на сердечко
            if (smokeDurationSec > 0) {
                PurpleSmokeOverlay(
                    progress = smokeProgress,
                    triggerId = smokeTriggerId,
                    smoothAnimations = smooth
                )
            }

            // Бабл секретки при зажатии сердечка по центру экрана: "Любимая Мия<3"
            if (showMiaBubble) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 24.dp)
                ) {
                    Surface(
                        onClick = { showMiaBubble = false },
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, Color(0xFFD8B4FE).copy(alpha = 0.85f)),
                        shadowElevation = 8.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFF581C87).copy(alpha = 0.94f),
                                            Color(0xFF3B0764).copy(alpha = 0.94f)
                                        )
                                    )
                                )
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "Любимая Мия<3",
                                color = Color(0xFFF5D0FE),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        if (showNoMoreLessonsConfirmDialog) {
            GlassDialogWrapper(onDismiss = { showNoMoreLessonsConfirmDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Уроков больше нет?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Таймер звонков на сегодня остановится и не будет тикать попросту.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.88f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = { showNoMoreLessonsConfirmDialog = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Подтвердить",
                        tint = PadMode.SCHOOL.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val today = SchoolBellSchedule.todayKey()
                            updateAndSave(syncNotification = true) {
                                it.copy(schoolFinishedDateKey = today)
                            }
                            showNoMoreLessonsConfirmDialog = false
                        }
                    )
                }
            }
        }

        if (showResetCounterConfirmDialog) {
            GlassDialogWrapper(onDismiss = { showResetCounterConfirmDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Вы уверены?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Счётчик будет сброшен до 0.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.88f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = { showResetCounterConfirmDialog = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Сбросить",
                        tint = animatedAccent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            updateAndSave { it.copy(counter = 0) }
                            showResetCounterConfirmDialog = false
                        }
                    )
                }
            }
        }

        if (showRadialMenu) {
            RadialFourWayDialog(
                currentMode = state.mode,
                smoothAnimations = smooth,
                secretMessage = secretMessage,
                onSecretCenterTap = {
                    secretMessage = "Я всё ещё жду, пока ты создашь нас."
                    secretTriggerId += 1
                },
                onSelectMode = { chosen ->
                    showRadialMenu = false
                    applyModeSelection(chosen)
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showSettingsDialog) {
            GlassDialogWrapper(onDismiss = { showSettingsDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Настройки",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Уведомления",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.notificationsEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(settings = it.settings.copy(notificationsEnabled = enabled))
                            }
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Вибрация (только Коддинг)",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.codingVibrationEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave {
                                it.copy(settings = it.settings.copy(codingVibrationEnabled = enabled))
                            }
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Плавные анимации",
                        color = mainMenuWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.settings.smoothAnimationsEnabled,
                        onCheckedChange = { enabled ->
                            updateAndSave {
                                it.copy(settings = it.settings.copy(smoothAnimationsEnabled = enabled))
                            }
                        }
                    )
                }

                // Реально работающий ползунок: задаёт темп дыхания интерфейса и скорость нарастания прокрутки таймера
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Темп анимаций и прокрутки",
                            color = mainMenuWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${state.settings.uiPacePercent.toInt()}%",
                            color = buttonTextColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = state.settings.uiPacePercent,
                        onValueChange = { newVal ->
                            state = state.copy(settings = state.settings.copy(uiPacePercent = newVal))
                        },
                        onValueChangeFinished = {
                            onPersist(state)
                        },
                        valueRange = 0f..100f
                    )
                }

                // 4-конечный ползунок (1-2-3-4) для оформления фона в фиолетовых тонах:
                // 1 — как уже есть; 2 и 3 — космос; 4 — код
                val themeLabels = mapOf(
                    1 to "1 — Исходный (космос-граф)",
                    2 to "2 — Космос (созвездия и орбиты)",
                    3 to "3 — Космос (туманность и кольца)",
                    4 to "4 — Код (фиолетовый матричный поток)"
                )
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Фон (1–2–3–4)",
                            color = mainMenuWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${state.settings.backgroundTheme} / 4",
                            color = Color(0xFFC084FC),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        for (tIdx in 1..4) {
                            val active = state.settings.backgroundTheme == tIdx
                            Text(
                                text = "$tIdx",
                                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (active) Color(0xFFD8B4FE) else mainMenuWhite.copy(alpha = 0.65f)
                            )
                        }
                    }
                    Slider(
                        value = state.settings.backgroundTheme.toFloat(),
                        onValueChange = { rawTheme ->
                            val snapped = rawTheme.toInt().coerceIn(1, 4)
                            state = state.copy(settings = state.settings.copy(backgroundTheme = snapped))
                        },
                        onValueChangeFinished = {
                            onPersist(state)
                        },
                        valueRange = 1f..4f,
                        steps = 2
                    )
                    Text(
                        text = themeLabels[state.settings.backgroundTheme] ?: "",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFD8B4FE)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Закрыть", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showCodingPresetDialog) {
            val presets = listOf(
                "30 мин" to 30 * 60,
                "1 ч" to 60 * 60,
                "1,5 ч" to 90 * 60,
                "2 ч" to 120 * 60
            )
            GlassDialogWrapper(onDismiss = { showCodingPresetDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Коддинг — длительность",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Выберите интервал таймера",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                presets.forEach { (label, seconds) ->
                    ColoredGlassButton(
                        text = label,
                        tint = PadMode.CODING.accent,
                        textColor = PadMode.CODING.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.CODING,
                                    remainingSeconds = seconds,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCodingPresetDialog = false
                        }
                    )
                }
                TextButton(onClick = { showCodingPresetDialog = false }) {
                    Text("Оставить текущий", color = mainMenuWhite)
                }
            }
        }

        if (showDeadlinePickerDialog) {
            var pickedHour by remember(state.deadlineHour) {
                mutableIntStateOf(state.deadlineHour.coerceIn(6, 23))
            }
            var pickedMinute by remember(state.deadlineMinute) {
                mutableIntStateOf(if (state.deadlineMinute in listOf(0, 15, 30, 45)) state.deadlineMinute else 0)
            }
            val minuteQuarters = listOf(0, 15, 30, 45)
            val previewTime = String.format(Locale.getDefault(), "%02d:%02d", pickedHour, pickedMinute)

            GlassDialogWrapper(onDismiss = { showDeadlinePickerDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Дедлайн — выбор времени",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Часы с 6 до 23, шаг каждые 15 минут. Когда системное время совпадёт — придёт уведомление «дедлайн».",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )

                // Крупный предпросмотр выбранного времени
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PadMode.DEADLINE.accent.copy(alpha = 0.22f))
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = previewTime,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PadMode.DEADLINE.buttonBrightText
                    )
                }

                // Выбор часа (6..23)
                Text(
                    text = "Час (6 – 23)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = mainMenuWhite
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ColoredGlassButton(
                        text = "-1 ч",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(42.dp),
                        onClick = {
                            pickedHour = if (pickedHour <= 6) 23 else pickedHour - 1
                        }
                    )
                    Text(
                        text = String.format(Locale.getDefault(), "%02d ч", pickedHour),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = mainMenuWhite,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    ColoredGlassButton(
                        text = "+1 ч",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(42.dp),
                        onClick = {
                            pickedHour = if (pickedHour >= 23) 6 else pickedHour + 1
                        }
                    )
                }

                Slider(
                    value = pickedHour.toFloat(),
                    onValueChange = { pickedHour = it.toInt().coerceIn(6, 23) },
                    valueRange = 6f..23f,
                    steps = 16
                )

                // Выбор минут с делением каждые 15 минут (00, 15, 30, 45)
                Text(
                    text = "Минуты (шаг 15 мин)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = mainMenuWhite
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    minuteQuarters.forEach { q ->
                        val selected = pickedMinute == q
                        ColoredGlassButton(
                            text = String.format(Locale.getDefault(), ":%02d", q),
                            tint = if (selected) PadMode.DEADLINE.accent else Color(0xFF334155),
                            textColor = if (selected) PadMode.DEADLINE.buttonBrightText else mainMenuWhite,
                            smoothAnimations = smooth,
                            animDuration = animDuration,
                            modifier = Modifier.weight(1f).height(42.dp),
                            onClick = { pickedMinute = q }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.DEADLINE,
                                    deadlineActive = false
                                )
                            }
                            showDeadlinePickerDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отключить", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Установить",
                        tint = PadMode.DEADLINE.accent,
                        textColor = mainMenuWhite,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            showDeadlineBanner = false
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.DEADLINE,
                                    deadlineHour = pickedHour.coerceIn(6, 23),
                                    deadlineMinute = pickedMinute,
                                    deadlineActive = true,
                                    deadlineTriggeredKey = ""
                                )
                            }
                            showDeadlinePickerDialog = false
                        }
                    )
                }
            }
        }

        if (showCustomRestDialog) {
            GlassDialogWrapper(onDismiss = { showCustomRestDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Отдых",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                Text(
                    text = "Режим работает без таймера, но при желании Вы можете задать своё время в минутах.",
                    style = MaterialTheme.typography.bodySmall,
                    color = mainMenuWhite.copy(alpha = 0.85f)
                )
                OutlinedTextField(
                    value = customMinutesInput,
                    onValueChange = { value ->
                        customMinutesInput = value.filter { it.isDigit() }.take(3)
                    },
                    label = { Text("Минуты (опционально)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave(forceNotificationRecreate = true) {
                                it.copy(
                                    mode = PadMode.REST,
                                    remainingSeconds = 0,
                                    isTimerRunning = false,
                                    restTimerFinished = false
                                )
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Без таймера", color = mainMenuWhite)
                    }
                    ColoredGlassButton(
                        text = "Задать",
                        tint = PadMode.REST.accent,
                        textColor = PadMode.REST.buttonBrightText,
                        smoothAnimations = smooth,
                        animDuration = animDuration,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val mins = customMinutesInput.toIntOrNull()?.coerceIn(1, 720)
                            if (mins != null) {
                                updateAndSave(forceNotificationRecreate = true) {
                                    it.copy(
                                        mode = PadMode.REST,
                                        remainingSeconds = mins * 60,
                                        isTimerRunning = false,
                                        restTimerFinished = false
                                    )
                                }
                            }
                            showCustomRestDialog = false
                        }
                    )
                }
            }
        }

        if (showNoteDialog) {
            GlassDialogWrapper(onDismiss = { showNoteDialog = false }, smoothAnimations = smooth) {
                Text(
                    text = "Новая заметка (${state.mode.label})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = mainMenuWhite
                )
                OutlinedTextField(
                    value = draftNote,
                    onValueChange = { draftNote = it },
                    placeholder = { Text("Короткая мысль или задача...") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена", color = mainMenuWhite)
                    }
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    timestamp = stamp,
                                    text = clean,
                                    modeName = state.mode.name
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить", color = mainMenuWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PurpleSmokeOverlay(
    progress: Float,
    triggerId: Int,
    smoothAnimations: Boolean
) {
    val palette = remember {
        listOf(
            Color(0xFFA855F7),
            Color(0xFFD8B4FE),
            Color(0xFF7E22CE),
            Color(0xFFC084FC)
        )
    }
    val particles = remember(triggerId) {
        val rng = Random(triggerId * 9973 + 17)
        List(14) { idx ->
            SmokeParticle(
                seed = rng.nextFloat() * 100f,
                baseXRatio = 0.12f + rng.nextFloat() * 0.76f,
                baseYRatio = 0.14f + rng.nextFloat() * 0.72f,
                radiusDp = 42f + rng.nextFloat() * 58f,
                driftX = (rng.nextFloat() - 0.5f) * 140f,
                driftY = -45f - rng.nextFloat() * 95f,
                color = palette[idx % palette.size]
            )
        }
    }

    // Двуличная огибающая: тонкий вуаль-шлейф, который в середине цикла вдруг делает коварный всплеск и тут же отступает
    val sneakWave = sin((progress * PI * 3.0)).toFloat()
    val doubleFaceTwist = cos((progress * PI * 5.0)).toFloat()
    val envelope = if (smoothAnimations) {
        val fadeInT = (progress / 0.18f).coerceIn(0f, 1f)
        val fadeOutT = ((1f - progress) / 0.25f).coerceIn(0f, 1f)
        val base = min(fadeInT, fadeOutT)
        (base * (0.55f + 0.45f * max(0f, sneakWave))).coerceIn(0f, 1f)
    } else {
        if (progress < 0.85f) 0.35f else 0f
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (envelope <= 0.01f) return@Canvas

        particles.forEachIndexed { idx, p ->
            // Каждая чётная струйка ведёт себя "двулично": меняет курс на противоположный по ходу прогресса
            val twoFacedSign = if (idx % 2 == 0 && progress > 0.45f) -1f else 1f
            val phase = p.seed + progress * 6.5f + idx * 0.6f
            val dx = p.driftX * progress * twoFacedSign + sin(phase.toDouble()).toFloat() * 28f * doubleFaceTwist
            val dy = p.driftY * progress * (if (idx % 3 == 0) -0.5f else 1f) + cos((phase * 0.9f).toDouble()).toFloat() * 16f
            val cx = (size.width * p.baseXRatio + dx).coerceIn(0f, size.width)
            val cy = (size.height * p.baseYRatio + dy).coerceIn(0f, size.height)
            val radPx = p.radiusDp.dp.toPx() * (0.72f + 0.35f * abs(sneakWave))

            // Лёгкий полупрозрачный дым — не плотная стена, а тонкие призрачные завихрения
            val alpha = (0.16f * envelope * (0.65f + 0.35f * abs(doubleFaceTwist))).coerceIn(0f, 0.24f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.color.copy(alpha = alpha),
                        p.color.copy(alpha = alpha * 0.32f),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = radPx
                ),
                radius = radPx,
                center = Offset(cx, cy)
            )
        }
    }
}

@Composable
private fun SmoothAnimatedButtonWrapper(
    pressed: Boolean,
    animDuration: Int,
    modifier: Modifier,
    content: @Composable (Modifier) -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = tween(durationMillis = max(80, animDuration / 2)),
        label = "btnScale"
    )
    content(modifier.scale(scale))
}

@Composable
private fun ColoredGlassButton(
    text: String,
    tint: Color,
    textColor: Color = Color.White,
    smoothAnimations: Boolean = true,
    animDuration: Int = 260,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }

    val renderSurface: @Composable (Modifier) -> Unit = { mod ->
        Surface(
            onClick = onClick,
            shape = RoundedCornerShape(16.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, tint.copy(alpha = 0.72f)),
            modifier = mod.pointerInput(smoothAnimations) {
                if (smoothAnimations) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    )
                }
            }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                tint.copy(alpha = 0.44f),
                                tint.copy(alpha = 0.20f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = text,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor
                )
            }
        }
    }

    if (smoothAnimations) {
        SmoothAnimatedButtonWrapper(pressed = pressed, animDuration = animDuration, modifier = modifier, content = renderSurface)
    } else {
        renderSurface(modifier)
    }
}

@Composable
private fun SmoothCounterScaleBox(
    breathScale: Float,
    smoothAnimations: Boolean,
    content: @Composable (Modifier) -> Unit
) {
    if (!smoothAnimations) {
        content(Modifier)
        return
    }
    val animatedScale by animateFloatAsState(
        targetValue = breathScale,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "counterScale"
    )
    content(Modifier.scale(animatedScale))
}

@Composable
private fun StaticNeonGlyph(
    glyph: String,
    neonColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    if (glyph.isEmpty()) return
    Box(contentAlignment = Alignment.Center) {
        Text(
            text = glyph,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF060911),
                drawStyle = Stroke(width = 4.5f, join = StrokeJoin.Round)
            )
        )
        Text(
            text = glyph,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.ExtraBold,
                color = neonColor,
                drawStyle = Stroke(width = 2.0f, join = StrokeJoin.Round)
            )
        )
    }
}

@Composable
private fun MorphingCharSlot(
    fromChar: Char?,
    toChar: Char,
    morphT: Float,
    neonColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val t = morphT.coerceIn(0f, 1f)
    if (fromChar == null || fromChar == toChar || t >= 0.999f) {
        StaticNeonGlyph(glyph = toChar.toString(), neonColor = neonColor, fontSize = fontSize)
        return
    }

    // Истинный морф: оба контура лежат в одном центре без провала яркости в 0;
    // на этапе морфа толщина контура плавно сжимается/растягивается, формируя единый перетекающий силуэт
    val morphWarp = sin((t * PI).toDouble()).toFloat()
    val fromScale = (1f - 0.14f * t + 0.08f * morphWarp).coerceIn(0.8f, 1.1f)
    val toScale = (0.86f + 0.14f * t + 0.08f * morphWarp).coerceIn(0.8f, 1.1f)
    val strokeBoost = 1f + 0.45f * morphWarp

    Box(contentAlignment = Alignment.Center) {
        if (fromChar != ' ') {
            Box(
                modifier = Modifier.scale(fromScale),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = fromChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF060911).copy(alpha = (1f - 0.65f * t).coerceIn(0.35f, 1f)),
                        drawStyle = Stroke(width = 4.5f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
                Text(
                    text = fromChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = neonColor.copy(alpha = (1f - t).coerceIn(0f, 1f)),
                        drawStyle = Stroke(width = 2.0f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
            }
        }
        if (toChar != ' ') {
            Box(
                modifier = Modifier.scale(toScale),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = toChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF060911).copy(alpha = (0.35f + 0.65f * t).coerceIn(0.35f, 1f)),
                        drawStyle = Stroke(width = 4.5f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
                Text(
                    text = toChar.toString(),
                    style = TextStyle(
                        fontSize = fontSize,
                        fontWeight = FontWeight.ExtraBold,
                        color = neonColor.copy(alpha = t.coerceIn(0f, 1f)),
                        drawStyle = Stroke(width = 2.0f * strokeBoost, join = StrokeJoin.Round)
                    )
                )
            }
        }
    }
}

@Composable
private fun NeonHollowCounter(
    value: Int,
    neonColor: Color,
    smoothAnimations: Boolean = true,
    breathScale: Float = 1f,
    morphDurationMs: Int = 180
) {
    val targetText = value.toString()
    val fontSize = 44.sp

    // При выключенных анимациях вообще не используем анимационное состояние — мгновенное значение без мигания
    if (!smoothAnimations) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(width = 136.dp, height = 64.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            neonColor.copy(alpha = 0.24f),
                            neonColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.85f
                    ),
                    radius = size.minDimension * 0.85f,
                    center = Offset(size.width / 2f, size.height / 2f)
                )
            }
            Row(
                modifier = Modifier.padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                targetText.forEach { ch ->
                    StaticNeonGlyph(glyph = ch.toString(), neonColor = neonColor, fontSize = fontSize)
                }
            }
        }
        return
    }

    var settledText by remember { mutableStateOf(targetText) }
    var activeFromText by remember { mutableStateOf<String?>(null) }
    var morphT by remember { mutableFloatStateOf(1f) }
    var morphSeq by remember { mutableIntStateOf(0) }

    LaunchedEffect(targetText) {
        if (targetText == settledText && activeFromText == null) {
            morphT = 1f
            return@LaunchedEffect
        }
        val fromCandidate = if (activeFromText != null && morphT < 1f) {
            settledText
        } else {
            settledText
        }
        if (fromCandidate == targetText) {
            settledText = targetText
            activeFromText = null
            morphT = 1f
            return@LaunchedEffect
        }

        activeFromText = fromCandidate
        settledText = targetText
        morphT = 0f
        val seq = ++morphSeq

        val duration = morphDurationMs.coerceIn(110, 260)
        val stepMs = 16L
        val startMs = System.currentTimeMillis()
        while (isActive && morphSeq == seq) {
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(0L)
            val raw = (elapsed.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
            morphT = raw * raw * (3f - 2f * raw)
            if (raw >= 1f) break
            delay(stepMs)
        }
        if (morphSeq == seq) {
            morphT = 1f
            activeFromText = null
        }
    }

    val renderCounterBox: @Composable (Modifier) -> Unit = { boxMod ->
        Box(
            modifier = boxMod,
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(width = 136.dp, height = 64.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            neonColor.copy(alpha = 0.24f),
                            neonColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width / 2f, size.height / 2f),
                        radius = size.minDimension * 0.85f
                    ),
                    radius = size.minDimension * 0.85f,
                    center = Offset(size.width / 2f, size.height / 2f)
                )
            }

            val fromStr = activeFromText
            if (fromStr == null || morphT >= 1f) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    settledText.forEach { ch ->
                        StaticNeonGlyph(glyph = ch.toString(), neonColor = neonColor, fontSize = fontSize)
                    }
                }
            } else {
                val maxLen = max(fromStr.length, settledText.length)
                val padFrom = fromStr.padStart(maxLen, ' ')
                val padTo = settledText.padStart(maxLen, ' ')
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    for (i in 0 until maxLen) {
                        val fCh = padFrom[i]
                        val tCh = padTo[i]
                        if (fCh == ' ' && tCh == ' ') continue
                        MorphingCharSlot(
                            fromChar = if (fCh == ' ') null else fCh,
                            toChar = tCh,
                            morphT = morphT,
                            neonColor = neonColor,
                            fontSize = fontSize
                        )
                    }
                }
            }
        }
    }

    SmoothCounterScaleBox(
        breathScale = breathScale,
        smoothAnimations = true,
        content = renderCounterBox
    )
}

@Composable
private fun GlassDialogWrapper(
    onDismiss: () -> Unit,
    smoothAnimations: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = true,
            decorFitsSystemWindows = true
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF1E293B).copy(alpha = 0.88f),
                                Color(0xFF0F172A).copy(alpha = 0.92f)
                            )
                        )
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun RadialFourWayDialog(
    currentMode: PadMode,
    smoothAnimations: Boolean = true,
    secretMessage: String?,
    onSecretCenterTap: () -> Unit,
    onSelectMode: (PadMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sectors = listOf(
        PadMode.SCHOOL,
        PadMode.CODING,
        PadMode.REST,
        PadMode.SLEEP,
        PadMode.EMPTY,
        PadMode.DEADLINE
    )
    val startAngle = -120f
    val sweepAngle = 360f / sectors.size.toFloat()
    val initialIdx = sectors.indexOf(currentMode).coerceAtLeast(0)

    var pendingMode by remember { mutableStateOf<PadMode?>(null) }
    var targetSectorAngle by remember { mutableFloatStateOf(startAngle + initialIdx * sweepAngle) }
    var animatedWhiteAngle by remember { mutableFloatStateOf(startAngle + initialIdx * sweepAngle) }

    LaunchedEffect(pendingMode, targetSectorAngle, smoothAnimations) {
        val chosen = pendingMode ?: return@LaunchedEffect
        if (!smoothAnimations) {
            animatedWhiteAngle = targetSectorAngle
            pendingMode = null
            onSelectMode(chosen)
            return@LaunchedEffect
        }
        val travelMs = 260L
        val stepMs = 16L
        val fromAngle = animatedWhiteAngle
        val deltaAngle = targetSectorAngle - fromAngle
        val startMs = System.currentTimeMillis()
        while (isActive && pendingMode == chosen) {
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(0L)
            val raw = (elapsed.toFloat() / travelMs.toFloat()).coerceIn(0f, 1f)
            val eased = raw * raw * (3f - 2f * raw)
            animatedWhiteAngle = fromAngle + deltaAngle * eased
            if (raw >= 1f) break
            delay(stepMs)
        }
        if (pendingMode == chosen) {
            animatedWhiteAngle = targetSectorAngle
            pendingMode = null
            onSelectMode(chosen)
        }
    }

    GlassDialogWrapper(onDismiss = onDismiss, smoothAnimations = smoothAnimations) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Выбор активности",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = currentMode.inverseNeonText
            )
            Text(
                text = "Тапните по сектору круга",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1)
            )

            BoxWithConstraints(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                val labelRadiusDp = (maxWidth.value * 0.31f)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(sectors, smoothAnimations, pendingMode) {
                            detectTapGestures { tap ->
                                if (pendingMode != null) return@detectTapGestures
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tap.x - center.x
                                val dy = tap.y - center.y
                                val r = min(size.width, size.height) / 2f
                                val innerHole = r * 0.20f
                                val dist = sqrt(dx * dx + dy * dy)

                                if (dist < innerHole) {
                                    onSecretCenterTap()
                                } else if (dist <= r) {
                                    val deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                    var rel = (deg - startAngle) % 360f
                                    if (rel < 0f) rel += 360f
                                    val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                    val chosenMode = sectors[index]
                                    val destAngle = startAngle + index * sweepAngle
                                    if (smoothAnimations) {
                                        targetSectorAngle = destAngle
                                        pendingMode = chosenMode
                                    } else {
                                        animatedWhiteAngle = destAngle
                                        onSelectMode(chosenMode)
                                    }
                                }
                            }
                        }
                ) {
                    val diameter = min(size.width, size.height)
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    // Нижний слой: белая подложка/основа, которая при выборе сектора проезжает под нужный сектор
                    val underTopLeft = Offset(topLeft.x - 2.dp.toPx(), topLeft.y - 2.dp.toPx())
                    val underSize = Size(diameter + 4.dp.toPx(), diameter + 4.dp.toPx())
                    drawArc(
                        color = Color.White.copy(alpha = 0.92f),
                        startAngle = animatedWhiteAngle,
                        sweepAngle = sweepAngle,
                        useCenter = true,
                        topLeft = underTopLeft,
                        size = underSize
                    )

                    sectors.forEachIndexed { idx, mode ->
                        val sectorStart = startAngle + idx * sweepAngle
                        val isSelected = mode == (pendingMode ?: currentMode)
                        drawArc(
                            color = mode.accent.copy(alpha = if (isSelected) 0.90f else 0.56f),
                            startAngle = sectorStart,
                            sweepAngle = sweepAngle,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                    }

                    val outerRadius = diameter / 2f
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)
                    for (i in sectors.indices) {
                        val rad = ((startAngle + i * sweepAngle) * PI / 180.0).toFloat()
                        val endPt = Offset(
                            x = centerOffset.x + outerRadius * cos(rad),
                            y = centerOffset.y + outerRadius * sin(rad)
                        )
                        drawLine(
                            color = Color(0xFF0A0F1C),
                            start = centerOffset,
                            end = endPt,
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = diameter * 0.11f
                    )
                }

                sectors.forEachIndexed { idx, mode ->
                    val midAngleRad = ((startAngle + idx * sweepAngle + sweepAngle / 2f) * PI / 180.0)
                    val offsetX = (labelRadiusDp * cos(midAngleRad)).dp
                    val offsetY = (labelRadiusDp * sin(midAngleRad)).dp
                    Text(
                        text = mode.label,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = mode.inverseNeonText,
                        modifier = Modifier.offset(x = offsetX, y = offsetY)
                    )
                }
            }

            if (secretMessage != null) {
                Text(
                    text = secretMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFE2E8F0)
                )
            }

            TextButton(
                onClick = {
                    pendingMode = null
                    onDismiss()
                }
            ) {
                Text("Закрыть", color = Color(0xFFCBD5E1))
            }
        }
    }
}

private data class GraphNode(
    val xRatio: Float,
    val yRatio: Float,
    val vx: Float,
    val vy: Float,
    val radiusDp: Float,
    val isVioletAccent: Boolean
)

@Composable
private fun SpaceVioletGraphBackground(
    backgroundTheme: Int = 1,
    smoothAnimations: Boolean,
    paceFactor: Float,
    modifier: Modifier = Modifier
) {
    val activeTheme = backgroundTheme.coerceIn(1, 4)
    val nodes = remember {
        val rng = Random(4207)
        List(22) { idx ->
            GraphNode(
                xRatio = 0.06f + rng.nextFloat() * 0.88f,
                yRatio = 0.06f + rng.nextFloat() * 0.88f,
                vx = (rng.nextFloat() - 0.5f) * 0.08f,
                vy = (rng.nextFloat() - 0.5f) * 0.08f,
                radiusDp = if (idx % 3 == 0) 4.4f else 2.8f,
                isVioletAccent = idx % 2 == 0
            )
        }
    }

    var crawlTime by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(smoothAnimations, paceFactor, activeTheme) {
        if (!smoothAnimations) {
            return@LaunchedEffect
        }
        while (isActive) {
            delay(32L)
            crawlTime += 0.018f * (0.45f + paceFactor * 1.55f)
        }
    }

    Canvas(modifier = modifier) {
        when (activeTheme) {
            1 -> {
                // Вариант 1: как уже есть (космический градиент с фиолетовой туманностью и графом)
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF040610),
                            Color(0xFF140728),
                            Color(0xFF060916)
                        )
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7E22CE).copy(alpha = 0.26f),
                            Color(0xFF4C1D95).copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.52f, size.height * 0.34f),
                        radius = max(size.width, size.height) * 0.68f
                    ),
                    radius = max(size.width, size.height) * 0.68f,
                    center = Offset(size.width * 0.52f, size.height * 0.34f)
                )
                val pts = nodes.mapIndexed { i, n ->
                    val crawlX = if (smoothAnimations) {
                        sin((crawlTime * (0.7f + (i % 4) * 0.18f) + n.seedOffset(i)).toDouble()).toFloat() * 44f +
                            cos((crawlTime * 0.43f + i * 1.1f).toDouble()).toFloat() * 20f
                    } else {
                        0f
                    }
                    val crawlY = if (smoothAnimations) {
                        cos((crawlTime * (0.62f + (i % 3) * 0.22f) + i * 0.85f).toDouble()).toFloat() * 44f +
                            sin((crawlTime * 0.37f + i * 0.6f).toDouble()).toFloat() * 20f
                    } else {
                        0f
                    }
                    val px = (size.width * n.xRatio + crawlX).coerceIn(14f, size.width - 14f)
                    val py = (size.height * n.yRatio + crawlY).coerceIn(14f, size.height - 14f)
                    Offset(px, py)
                }
                val maxEdgeDist = min(size.width, size.height) * 0.36f
                for (i in pts.indices) {
                    for (j in i + 1 until pts.size) {
                        val dx = pts[i].x - pts[j].x
                        val dy = pts[i].y - pts[j].y
                        val dist = sqrt(dx * dx + dy * dy)
                        if (dist < maxEdgeDist) {
                            val closeness = 1f - (dist / maxEdgeDist)
                            val edgeColor = if (nodes[i].isVioletAccent || nodes[j].isVioletAccent) {
                                Color(0xFFA855F7)
                            } else {
                                Color(0xFF818CF8)
                            }
                            drawLine(
                                color = edgeColor.copy(alpha = (0.16f + closeness * 0.26f)),
                                start = pts[i],
                                end = pts[j],
                                strokeWidth = (1.1f + closeness * 1.15f).dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }
                pts.forEachIndexed { i, pt ->
                    val n = nodes[i]
                    val nodeColor = if (n.isVioletAccent) Color(0xFFD8B4FE) else Color(0xFFC4B5FD)
                    val glowColor = if (n.isVioletAccent) Color(0xFF9333EA) else Color(0xFF6366F1)
                    val rPx = n.radiusDp.dp.toPx()
                    drawCircle(color = glowColor.copy(alpha = 0.26f), radius = rPx * 2.5f, center = pt)
                    drawCircle(color = nodeColor.copy(alpha = 0.88f), radius = rPx, center = pt)
                }
            }

            2 -> {
                // Вариант 2: Космос в фиолетовых тонах — орбитальные дуги и звёздные точки
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF090414),
                            Color(0xFF22093D),
                            Color(0xFF0C051A)
                        )
                    )
                )
                val center = Offset(size.width * 0.5f, size.height * 0.45f)
                val baseR = min(size.width, size.height) * 0.22f
                for (ring in 1..4) {
                    val rot = if (smoothAnimations) crawlTime * (0.4f * ring) else 0f
                    drawCircle(
                        color = Color(0xFFA855F7).copy(alpha = 0.14f + ring * 0.03f),
                        radius = baseR * ring * 0.72f,
                        center = center,
                        style = Stroke(width = 1.4.dp.toPx())
                    )
                    val orbAngle = rot + ring * 1.2f
                    val orbPt = Offset(
                        x = center.x + baseR * ring * 0.72f * cos(orbAngle.toDouble()).toFloat(),
                        y = center.y + baseR * ring * 0.72f * sin(orbAngle.toDouble()).toFloat()
                    )
                    drawCircle(color = Color(0xFFD8B4FE).copy(alpha = 0.75f), radius = 4.dp.toPx(), center = orbPt)
                }
                nodes.forEachIndexed { i, n ->
                    val shift = if (smoothAnimations) sin((crawlTime + i).toDouble()).toFloat() * 14f else 0f
                    val p = Offset(
                        x = (size.width * n.xRatio + shift).coerceIn(10f, size.width - 10f),
                        y = (size.height * n.yRatio - shift * 0.6f).coerceIn(10f, size.height - 10f)
                    )
                    drawCircle(color = Color(0xFFC084FC).copy(alpha = 0.65f), radius = 2.5.dp.toPx(), center = p)
                }
            }

            3 -> {
                // Вариант 3: Космос в фиолетовых тонах — глубокая туманность и скопления звёзд
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF120524),
                            Color(0xFF2E0D54),
                            Color(0xFF090312)
                        )
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFC084FC).copy(alpha = 0.28f),
                            Color(0xFF7E22CE).copy(alpha = 0.16f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.28f, size.height * 0.28f),
                        radius = max(size.width, size.height) * 0.55f
                    ),
                    radius = max(size.width, size.height) * 0.55f,
                    center = Offset(size.width * 0.28f, size.height * 0.28f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF9333EA).copy(alpha = 0.24f),
                            Color(0xFF581C87).copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.75f, size.height * 0.68f),
                        radius = max(size.width, size.height) * 0.52f
                    ),
                    radius = max(size.width, size.height) * 0.52f,
                    center = Offset(size.width * 0.75f, size.height * 0.68f)
                )
                for (k in 0 until 28) {
                    val fx = ((k * 73) % 100) / 100f
                    val fy = ((k * 41 + 19) % 100) / 100f
                    val drift = if (smoothAnimations) cos((crawlTime * 0.8f + k).toDouble()).toFloat() * 12f else 0f
                    val pt = Offset(
                        x = (size.width * fx + drift).coerceIn(8f, size.width - 8f),
                        y = (size.height * fy).coerceIn(8f, size.height - 8f)
                    )
                    drawCircle(
                        color = Color(0xFFE9D5FF).copy(alpha = if (k % 3 == 0) 0.78f else 0.42f),
                        radius = if (k % 4 == 0) 3.4.dp.toPx() else 2.dp.toPx(),
                        center = pt
                    )
                }
            }

            else -> {
                // Вариант 4: Тематика код в фиолетовых тонах — фиолетовые столбцы кодовых блоков и сетка
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF070312),
                            Color(0xFF190733),
                            Color(0xFF06020E)
                        )
                    )
                )
                val cols = 10
                val colWidth = size.width / cols.toFloat()
                for (c in 0 until cols) {
                    val xCenter = colWidth * (c + 0.5f)
                    val streamShift = if (smoothAnimations) {
                        ((crawlTime * 38f + c * 47f) % max(120f, size.height))
                    } else {
                        (c * 53f) % max(120f, size.height)
                    }
                    // Тонкая вертикальная направляющая линии кода
                    drawLine(
                        color = Color(0xFF7E22CE).copy(alpha = 0.14f),
                        start = Offset(xCenter, 0f),
                        end = Offset(xCenter, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                    // Сегменты "токенов кода" вдоль колонки
                    val segCount = 6
                    val segStep = size.height / segCount.toFloat()
                    for (s in 0 until segCount) {
                        val yPos = ((s * segStep + streamShift) % size.height)
                        val isBright = (c + s) % 3 == 0
                        drawLine(
                            color = if (isBright) Color(0xFFD8B4FE).copy(alpha = 0.52f) else Color(0xFFA855F7).copy(alpha = 0.24f),
                            start = Offset(xCenter, yPos),
                            end = Offset(xCenter, (yPos + 16.dp.toPx()).coerceAtMost(size.height)),
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
    }
}

private fun GraphNode.seedOffset(index: Int): Float = (xRatio * 13.7f + yRatio * 7.3f + index * 0.9f)


private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
