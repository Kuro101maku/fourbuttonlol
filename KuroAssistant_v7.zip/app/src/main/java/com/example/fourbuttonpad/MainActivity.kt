package com.example.fourbuttonpad

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class QuickNote(
    val id: Long,
    val timestamp: String,
    val text: String,
    val modeName: String = PadMode.SCHOOL.name
)

enum class PadMode(
    val label: String,
    val accent: Color,
    val inverseNeonText: Color,
    val defaultSeconds: Int?,
    val supportsTimer: Boolean
) {
    SCHOOL(
        label = "Школа",
        accent = Color(0xFFE11D48),
        inverseNeonText = Color(0xFF5EEAD4),
        defaultSeconds = 40 * 60,
        supportsTimer = true
    ),
    CODING(
        label = "Коддинг",
        accent = Color(0xFF9333EA),
        inverseNeonText = Color(0xFFBEF264),
        defaultSeconds = 60 * 60,
        supportsTimer = true
    ),
    REST(
        label = "Отдых",
        accent = Color(0xFF84CC16),
        inverseNeonText = Color(0xFFC084FC),
        defaultSeconds = null,
        supportsTimer = true
    ),
    SLEEP(
        label = "Сон",
        accent = Color(0xFF93C5FD),
        inverseNeonText = Color(0xFFFDE68A),
        defaultSeconds = null,
        supportsTimer = false
    );

    companion object {
        fun fromName(name: String?): PadMode {
            if (name == "STUDY") return SCHOOL
            return runCatching { valueOf(name ?: "") }.getOrDefault(SCHOOL)
        }
    }
}

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.SCHOOL,
    val remainingSeconds: Int = 40 * 60,
    val isTimerRunning: Boolean = false,
    val notes: List<QuickNote> = emptyList()
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val mode = PadMode.fromName(obj.optString("mode", PadMode.SCHOOL.name))
            val defaultSec = mode.defaultSeconds ?: 0
            val remainingSeconds = obj.optInt("remainingSeconds", defaultSec).coerceAtLeast(0)
            val isTimerRunning = if (mode.supportsTimer) obj.optBoolean("isTimerRunning", false) else false

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    val rawStamp = item.optString("timestamp", "").ifBlank {
                        item.optString("time", "01.01.26, 00:00")
                    }
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            timestamp = rawStamp,
                            text = item.optString("text", ""),
                            modeName = PadMode.fromName(item.optString("modeName", mode.name)).name
                        )
                    )
                }
            }

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                notes = notes
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("timestamp", n.timestamp)
                        put("text", n.text)
                        put("modeName", n.modeName)
                    }
                )
            }
            put("notes", arr)
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

object AlertHelper {
    const val CHANNEL_SCHOOL_NO_VIBRATE = "kuro_school_silent_v3"
    const val CHANNEL_CODING_VIBRATE = "kuro_coding_vibrate_v3"
    const val CHANNEL_ONGOING_QUIET = "kuro_ongoing_quiet_v3"

    private const val TIMER_DONE_ID = 1001
    private const val ONGOING_STATUS_ID = 2001

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Школа: по окончании таймера, без вибрации (чтобы не отвлекало)
            val schoolChannel = NotificationChannel(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Школа — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомление по окончании таймера в режиме Школа без вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
            }

            // Коддинг: уведомление с вибрацией по окончании таймера
            val codingChannel = NotificationChannel(
                CHANNEL_CODING_VIBRATE,
                "Коддинг — завершение таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомление по окончании таймера в режиме Коддинг с вибрацией"
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 300L, 150L, 300L)
            }

            // Сон и Отдых: постоянные уведомления, тихие (без звука, вибрации и всплывающего алерта)
            val ongoingQuietChannel = NotificationChannel(
                CHANNEL_ONGOING_QUIET,
                "Сон и Отдых — постоянный статус",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Постоянное статус-уведомление для режимов Сон и Отдых без звука и вибрации"
                setSound(null, null)
                enableVibration(false)
                vibrationPattern = longArrayOf(0L)
                setShowBadge(false)
            }

            manager.createNotificationChannel(schoolChannel)
            manager.createNotificationChannel(codingChannel)
            manager.createNotificationChannel(ongoingQuietChannel)
        }
    }

    fun canNotify(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }

    fun showTimerDoneNotification(context: Context, mode: PadMode) {
        if (!canNotify(context)) return

        val (channelId, title, message, vibrateEnabled) = when (mode) {
            PadMode.CODING -> Quadruple(
                CHANNEL_CODING_VIBRATE,
                "Помощник Куро — Коддинг",
                "Таймер закончился. Пора отдохнуть.",
                true
            )
            else -> Quadruple(
                CHANNEL_SCHOOL_NO_VIBRATE,
                "Помощник Куро — Школа",
                "Урок кончился? Есть что записать? Я здесь.",
                false
            )
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(0)
            .setSilent(!vibrateEnabled)
            .setAutoCancel(true)
            .apply {
                if (vibrateEnabled) {
                    setVibrate(longArrayOf(0L, 300L, 150L, 300L))
                } else {
                    setVibrate(longArrayOf(0L))
                }
            }
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(TIMER_DONE_ID, notification)
        }
    }

    // Постоянное уведомление ТОЛЬКО для режимов Сон и Отдых (без звукового/всплывающего оповещения)
    fun syncOngoingModeNotification(context: Context, mode: PadMode) {
        if (!canNotify(context)) return

        val message = when (mode) {
            PadMode.SLEEP -> "Вы спите?"
            PadMode.REST -> "Ждём, когда Вы отдохнете... Не торопитесь, я здесь."
            else -> {
                cancelOngoingNotification(context)
                return
            }
        }

        val title = "Помощник Куро — ${mode.label}"
        val notification = NotificationCompat.Builder(context, CHANNEL_ONGOING_QUIET)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setAutoCancel(false)
            .setDefaults(0)
            .setSilent(true)
            .setVibrate(longArrayOf(0L))
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(ONGOING_STATUS_ID, notification)
        }
    }

    fun cancelOngoingNotification(context: Context) {
        runCatching {
            NotificationManagerCompat.from(context).cancel(ONGOING_STATUS_ID)
        }
    }

    private data class Quadruple<A, B, C, D>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D
    )
}

class MainActivity : ComponentActivity() {
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                val store = MemoryStore(File(filesDir, "pad_memory.json"))
                AlertHelper.syncOngoingModeNotification(this, store.load().mode)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.ensureChannels(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()
        AlertHelper.syncOngoingModeNotification(this, initialState.mode)

        setContent {
            KuroAssistantApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KuroAssistantApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var showCodingPresetDialog by remember { mutableStateOf(false) }
    var showCustomRestDialog by remember { mutableStateOf(false) }
    var showTimerFinishedBanner by remember { mutableStateOf(false) }
    var draftNote by remember { mutableStateOf("") }
    var customMinutesInput by remember { mutableStateOf("15") }

    fun updateAndSave(transform: (PadMemoryState) -> PadMemoryState) {
        val next = transform(state)
        state = next
        onPersist(next)
        AlertHelper.syncOngoingModeNotification(context, next.mode)
    }

    fun applyModeSelection(chosen: PadMode) {
        when (chosen) {
            PadMode.SCHOOL -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.SCHOOL,
                        remainingSeconds = 40 * 60,
                        isTimerRunning = false
                    )
                }
            }
            PadMode.CODING -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.CODING,
                        remainingSeconds = 60 * 60,
                        isTimerRunning = false
                    )
                }
                showCodingPresetDialog = true
            }
            PadMode.REST -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.REST,
                        remainingSeconds = 0,
                        isTimerRunning = false
                    )
                }
                showCustomRestDialog = true
            }
            PadMode.SLEEP -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.SLEEP,
                        remainingSeconds = 0,
                        isTimerRunning = false
                    )
                }
            }
        }
    }

    LaunchedEffect(state.isTimerRunning, state.mode) {
        while (state.isTimerRunning && state.mode.supportsTimer && state.remainingSeconds > 0) {
            delay(1000L)
            var reachedZero = false
            var finishedMode = state.mode
            updateAndSave { current ->
                finishedMode = current.mode
                if (!current.isTimerRunning || !current.mode.supportsTimer) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    reachedZero = true
                    current.copy(remainingSeconds = 0, isTimerRunning = false)
                }
            }
            if (reachedZero) {
                showTimerFinishedBanner = true
                // Уведомление по окончании таймера срабатывает только для режимов с таймером (Школа — без вибрации, Коддинг — с вибрацией)
                if (finishedMode == PadMode.SCHOOL || finishedMode == PadMode.CODING) {
                    AlertHelper.showTimerDoneNotification(context, finishedMode)
                }
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = state.mode.accent,
        onPrimary = Color(0xFF060911),
        background = Color(0xFF060911),
        onBackground = Color(0xFFF1F5F9),
        surface = Color(0xFF0E1525),
        onSurface = Color(0xFFF1F5F9),
        surfaceVariant = Color(0xFF1A2438),
        onSurfaceVariant = Color(0xFF94A3B8)
    )

    MaterialTheme(colorScheme = darkScheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Помощник Куро",
                            fontWeight = FontWeight.SemiBold,
                            color = state.mode.inverseNeonText
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0A0F1C),
                        titleContentColor = state.mode.inverseNeonText
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (showTimerFinishedBanner) {
                    val bannerMessage = when (state.mode) {
                        PadMode.CODING -> "Таймер закончился. Пора отдохнуть."
                        else -> "Урок кончился? Есть что записать? Я здесь."
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, state.mode.accent.copy(alpha = 0.78f))
                    ) {
                        Row(
                            modifier = Modifier
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            state.mode.accent.copy(alpha = 0.36f),
                                            Color.White.copy(alpha = 0.08f)
                                        )
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Таймер завершён (${state.mode.label})",
                                    fontWeight = FontWeight.Bold,
                                    color = state.mode.inverseNeonText
                                )
                                Text(
                                    text = bannerMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                            TextButton(onClick = { showTimerFinishedBanner = false }) {
                                Text("ОК", color = state.mode.inverseNeonText, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Стеклянная карточка статуса с пустым неоновым счётчиком
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, state.mode.accent.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        state.mode.accent.copy(alpha = 0.22f),
                                        Color.White.copy(alpha = 0.06f)
                                    )
                                )
                            )
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Режим: ${state.mode.label}",
                                fontWeight = FontWeight.Bold,
                                color = state.mode.inverseNeonText
                            )
                            val timerText = when {
                                !state.mode.supportsTimer -> "Таймер: отключён"
                                state.mode == PadMode.REST && state.remainingSeconds == 0 ->
                                    "Таймер: без таймера (00:00)"
                                else -> "Таймер: ${formatSeconds(state.remainingSeconds)}"
                            }
                            Text(
                                text = timerText,
                                color = state.mode.inverseNeonText
                            )
                            Text(
                                text = "Счётчик: тап +1, зажать -1",
                                style = MaterialTheme.typography.labelSmall,
                                color = state.mode.inverseNeonText.copy(alpha = 0.85f)
                            )
                        }

                        NeonHollowCounter(
                            value = state.counter,
                            neonColor = state.mode.accent
                        )
                    }
                }

                // Кнопка 1 и Кнопка 2 — цветные стеклянные кнопки
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ColoredGlassButton(
                        text = "1. Заметка",
                        tint = state.mode.accent,
                        textColor = state.mode.inverseNeonText,
                        modifier = Modifier.weight(1f).height(64.dp),
                        onClick = { showNoteDialog = true }
                    )

                    val canToggleTimer = state.mode.supportsTimer && state.remainingSeconds > 0
                    val timerLabel = when {
                        !state.mode.supportsTimer -> "2. Без таймера"
                        state.mode == PadMode.REST && state.remainingSeconds == 0 -> "2. Задать время"
                        state.isTimerRunning -> "2. Пауза"
                        else -> "2. Старт"
                    }
                    ColoredGlassButton(
                        text = timerLabel,
                        tint = Color(0xFF0EA5E9),
                        textColor = Color(0xFFFDE047),
                        modifier = Modifier.weight(1f).height(64.dp),
                        onClick = {
                            if (canToggleTimer) {
                                showTimerFinishedBanner = false
                                updateAndSave { it.copy(isTimerRunning = !it.isTimerRunning) }
                            } else if (state.mode == PadMode.REST) {
                                showCustomRestDialog = true
                            }
                        }
                    )
                }

                // Кнопка 3 (тап +1, зажатие -1) и Кнопка 4 (радиальное меню) — цветные стеклянные
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, state.mode.accent.copy(alpha = 0.72f)),
                        modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        updateAndSave { it.copy(counter = it.counter + 1) }
                                    },
                                    onLongPress = {
                                        updateAndSave { it.copy(counter = it.counter - 1) }
                                    }
                                )
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            state.mode.accent.copy(alpha = 0.44f),
                                            state.mode.accent.copy(alpha = 0.20f)
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "3. Счёт (±1)",
                                fontWeight = FontWeight.SemiBold,
                                color = state.mode.inverseNeonText
                            )
                        }
                    }

                    ColoredGlassButton(
                        text = "4. Меню",
                        tint = Color(0xFF8B5CF6),
                        textColor = Color(0xFF67E8F9),
                        modifier = Modifier.weight(1f).height(64.dp),
                        onClick = { showRadialMenu = true }
                    )
                }

                Text(
                    text = "Сохранённые записи (${state.notes.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = state.mode.inverseNeonText
                )

                if (state.notes.isEmpty()) {
                    Text(
                        text = "Пока пусто. Нажмите «1. Заметка», чтобы добавить запись.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.notes, key = { it.id }) { note ->
                            val noteMode = PadMode.fromName(note.modeName)
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Transparent,
                                border = BorderStroke(1.dp, noteMode.accent.copy(alpha = 0.55f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.horizontalGradient(
                                                colors = listOf(
                                                    noteMode.accent.copy(alpha = 0.28f),
                                                    noteMode.accent.copy(alpha = 0.08f)
                                                )
                                            )
                                        )
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(end = 8.dp)
                                    ) {
                                        Text(
                                            text = "${note.timestamp}  •  ${noteMode.label}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = noteMode.inverseNeonText
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = note.text,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color(0xFFF8FAFC)
                                        )
                                    }
                                    TextButton(
                                        onClick = {
                                            updateAndSave { current ->
                                                current.copy(notes = current.notes.filterNot { it.id == note.id })
                                            }
                                        }
                                    ) {
                                        Text(
                                            text = "Удалить",
                                            color = Color(0xFFFDA4AF),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showRadialMenu) {
            RadialFourWayDialog(
                currentMode = state.mode,
                onSelectMode = { chosen ->
                    showRadialMenu = false
                    applyModeSelection(chosen)
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showCodingPresetDialog) {
            val presets = listOf(
                "30 мин" to 30 * 60,
                "1 ч" to 60 * 60,
                "1,5 ч" to 90 * 60,
                "2 ч" to 120 * 60
            )
            GlassDialogWrapper(onDismiss = { showCodingPresetDialog = false }) {
                Text(
                    text = "Коддинг — длительность",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PadMode.CODING.inverseNeonText
                )
                Text(
                    text = "Выберите интервал таймера",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
                presets.forEach { (label, seconds) ->
                    ColoredGlassButton(
                        text = label,
                        tint = PadMode.CODING.accent,
                        textColor = PadMode.CODING.inverseNeonText,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.CODING,
                                    remainingSeconds = seconds,
                                    isTimerRunning = false
                                )
                            }
                            showCodingPresetDialog = false
                        }
                    )
                }
                TextButton(onClick = { showCodingPresetDialog = false }) {
                    Text("Оставить текущий", color = Color(0xFFCBD5E1))
                }
            }
        }

        if (showCustomRestDialog) {
            GlassDialogWrapper(onDismiss = { showCustomRestDialog = false }) {
                Text(
                    text = "Отдых",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = PadMode.REST.inverseNeonText
                )
                Text(
                    text = "Режим работает без таймера, но при желании Вы можете задать своё время в минутах.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
                OutlinedTextField(
                    value = customMinutesInput,
                    onValueChange = { value ->
                        customMinutesInput = value.filter { it.isDigit() }.take(3)
                    },
                    label = { Text("Минуты (опционально)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.REST,
                                    remainingSeconds = 0,
                                    isTimerRunning = false
                                )
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Без таймера", color = Color(0xFFCBD5E1))
                    }
                    ColoredGlassButton(
                        text = "Задать",
                        tint = PadMode.REST.accent,
                        textColor = PadMode.REST.inverseNeonText,
                        modifier = Modifier.weight(1f).height(44.dp),
                        onClick = {
                            val mins = customMinutesInput.toIntOrNull()?.coerceIn(1, 720)
                            if (mins != null) {
                                updateAndSave {
                                    it.copy(
                                        mode = PadMode.REST,
                                        remainingSeconds = mins * 60,
                                        isTimerRunning = false
                                    )
                                }
                            }
                            showCustomRestDialog = false
                        }
                    )
                }
            }
        }

        if (showNoteDialog) {
            GlassDialogWrapper(onDismiss = { showNoteDialog = false }) {
                Text(
                    text = "Новая заметка (${state.mode.label})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = state.mode.inverseNeonText
                )
                OutlinedTextField(
                    value = draftNote,
                    onValueChange = { draftNote = it },
                    placeholder = { Text("Короткая мысль или задача...") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена", color = Color(0xFFCBD5E1))
                    }
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("dd.MM.yy, HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    timestamp = stamp,
                                    text = clean,
                                    modeName = state.mode.name
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить", color = state.mode.inverseNeonText, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColoredGlassButton(
    text: String,
    tint: Color,
    textColor: Color = Color.White,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.72f)),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            tint.copy(alpha = 0.44f),
                            tint.copy(alpha = 0.20f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            )
        }
    }
}

@Composable
private fun NeonHollowCounter(
    value: Int,
    neonColor: Color
) {
    val isNegative = value < 0
    val absDigits = abs(value).toString()
    val fontSize = 44.sp

    Row(
        modifier = Modifier
            .shadow(16.dp, RoundedCornerShape(16.dp), ambientColor = neonColor, spotColor = neonColor)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (isNegative) {
            Text(
                text = "-",
                style = TextStyle(
                    fontSize = fontSize,
                    fontWeight = FontWeight.ExtraBold,
                    color = neonColor
                )
            )
        }

        Box(contentAlignment = Alignment.Center) {
            Text(
                text = absDigits,
                style = TextStyle(
                    fontSize = fontSize,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF060911),
                    drawStyle = Stroke(width = 4.5f, join = StrokeJoin.Round)
                )
            )
            Text(
                text = absDigits,
                style = TextStyle(
                    fontSize = fontSize,
                    fontWeight = FontWeight.ExtraBold,
                    color = neonColor,
                    drawStyle = Stroke(width = 2.0f, join = StrokeJoin.Round)
                )
            )
        }
    }
}

@Composable
private fun GlassDialogWrapper(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF1E293B).copy(alpha = 0.88f),
                                Color(0xFF0F172A).copy(alpha = 0.92f)
                            )
                        )
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun RadialFourWayDialog(
    currentMode: PadMode,
    onSelectMode: (PadMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sectors = listOf(PadMode.SCHOOL, PadMode.CODING, PadMode.REST, PadMode.SLEEP)
    val startAngle = -135f
    val sweepAngle = 90f

    GlassDialogWrapper(onDismiss = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Выбор активности",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = currentMode.inverseNeonText
            )
            Text(
                text = "Тапните по сектору круга",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1)
            )

            BoxWithConstraints(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                val labelRadiusDp = (maxWidth.value * 0.31f)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(sectors) {
                            detectTapGestures { tap ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tap.x - center.x
                                val dy = tap.y - center.y
                                val r = min(size.width, size.height) / 2f
                                val innerHole = r * 0.20f
                                val dist = sqrt(dx * dx + dy * dy)

                                if (dist in innerHole..r) {
                                    val deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                    var rel = (deg - startAngle) % 360f
                                    if (rel < 0f) rel += 360f
                                    val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                    onSelectMode(sectors[index])
                                }
                            }
                        }
                ) {
                    val diameter = min(size.width, size.height)
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    sectors.forEachIndexed { idx, mode ->
                        val sectorStart = startAngle + idx * sweepAngle
                        val isSelected = mode == currentMode
                        drawArc(
                            color = mode.accent.copy(alpha = if (isSelected) 0.90f else 0.52f),
                            startAngle = sectorStart,
                            sweepAngle = sweepAngle,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                    }

                    val outerRadius = diameter / 2f
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)
                    for (i in sectors.indices) {
                        val rad = ((startAngle + i * sweepAngle) * PI / 180.0).toFloat()
                        val endPt = Offset(
                            x = centerOffset.x + outerRadius * cos(rad),
                            y = centerOffset.y + outerRadius * sin(rad)
                        )
                        drawLine(
                            color = Color(0xFF0A0F1C),
                            start = centerOffset,
                            end = endPt,
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }

                    val activeIdx = sectors.indexOf(currentMode).coerceAtLeast(0)
                    drawArc(
                        color = Color.White,
                        startAngle = startAngle + activeIdx * sweepAngle,
                        sweepAngle = sweepAngle,
                        useCenter = true,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
                    )

                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = diameter * 0.11f
                    )
                }

                sectors.forEachIndexed { idx, mode ->
                    val midAngleRad = ((startAngle + idx * sweepAngle + sweepAngle / 2f) * PI / 180.0)
                    val offsetX = (labelRadiusDp * cos(midAngleRad)).dp
                    val offsetY = (labelRadiusDp * sin(midAngleRad)).dp
                    Text(
                        text = mode.label,
                        fontWeight = FontWeight.Bold,
                        color = mode.inverseNeonText,
                        modifier = Modifier.offset(x = offsetX, y = offsetY)
                    )
                }
            }

            TextButton(onClick = onDismiss) {
                Text("Закрыть", color = Color(0xFFCBD5E1))
            }
        }
    }
}

private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
