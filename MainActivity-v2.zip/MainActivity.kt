package com.example.fourbuttonpad

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class QuickNote(
    val id: Long,
    val time: String,
    val text: String
)

enum class PadMode(
    val label: String,
    val accent: Color,
    val defaultSeconds: Int?,
    val hasTimer: Boolean
) {
    STUDY("Учёба", Color(0xFF38BDF8), 40 * 60, true),
    CODING("Коддинг", Color(0xFFA855F7), 60 * 60, true),
    REST("Отдых", Color(0xFF10B981), null, false),
    SLEEP("Сон", Color(0xFF6366F1), null, false)
}

data class PadMemoryState(
    val counter: Int = 0,
    val mode: PadMode = PadMode.STUDY,
    val remainingSeconds: Int = 40 * 60,
    val isTimerRunning: Boolean = false,
    val notes: List<QuickNote> = emptyList()
)

class MemoryStore(private val file: File) {
    fun load(): PadMemoryState {
        if (!file.exists()) return PadMemoryState()
        return try {
            val raw = file.readText()
            if (raw.isBlank()) return PadMemoryState()
            val obj = JSONObject(raw)

            val counter = obj.optInt("counter", 0)
            val modeName = obj.optString("mode", PadMode.STUDY.name)
            val mode = runCatching { PadMode.valueOf(modeName) }.getOrDefault(PadMode.STUDY)
            val defaultSec = mode.defaultSeconds ?: 0
            val remainingSeconds = obj.optInt("remainingSeconds", defaultSec).coerceAtLeast(0)
            val isTimerRunning = if (mode.hasTimer) obj.optBoolean("isTimerRunning", false) else false

            val notesJson = obj.optJSONArray("notes") ?: JSONArray()
            val notes = buildList {
                for (i in 0 until notesJson.length()) {
                    val item = notesJson.optJSONObject(i) ?: continue
                    add(
                        QuickNote(
                            id = item.optLong("id", System.currentTimeMillis() + i),
                            time = item.optString("time", "--:--"),
                            text = item.optString("text", "")
                        )
                    )
                }
            }

            PadMemoryState(
                counter = counter,
                mode = mode,
                remainingSeconds = remainingSeconds,
                isTimerRunning = isTimerRunning,
                notes = notes
            )
        } catch (_: Exception) {
            PadMemoryState()
        }
    }

    fun save(state: PadMemoryState) {
        val root = JSONObject().apply {
            put("counter", state.counter)
            put("mode", state.mode.name)
            put("remainingSeconds", state.remainingSeconds)
            put("isTimerRunning", state.isTimerRunning)

            val arr = JSONArray()
            for (n in state.notes) {
                arr.put(
                    JSONObject().apply {
                        put("id", n.id)
                        put("time", n.time)
                        put("text", n.text)
                    }
                )
            }
            put("notes", arr)
        }
        val tmpFile = File(file.parentFile, "${file.name}.tmp")
        tmpFile.writeText(root.toString())
        tmpFile.renameTo(file)
    }
}

object AlertHelper {
    const val CHANNEL_ID = "la_silent_timer_channel"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Уведомления таймера",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Всплывающие уведомления по завершении таймера"
                setSound(null, null)
                enableVibration(false)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun showTimerDoneNotification(context: Context, modeLabel: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Время вышло — $modeLabel")
            .setContentText("Таймер завершил отсчёт (00:00).")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSilent(true)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(1001, notification)
        }
    }
}

class MainActivity : ComponentActivity() {
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.ensureChannel(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val store = MemoryStore(File(filesDir, "pad_memory.json"))
        val initialState = store.load()

        setContent {
            FourButtonPadApp(
                initialState = initialState,
                onPersist = { latest -> store.save(latest) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FourButtonPadApp(
    initialState: PadMemoryState,
    onPersist: (PadMemoryState) -> Unit
) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(initialState) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var showCodingPresetDialog by remember { mutableStateOf(false) }
    var showCustomRestDialog by remember { mutableStateOf(false) }
    var showTimerFinishedBanner by remember { mutableStateOf(false) }
    var draftNote by remember { mutableStateOf("") }
    var customMinutesInput by remember { mutableStateOf("15") }

    fun updateAndSave(transform: (PadMemoryState) -> PadMemoryState) {
        val next = transform(state)
        state = next
        onPersist(next)
    }

    fun applyModeSelection(chosen: PadMode) {
        when (chosen) {
            PadMode.STUDY -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.STUDY,
                        remainingSeconds = 40 * 60,
                        isTimerRunning = false
                    )
                }
            }
            PadMode.CODING -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.CODING,
                        remainingSeconds = 60 * 60,
                        isTimerRunning = false
                    )
                }
                showCodingPresetDialog = true
            }
            PadMode.REST -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.REST,
                        remainingSeconds = 0,
                        isTimerRunning = false
                    )
                }
                showCustomRestDialog = true
            }
            PadMode.SLEEP -> {
                showTimerFinishedBanner = false
                updateAndSave {
                    it.copy(
                        mode = PadMode.SLEEP,
                        remainingSeconds = 0,
                        isTimerRunning = false
                    )
                }
            }
        }
    }

    LaunchedEffect(state.isTimerRunning, state.mode) {
        while (state.isTimerRunning && state.mode.hasTimer) {
            delay(1000L)
            var reachedZero = false
            updateAndSave { current ->
                if (!current.isTimerRunning || !current.mode.hasTimer) {
                    current
                } else if (current.remainingSeconds > 1) {
                    current.copy(remainingSeconds = current.remainingSeconds - 1)
                } else {
                    reachedZero = true
                    current.copy(remainingSeconds = 0, isTimerRunning = false)
                }
            }
            if (reachedZero) {
                showTimerFinishedBanner = true
                AlertHelper.showTimerDoneNotification(context, state.mode.label)
            }
        }
    }

    val darkScheme = darkColorScheme(
        primary = state.mode.accent,
        onPrimary = Color(0xFF060911),
        background = Color(0xFF070B14),
        onBackground = Color(0xFFE2E8F0),
        surface = Color(0xFF0F172A),
        onSurface = Color(0xFFE2E8F0),
        surfaceVariant = Color(0xFF1E293B),
        onSurfaceVariant = Color(0xFF94A3B8)
    )

    val glassSurface = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.16f),
            Color.White.copy(alpha = 0.06f)
        )
    )
    val glassBorder = BorderStroke(1.dp, Color.White.copy(alpha = 0.24f))

    MaterialTheme(colorScheme = darkScheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FourPointStarBadge(size = 28.dp)
                            Text("Быстрый пульт", fontWeight = FontWeight.SemiBold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0B1120),
                        titleContentColor = Color(0xFFF8FAFC)
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (showTimerFinishedBanner) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, state.mode.accent.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            state.mode.accent.copy(alpha = 0.28f),
                                            Color.White.copy(alpha = 0.08f)
                                        )
                                    )
                                )
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Таймер завершён (${state.mode.label})",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Отсчёт дошёл до 00:00",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            TextButton(onClick = { showTimerFinishedBanner = false }) {
                                Text("ОК", color = state.mode.accent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Стеклянная карточка статуса
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    border = glassBorder
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(glassSurface)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Режим: ${state.mode.label}",
                                fontWeight = FontWeight.Bold,
                                color = state.mode.accent
                            )
                            val timerText = when {
                                state.mode == PadMode.SLEEP -> "Таймер: отключён"
                                state.mode == PadMode.REST && state.remainingSeconds == 0 ->
                                    "Таймер: без таймера (00:00)"
                                else -> "Таймер: ${formatSeconds(state.remainingSeconds)}"
                            }
                            Text(
                                text = timerText,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Счётчик: тап +1, зажать -1",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${state.counter}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = state.mode.accent
                        )
                    }
                }

                // Кнопка 1 и Кнопка 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showNoteDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text("1. Заметка")
                    }

                    val canToggleTimer = state.mode.hasTimer || state.remainingSeconds > 0
                    Button(
                        onClick = {
                            if (canToggleTimer) {
                                showTimerFinishedBanner = false
                                updateAndSave { it.copy(isTimerRunning = !it.isTimerRunning) }
                            } else if (state.mode == PadMode.REST) {
                                showCustomRestDialog = true
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        val label = when {
                            !canToggleTimer && state.mode == PadMode.REST -> "2. Задать время"
                            !canToggleTimer -> "2. Без таймера"
                            state.isTimerRunning -> "2. Пауза"
                            else -> "2. Старт"
                        }
                        Text(label)
                    }
                }

                // Кнопка 3 (тап +1, зажатие -1) и Кнопка 4 (радиальное меню)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = state.mode.accent,
                        modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        updateAndSave { it.copy(counter = it.counter + 1) }
                                    },
                                    onLongPress = {
                                        updateAndSave { it.copy(counter = it.counter - 1) }
                                    }
                                )
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "3. Счёт (±1)",
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF060911)
                            )
                        }
                    }

                    Button(
                        onClick = { showRadialMenu = true },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = Color(0xFFF8FAFC)
                        ),
                        modifier = Modifier.weight(1f).height(64.dp)
                    ) {
                        Text("4. Меню")
                    }
                }

                Text(
                    text = "Сохранённые записи (${state.notes.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (state.notes.isEmpty()) {
                    Text(
                        text = "Пока пусто. Нажми «1. Заметка», чтобы добавить запись.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.notes, key = { it.id }) { note ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Transparent,
                                border = glassBorder
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(glassSurface)
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(end = 8.dp)
                                    ) {
                                        Text(
                                            text = note.time,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = state.mode.accent
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = note.text,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    TextButton(
                                        onClick = {
                                            updateAndSave { current ->
                                                current.copy(notes = current.notes.filterNot { it.id == note.id })
                                            }
                                        }
                                    ) {
                                        Text(
                                            text = "Удалить",
                                            color = Color(0xFFF87171),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showRadialMenu) {
            RadialFourWayDialog(
                currentMode = state.mode,
                onSelectMode = { chosen ->
                    showRadialMenu = false
                    applyModeSelection(chosen)
                },
                onDismiss = { showRadialMenu = false }
            )
        }

        if (showCodingPresetDialog) {
            val presets = listOf(
                "30 мин" to 30 * 60,
                "1 ч" to 60 * 60,
                "1,5 ч" to 90 * 60,
                "2 ч" to 120 * 60
            )
            GlassDialogWrapper(onDismiss = { showCodingPresetDialog = false }) {
                Text(
                    text = "Коддинг — длительность",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Выбери интервал таймера",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
                presets.forEach { (label, seconds) ->
                    Button(
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.CODING,
                                    remainingSeconds = seconds,
                                    isTimerRunning = false
                                )
                            }
                            showCodingPresetDialog = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(label)
                    }
                }
                TextButton(onClick = { showCodingPresetDialog = false }) {
                    Text("Оставить текущий", color = Color(0xFFCBD5E1))
                }
            }
        }

        if (showCustomRestDialog) {
            GlassDialogWrapper(onDismiss = { showCustomRestDialog = false }) {
                Text(
                    text = "Отдых",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Режим работает без таймера, но при желании можно задать своё время в минутах.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
                OutlinedTextField(
                    value = customMinutesInput,
                    onValueChange = { value ->
                        customMinutesInput = value.filter { it.isDigit() }.take(3)
                    },
                    label = { Text("Минуты (опционально)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            updateAndSave {
                                it.copy(
                                    mode = PadMode.REST,
                                    remainingSeconds = 0,
                                    isTimerRunning = false
                                )
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Без таймера", color = Color(0xFFCBD5E1))
                    }
                    Button(
                        onClick = {
                            val mins = customMinutesInput.toIntOrNull()?.coerceIn(1, 720)
                            if (mins != null) {
                                updateAndSave {
                                    it.copy(
                                        mode = PadMode.REST,
                                        remainingSeconds = mins * 60,
                                        isTimerRunning = false
                                    )
                                }
                            }
                            showCustomRestDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Задать")
                    }
                }
            }
        }

        if (showNoteDialog) {
            GlassDialogWrapper(onDismiss = { showNoteDialog = false }) {
                Text(
                    text = "Новая заметка",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                OutlinedTextField(
                    value = draftNote,
                    onValueChange = { draftNote = it },
                    placeholder = { Text("Короткая мысль или задача...") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Отмена", color = Color(0xFFCBD5E1))
                    }
                    TextButton(
                        onClick = {
                            val clean = draftNote.trim()
                            if (clean.isNotEmpty()) {
                                val stamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                val newNote = QuickNote(
                                    id = System.currentTimeMillis(),
                                    time = stamp,
                                    text = clean
                                )
                                updateAndSave { it.copy(notes = listOf(newNote) + it.notes) }
                            }
                            draftNote = ""
                            showNoteDialog = false
                        }
                    ) {
                        Text("Сохранить", color = state.mode.accent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassDialogWrapper(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF1E293B).copy(alpha = 0.88f),
                                Color(0xFF0F172A).copy(alpha = 0.92f)
                            )
                        )
                    )
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun RadialFourWayDialog(
    currentMode: PadMode,
    onSelectMode: (PadMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sectors = listOf(PadMode.STUDY, PadMode.CODING, PadMode.REST, PadMode.SLEEP)
    val startAngle = -135f
    val sweepAngle = 90f

    GlassDialogWrapper(onDismiss = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Выбор активности",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Тапни по сектору круга",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1)
            )

            BoxWithConstraints(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                val boxSizePx = min(constraints.maxWidth, constraints.maxHeight).toFloat()
                val radiusPx = boxSizePx / 2f
                val labelRadiusDp = (maxWidth.value * 0.31f)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(sectors) {
                            detectTapGestures { tap ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tap.x - center.x
                                val dy = tap.y - center.y
                                val r = min(size.width, size.height) / 2f
                                val innerHole = r * 0.20f
                                val dist = sqrt(dx * dx + dy * dy)

                                if (dist in innerHole..r) {
                                    val deg = (atan2(dy, dx) * 180.0 / PI).toFloat()
                                    var rel = (deg - startAngle) % 360f
                                    if (rel < 0f) rel += 360f
                                    val index = (rel / sweepAngle).toInt().coerceIn(0, sectors.lastIndex)
                                    onSelectMode(sectors[index])
                                }
                            }
                        }
                ) {
                    val diameter = min(size.width, size.height)
                    val topLeft = Offset(
                        (size.width - diameter) / 2f,
                        (size.height - diameter) / 2f
                    )
                    val arcSize = Size(diameter, diameter)

                    sectors.forEachIndexed { idx, mode ->
                        val sectorStart = startAngle + idx * sweepAngle
                        val isSelected = mode == currentMode
                        drawArc(
                            color = mode.accent.copy(alpha = if (isSelected) 0.90f else 0.42f),
                            startAngle = sectorStart,
                            sweepAngle = sweepAngle - 2f,
                            useCenter = true,
                            topLeft = topLeft,
                            size = arcSize
                        )
                        if (isSelected) {
                            drawArc(
                                color = Color.White,
                                startAngle = sectorStart,
                                sweepAngle = sweepAngle - 2f,
                                useCenter = true,
                                topLeft = topLeft,
                                size = arcSize,
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                    }

                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = diameter * 0.11f
                    )
                }

                // Подписи строго по биссектрисе каждого сектора
                sectors.forEachIndexed { idx, mode ->
                    val midAngleRad = ((startAngle + idx * sweepAngle + sweepAngle / 2f) * PI / 180.0)
                    val offsetX = (labelRadiusDp * cos(midAngleRad)).dp
                    val offsetY = (labelRadiusDp * sin(midAngleRad)).dp
                    Text(
                        text = mode.label,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.offset(x = offsetX, y = offsetY)
                    )
                }
            }

            TextButton(onClick = onDismiss) {
                Text("Закрыть", color = Color(0xFFCBD5E1))
            }
        }
    }
}

@Composable
fun FourPointStarBadge(
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 64.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.Black)
            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2f
            val cy = h / 2f
            val outerR = min(w, h) * 0.47f
            val innerR = min(w, h) * 0.22f

            val starPath = Path().apply {
                // 4 вершины звезды (верх, право, низ, лево) и 4 вогнутые точки между ними
                moveTo(cx, cy - outerR)
                quadraticTo(cx, cy, cx + outerR, cy)
                quadraticTo(cx, cy, cx, cy + outerR)
                quadraticTo(cx, cy, cx - outerR, cy)
                quadraticTo(cx, cy, cx, cy - outerR)
                close()
            }
            // Более чёткая четырёхконечная звезда с 4 точками-лучами
            val sharpStar = Path().apply {
                val pts = listOf(
                    Offset(cx, cy - outerR),
                    Offset(cx + innerR, cy - innerR),
                    Offset(cx + outerR, cy),
                    Offset(cx + innerR, cy + innerR),
                    Offset(cx, cy + outerR),
                    Offset(cx - innerR, cy + innerR),
                    Offset(cx - outerR, cy),
                    Offset(cx - innerR, cy - innerR)
                )
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) {
                    lineTo(pts[i].x, pts[i].y)
                }
                close()
            }
            drawPath(path = sharpStar, color = Color.White)
        }
        Text(
            text = "LA",
            color = Color.Black,
            fontWeight = FontWeight.ExtraBold,
            fontSize = (size.value * 0.26f).sp,
            letterSpacing = 0.5.sp
        )
    }
}

private fun formatSeconds(total: Int): String {
    val mins = total / 60
    val secs = total % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
